import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        // File operations
        FileManager fileManager = new FileManager("example.txt");
        try {
            fileManager.writeContent("Hello, World!");

            // Student and Course operations
            Student student1 = new Student("Alice");
            student1.addGrade(85);
            student1.addGrade(90);

            Student student2 = new Student("Bob");
            student2.addGrade(75);
            student2.addGrade(80);

            Course course = new Course("Math");
            course.addStudent(student1);
            course.addStudent(student2);

            for (Student student : course.getStudents()) {
                System.out.println("Student: " + student.getName() + ", Grades: " + student.getGrades());
            }

            // Check if the file exists
            boolean fileExists = fileManager.fileExists();
            System.out.println("File exists: " + fileExists);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}