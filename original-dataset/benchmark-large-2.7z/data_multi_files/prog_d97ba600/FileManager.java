import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;

public class FileManager {
    private Path path;

    public FileManager(String fileName) {
        this.path = Paths.get(fileName);
    }

    public void writeContent(String content) throws IOException {
        byte[] data = content.getBytes();
        /* write */ Files.write(path, data);
    }

    public boolean fileExists() {
        /* read */ return Files.exists(path);
    }
}
