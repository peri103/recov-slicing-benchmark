import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        DataManager dataManager = new DataManager();
        dataManager.updateData(0, 42);

        Course course = new Course("Mathematics");
        course.enrollStudent(new Student("Alice", 20));
        course.enrollStudent(new Student("Bob", 22));

        ArrayList<Student> students = course.getEnrolledStudents();
        for (Student student : students) {
            System.out.println("Student: " + student.getName() + ", Age: " + student.getAge());
        }

        ArrayList<Integer> dataList = dataManager.getDataList();
        /* read */ int value = dataList.get(0);
        System.out.println("Data value: " + value);
    }
}