import java.util.ArrayList;

public class DataManager {
    private ArrayList<Integer> dataList = new ArrayList<>();

    public DataManager() {
        dataList.add(0); // Initialize with a default value to ensure index 0 exists
    }

    public void updateData(int index, int value) {
        /* write */ dataList.set(index, value);
    }

    public ArrayList<Integer> getDataList() {
        return dataList;
    }
}
