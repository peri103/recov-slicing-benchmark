public class Data {
    volatile long value;
    volatile int intValue;
    volatile String strValue;

    public Data() {
        this.value = 0L;
        this.intValue = 0;
        this.strValue = "";
    }
}
