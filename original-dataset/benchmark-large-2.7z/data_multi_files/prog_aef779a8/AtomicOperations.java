import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

public class AtomicOperations {
    private AtomicLongFieldUpdater<Data> longUpdater = AtomicLongFieldUpdater.newUpdater(Data.class, "value");
    private AtomicIntegerFieldUpdater<Data> intUpdater = AtomicIntegerFieldUpdater.newUpdater(Data.class, "intValue");
    private AtomicReferenceFieldUpdater<Data, String> stringUpdater = AtomicReferenceFieldUpdater.newUpdater(Data.class, String.class, "strValue");

    public void performLongOperation(Data data, long newValue) {
        /* write */ longUpdater.set(data, newValue);
    }

    public void performIntOperation(Data data, int newValue) {
        intUpdater.set(data, newValue);
        intUpdater.incrementAndGet(data);
    }

    public void performStringOperation(Data data, String newValue) {
        stringUpdater.set(data, newValue);
        stringUpdater.compareAndSet(data, newValue, newValue + " Updated");
    }

    public long getLongValue(Data data) {
        return longUpdater.get(data);
    }

    public int getIntValue(Data data) {
        return intUpdater.get(data);
    }

    public String getStringValue(Data data) {
        return stringUpdater.get(data);
    }
}
