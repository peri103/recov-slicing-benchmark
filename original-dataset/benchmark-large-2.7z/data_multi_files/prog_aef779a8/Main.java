public class Main {
    public static void main(String[] args) {
        Data data = new Data();
        AtomicOperations operations = new AtomicOperations();

        operations.performLongOperation(data, 42L);
        operations.performIntOperation(data, 100);
        operations.performStringOperation(data, "Hello");

        // Unrelated computation to increase complexity
        for (int i = 0; i < 5; i++) {
            System.out.println("Loop iteration: " + i);
        }

        // Retrieve values
        long longValue = operations.getLongValue(data);
        int intValue = operations.getIntValue(data);
        String strValue = operations.getStringValue(data);

        System.out.println("Updated intValue: " + intValue);
        System.out.println("Updated strValue: " + strValue);

        // Continue with the original read
        /* read */ System.out.println("Original long value: " + longValue);
    }
}