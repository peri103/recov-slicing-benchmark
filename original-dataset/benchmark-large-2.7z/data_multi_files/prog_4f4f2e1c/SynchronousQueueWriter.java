import java.util.concurrent.SynchronousQueue;

public class SynchronousQueueWriter {
    private SynchronousQueue<Integer> queue;

    public SynchronousQueueWriter(SynchronousQueue<Integer> queue) {
        this.queue = queue;
    }

    public void writeToQueue() {
        try {
            /* write */ queue.offer(42);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
