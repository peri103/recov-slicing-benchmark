import java.util.concurrent.SynchronousQueue;

public class SynchronousQueueReader {
    private SynchronousQueue<Integer> queue;

    public SynchronousQueueReader(SynchronousQueue<Integer> queue) {
        this.queue = queue;
    }

    public void readFromQueue() {
        try {
            /* read */ Integer value = queue.peek();
            System.out.println("SynchronousQueue value: " + value);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
