import java.util.concurrent.SynchronousQueue;

public class Main {
    public static void main(String[] args) {
        SynchronousQueue<Integer> syncQueue = new SynchronousQueue<>();
        
        SynchronousQueueWriter writer = new SynchronousQueueWriter(syncQueue);
        SynchronousQueueReader reader = new SynchronousQueueReader(syncQueue);

        Thread writerThread = new Thread(writer::writeToQueue);
        Thread readerThread = new Thread(reader::readFromQueue);

        writerThread.start();
        readerThread.start();

        try {
            writerThread.join();
            readerThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Course course = new Course("Computer Science");
        Student student1 = new Student("Alice", 1);
        Student student2 = new Student("Bob", 2);

        course.addStudent(student1);
        course.addStudent(student2);

        for (Student student : course.getStudents()) {
            System.out.println("Student Name: " + student.getName() + ", ID: " + student.getId());
        }
    }
}