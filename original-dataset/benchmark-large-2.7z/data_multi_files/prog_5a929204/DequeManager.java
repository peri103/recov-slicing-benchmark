import java.util.concurrent.LinkedBlockingDeque;
import java.util.Arrays;

public class DequeManager {
    private LinkedBlockingDeque<Integer> deque = new LinkedBlockingDeque<>();

    public void initializeDeque() {
        /* write */ deque.addAll(Arrays.asList(1, 2, 3, 4, 5));
    }

    public LinkedBlockingDeque<Integer> getDeque() {
        return deque;
    }

    public void addMoreElements() {
        deque.offer(6);
        deque.offerFirst(0);
        deque.offerLast(7);
    }
}
