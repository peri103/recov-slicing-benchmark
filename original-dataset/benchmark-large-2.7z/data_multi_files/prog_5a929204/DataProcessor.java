import java.util.Queue;
import java.util.LinkedList;
import java.util.concurrent.ConcurrentHashMap;

public class DataProcessor {
    private Queue<String> stringQueue = new LinkedList<>();
    private ConcurrentHashMap<String, Integer> map = new ConcurrentHashMap<>();

    public DataProcessor() {
        stringQueue.add("Hello");
        stringQueue.add("World");
        stringQueue.add("!");

        map.put("One", 1);
        map.put("Two", 2);
        map.put("Three", 3);
    }

    public void processQueue() {
        while (!stringQueue.isEmpty()) {
            String element = stringQueue.poll();
            System.out.println("Queue Element: " + element);
        }
    }

    public void processMap() {
        map.forEach((key, value) -> {
            System.out.println("Map Key: " + key + ", Value: " + value);
        });
    }
}
