import java.util.concurrent.LinkedBlockingDeque;
import java.util.Arrays;

public class CustomDeque {
    private LinkedBlockingDeque<Integer> deque = new LinkedBlockingDeque<>();

    public void addElements() {
        /* write */ deque.addAll(Arrays.asList(1, 2, 3, 4, 5));
    }

    public LinkedBlockingDeque<Integer> getDeque() {
        return deque;
    }
}
