import java.util.concurrent.LinkedBlockingDeque;
import java.util.Arrays;

public class DequeOperations {
    private LinkedBlockingDeque<Integer> deque = new LinkedBlockingDeque<>();

    public void addElements() {
        /* write */ deque.addAll(Arrays.asList(1, 2, 3, 4, 5));
    }

    public int getSize() {
        return deque.size();
    }
}
