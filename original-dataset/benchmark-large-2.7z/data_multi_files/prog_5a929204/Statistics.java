import java.util.concurrent.LinkedBlockingDeque;

public class Statistics {
    private LinkedBlockingDeque<Integer> deque;

    public Statistics(LinkedBlockingDeque<Integer> deque) {
        this.deque = deque;
    }

    public int calculateSize() {
        /* read */ return deque.size();
    }

    public int findMax() {
        int max = Integer.MIN_VALUE;
        for (int value : deque) {
            if (value > max) {
                max = value;
            }
        }
        return max;
    }
}
