public class Main {
    public static void main(String[] args) {
        DequeOperations dequeOps = new DequeOperations();
        dequeOps.addElements();

        // Creating students
        Student student1 = new Student("Alice", 101);
        Student student2 = new Student("Bob", 102);

        // Creating a course and adding students
        Course course = new Course("Computer Science");
        course.addStudent(student1);
        course.addStudent(student2);

        // Display course information
        System.out.println("Course: " + course.getCourseName());
        for (Student student : course.getStudents()) {
            System.out.println("Student: " + student.getName() + ", ID: " + student.getId());
        }

        // Checking the size of the deque
        /* read */ int size = dequeOps.getSize();
        System.out.println("Size of deque: " + size);
    }
}