import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class StudentScores {
    private ArrayList<Integer> scores = new ArrayList<>();

    public void addScore(int score) {
        scores.add(score);
    }

    public void printScores() {
        Stream<Integer> scoreStream = scores.stream();
        /* write */ scoreStream.forEach(System.out::println);
    }

    public Stream<Integer> getScoreStream() {
        return scores.stream();
    }
}
