import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;

public class FileWriter {
    private Path filePath;

    public FileWriter(String fileName) {
        this.filePath = Paths.get(fileName);
    }

    public void writeToFile(String content) {
        try {
            /* write */ Files.writeString(filePath, content);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Path getFilePath() {
        return filePath;
    }
}