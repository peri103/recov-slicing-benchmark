import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;

public class FileReader {
    private Path filePath;

    public FileReader(Path filePath) {
        this.filePath = filePath;
    }

    public String readFromFile() {
        try {
            /* read */ return Files.readString(filePath);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}