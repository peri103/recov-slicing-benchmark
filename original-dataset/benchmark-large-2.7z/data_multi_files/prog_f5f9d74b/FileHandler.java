import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;

public class FileHandler {
    private Path filePath = Paths.get("example.txt");

    public void writeToFile(String content) {
        try {
            /* write */ Files.writeString(filePath, content);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String readFromFile() {
        try {
            /* read */ return Files.readString(filePath);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
