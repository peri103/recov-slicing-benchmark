public class Main {
    public static void main(String[] args) {
        // Initialize FileHandler
        FileHandler fileHandler = new FileHandler();
        
        // Write to file using FileHandler
        fileHandler.writeToFile("Hello, World!");

        // Initialize students and course
        Student student1 = new Student("Alice");
        Student student2 = new Student("Bob");
        Course course = new Course("Computer Science");

        // Add scores to students
        student1.addScore(85);
        student1.addScore(92);
        student2.addScore(78);
        student2.addScore(88);

        // Add students to course
        course.addStudent(student1);
        course.addStudent(student2);

        // Read from file using FileHandler
        String contentRead = fileHandler.readFromFile();
        System.out.println("Read from file: " + contentRead);

        // Display course information
        System.out.println("Course Name: " + course.getCourseName());
        for (Student student : course.getStudents()) {
            System.out.println("Student Name: " + student.getName());
            System.out.println("Scores: " + student.getScores());
        }
    }
}