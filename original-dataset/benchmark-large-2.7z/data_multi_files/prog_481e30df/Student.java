import java.util.ArrayList;

public class Student {
    private String name;
    private ArrayList<Integer> grades;
    private DoubleAdderWrapper adderWrapper;

    public Student(String name) {
        this.name = name;
        this.grades = new ArrayList<>();
        this.adderWrapper = new DoubleAdderWrapper();
    }

    public void addGrade(int grade) {
        grades.add(grade);
        if (grade > 50) {
            adderWrapper.incrementAdder();
        }
    }

    public ArrayList<Integer> getGrades() {
        return grades;
    }

    public DoubleAdderWrapper getAdderWrapper() {
        return adderWrapper;
    }
}