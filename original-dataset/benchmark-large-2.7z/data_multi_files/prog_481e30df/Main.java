public class Main {
    public static void main(String[] args) {
        Course course = new Course("Mathematics");
        Student student1 = new Student("Alice");
        Student student2 = new Student("Bob");

        student1.addGrade(60);
        student1.addGrade(45);
        student2.addGrade(75);
        student2.addGrade(30);

        course.addStudent(student1);
        course.addStudent(student2);

        // Additional operations
        for (Student student : course.getStudents()) {
            System.out.println("Grades for " + student.getGrades());
        }

        // Final read from DoubleAdderWrapper
        /* read */ double totalIncrements = student1.getAdderWrapper().getSum();
        System.out.println("Total increments for Alice: " + totalIncrements);
    }
}