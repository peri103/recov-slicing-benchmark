import java.util.concurrent.atomic.LongAdder;

public class LongAdderWrapper {
    private LongAdder longAdder = new LongAdder();

    public void add(long value) {
        longAdder.add(value);
    }

    public void increment() {
        longAdder.increment();
    }

    public long sum() {
        return longAdder.sum();
    }
}
