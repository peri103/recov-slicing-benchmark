import java.util.concurrent.atomic.DoubleAdder;

public class AdderOperations {
    private DoubleAdder adder = new DoubleAdder();

    public void incrementAdder() {
        /* write */ adder.increment();
    }

    public double getAdderSum() {
        return adder.sum();
    }
}
