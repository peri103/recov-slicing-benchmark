import java.util.concurrent.atomic.DoubleAdder;

public class DoubleAdderUtil {
    private DoubleAdder adder = new DoubleAdder();

    public void increment() {
        /* write */ adder.increment();
    }

    public double getSum() {
        return adder.sum();
    }
}
