import java.util.concurrent.atomic.DoubleAdder;

public class DoubleAdderWrapper {
    private DoubleAdder adder = new DoubleAdder();

    public void incrementAdder() {
        /* write */ adder.increment();
    }

    public double getSum() {
        return adder.sum();
    }
}