import java.util.ArrayList;
import java.util.List;

public class Statistics {
    private List<Double> data = new ArrayList<>();

    public void addData(double value) {
        data.add(value);
    }

    public List<Double> getData() {
        return data;
    }

    public double calculateAverage() {
        double sum = 0;
        for (double value : data) {
            sum += value;
        }
        return data.size() > 0 ? sum / data.size() : 0;
    }
}
