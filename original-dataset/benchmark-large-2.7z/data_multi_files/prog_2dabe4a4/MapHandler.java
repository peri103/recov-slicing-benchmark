import java.util.concurrent.ConcurrentSkipListMap;
import java.util.Map;
import java.util.HashMap;

public class MapHandler {
    private ConcurrentSkipListMap<Integer, String> map;

    public MapHandler() {
        map = new ConcurrentSkipListMap<>();
    }

    public void initializeMap() {
        Map<Integer, String> data = new HashMap<>();
        data.put(1, "One");
        data.put(2, "Two");
        
        /* write */ map.putAll(data);
    }

    public boolean isMapEmpty() {
        /* read */ return map.isEmpty();
    }
}
