public class Main {
    public static void main(String[] args) {
        // Handling students and courses
        Student alice = new Student("Alice", 20);
        Student bob = new Student("Bob", 22);

        Course javaCourse = new Course("Java Programming");
        javaCourse.addStudent(alice);
        javaCourse.addStudent(bob);

        for (Student student : javaCourse.getStudents()) {
            System.out.println("Student: " + student.getName() + ", Age: " + student.getAge());
        }

        // Handling map operations
        MapHandler mapHandler = new MapHandler();
        mapHandler.initializeMap();
        boolean isEmpty = mapHandler.isMapEmpty();
        System.out.println("Is the map empty? " + isEmpty);
    }
}