public class Main {
    public static void main(String[] args) {
        QueueOperations queueOps = new QueueOperations();
        Course course = new Course("Computer Science");
        Student student1 = new Student("Alice");
        Student student2 = new Student("Bob");

        // Add students to the course
        course.addStudent(student1);
        course.addStudent(student2);

        // Add scores to students
        student1.addScore(85);
        student2.addScore(90);

        // Use QueueOperations
        queueOps.addElement(1);
        queueOps.addElement(2);
        queueOps.addElement(3);

        // Retrieve and print scores
        for (Student student : course.getStudents()) {
            System.out.println(student.getName() + "'s scores: " + student.getScores());
        }

        // Read the original element
        /* read */ int value = queueOps.getElement();
        System.out.println("Original Queue element: " + value);

        // Print remaining queue elements
        while (!queueOps.isEmpty()) {
            System.out.println("Queue element: " + queueOps.getElement());
        }
    }
}