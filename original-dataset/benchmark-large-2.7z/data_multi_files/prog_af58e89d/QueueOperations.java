import java.util.LinkedList;
import java.util.Queue;

public class QueueOperations {
    private Queue<Integer> queue = new LinkedList<>();

    public void addElement(int element) {
        /* write */ queue.offer(element);
    }

    public int getElement() {
        return queue.poll();
    }

    public boolean isEmpty() {
        return queue.isEmpty();
    }
}
