import java.util.List;
import java.util.ArrayList;

public class Student {
    private String name;
    private List<Integer> grades;

    public Student(String name) {
        this.name = name;
        this.grades = new ArrayList<>();
    }

    public void addGrade(int grade) {
        this.grades.add(grade);
    }

    public List<Integer> getGrades() {
        return this.grades;
    }

    public String getName() {
        return this.name;
    }
}
