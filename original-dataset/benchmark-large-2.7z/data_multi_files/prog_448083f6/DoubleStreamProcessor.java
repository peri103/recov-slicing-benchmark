import java.util.stream.DoubleStream;

public class DoubleStreamProcessor {
    private DoubleStream stream;

    public DoubleStreamProcessor(double... values) {
        this.stream = DoubleStream.of(values);
    }

    public void boxStream() {
        /* write */ this.stream = this.stream.boxed().mapToDouble(Double::doubleValue);
    }

    public double calculateSum() {
        /* read */ return this.stream.sum();
    }
}
