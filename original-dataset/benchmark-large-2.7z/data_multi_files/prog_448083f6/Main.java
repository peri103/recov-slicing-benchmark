public class Main {
    public static void main(String[] args) {
        // Create a DoubleStreamProcessor and process the stream
        DoubleStreamProcessor processor = new DoubleStreamProcessor(1.0, 2.0, 3.0);
        processor.boxStream();
        double sum = processor.calculateSum();
        System.out.println("Sum of boxed stream: " + sum);

        // Create students and a course
        Student alice = new Student("Alice");
        alice.addGrade(85);
        alice.addGrade(90);

        Student bob = new Student("Bob");
        bob.addGrade(75);
        bob.addGrade(80);

        Course mathCourse = new Course("Mathematics");
        mathCourse.addStudent(alice);
        mathCourse.addStudent(bob);

        // Display course and student information
        System.out.println("Course: " + mathCourse.getCourseName());
        for (Student student : mathCourse.getStudents()) {
            System.out.println("Student: " + student.getName() + ", Grades: " + student.getGrades());
        }
    }
}