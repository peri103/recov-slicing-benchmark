public class Student {
    private String name;
    private AtomicLongArrayWrapper scores;

    public Student(String name, int numberOfScores) {
        this.name = name;
        this.scores = new AtomicLongArrayWrapper(numberOfScores);
    }

    public void setScore(int index, long score) {
        scores.setValue(index, score);
    }

    public long getScore(int index) {
        return scores.getValue(index);
    }

    public String getName() {
        return name;
    }
}
