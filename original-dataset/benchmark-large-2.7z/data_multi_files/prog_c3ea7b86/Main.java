public class Main {
    public static void main(String[] args) {
        Student alice = new Student("Alice", 1);
        alice.setScore(0, 95);

        Course mathCourse = new Course("Mathematics");
        mathCourse.addStudent(alice);

        for (Student student : mathCourse.getStudents()) {
            System.out.println("Student: " + student.getName());
            /* read */ long score = student.getScore(0);
            System.out.println("Score: " + score);
        }
    }
}