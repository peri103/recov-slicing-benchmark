import java.util.concurrent.atomic.AtomicLongArray;

public class AtomicLongArrayWrapper {
    private AtomicLongArray atomicArray;

    public AtomicLongArrayWrapper(int size) {
        atomicArray = new AtomicLongArray(size);
    }

    public void setValue(int index, long value) {
        /* write */ atomicArray.set(index, value);
    }

    public long getValue(int index) {
        return atomicArray.get(index);
    }
}
