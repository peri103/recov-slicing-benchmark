import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        DataStorage storage = new DataStorage();
        Course mathCourse = new Course("Mathematics");
        
        Student student1 = new Student("Alice", 20);
        Student student2 = new Student("Bob", 22);
        
        mathCourse.addStudent(student1);
        mathCourse.addStudent(student2);
        
        for (Student student : mathCourse.getStudents()) {
            System.out.println(student.getName() + ", Age: " + student.getAge());
        }
        
        storage.storeData("studentCount", mathCourse.getStudents().size());
        
        /* read */ int studentCount = storage.retrieveData("studentCount");
        System.out.println("Total students in " + mathCourse.getCourseName() + ": " + studentCount);
    }
}