import java.util.Hashtable;

public class DataStorage {
    private Hashtable<String, Integer> table = new Hashtable<>();

    public void storeData(String key, Integer value) {
        /* write */ table.put(key, value);
    }

    public Integer retrieveData(String key) {
        return table.get(key);
    }
}
