import java.util.concurrent.LinkedTransferQueue;
import java.util.Arrays;

public class QueueOperations {
    private LinkedTransferQueue<Integer> queue = new LinkedTransferQueue<>();

    public QueueOperations() {
        queue.addAll(Arrays.asList(1, 2, 3, 4, 5)); // Initializing the queue with some values
    }

    public void retainElements() {
        /* write */ queue.retainAll(Arrays.asList(2, 3)); // Retain only 2 and 3 in the queue
    }

    public int getQueueSize() {
        return queue.size();
    }

    public LinkedTransferQueue<Integer> getQueue() {
        return queue;
    }
}
