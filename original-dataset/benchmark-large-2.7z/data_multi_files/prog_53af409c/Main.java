public class Main {
    public static void main(String[] args) {
        QueueOperations queueOps = new QueueOperations();
        queueOps.retainElements(); // Perform the write operation

        Student student = new Student("Alice");
        student.updateAttributes("age", 21);
        student.printAttributes();

        /* read */ int size = queueOps.getQueueSize(); // Read the size of the queue
        System.out.println("Queue size after retain operation: " + size);

        for (Integer num : queueOps.getQueue()) {
            System.out.println("Queue element: " + num);
        }
    }
}