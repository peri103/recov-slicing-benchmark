import java.util.HashMap;
import java.util.Map;

public class Student {
    private String name;
    private Map<String, Integer> attributes = new HashMap<>();

    public Student(String name) {
        this.name = name;
        attributes.put("age", 20);
        attributes.put("grade", 3);
    }

    public void updateAttributes(String key, Integer value) {
        attributes.put(key, value);
    }

    public void printAttributes() {
        for (Map.Entry<String, Integer> entry : attributes.entrySet()) {
            System.out.println("Student Attribute - Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }
    }
}
