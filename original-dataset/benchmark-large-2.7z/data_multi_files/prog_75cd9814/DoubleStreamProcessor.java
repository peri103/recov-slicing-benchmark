import java.util.stream.DoubleStream;
import java.util.stream.Stream;

public class DoubleStreamProcessor {
    private DoubleStream doubleStream;

    public DoubleStreamProcessor(DoubleStream doubleStream) {
        this.doubleStream = doubleStream;
    }

    public Stream<Double> processStream() {
        /* write */ return doubleStream.boxed();
    }
}
