import java.util.stream.DoubleStream;

public class Main {
    public static void main(String[] args) {
        // Create a DoubleStreamProcessor and process the stream
        DoubleStreamProcessor processor = new DoubleStreamProcessor(DoubleStream.of(1.0, 2.0, 3.0));
        Stream<Double> boxedStream = processor.processStream();

        // Create a Course and add Students
        Course course = new Course("Mathematics");
        Student student1 = new Student("Alice");
        Student student2 = new Student("Bob");

        student1.addGrade(95.0);
        student2.addGrade(85.5);

        course.addStudent(student1);
        course.addStudent(student2);

        // Print course details
        System.out.println("Course: " + course.getCourseName());
        for (Student student : course.getStudents()) {
            System.out.println("Student: " + student.getName() + ", Grades: " + student.getGrades());
        }

        // Convert the processed stream to an array
        /* read */ Object[] array = boxedStream.toArray();
        
        // Print the elements from the original DoubleStream
        for (Object obj : array) {
            System.out.println(obj);
        }
    }
}