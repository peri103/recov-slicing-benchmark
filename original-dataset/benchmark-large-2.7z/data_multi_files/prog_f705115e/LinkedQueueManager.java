import java.util.concurrent.LinkedBlockingQueue;
import java.util.Arrays;

public class LinkedQueueManager {
    private LinkedBlockingQueue<Integer> linkedQueue = new LinkedBlockingQueue<>();

    public LinkedQueueManager() {
        linkedQueue.addAll(Arrays.asList(10, 20, 30, 40, 50));
    }

    public void modifyQueue() {
        linkedQueue.poll();
        linkedQueue.offer(60);
        linkedQueue.remove(30);
    }

    public int getLinkedQueueSize() {
        return linkedQueue.size();
    }

    public void displayLinkedQueueElements() {
        linkedQueue.forEach(num -> {
            System.out.println("LinkedBlockingQueue element: " + num);
        });
    }
}
