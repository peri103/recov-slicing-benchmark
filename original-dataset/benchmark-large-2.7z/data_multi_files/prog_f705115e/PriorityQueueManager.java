import java.util.concurrent.PriorityBlockingQueue;
import java.util.Arrays;

public class PriorityQueueManager {
    private PriorityBlockingQueue<Integer> queue = new PriorityBlockingQueue<>();

    public PriorityQueueManager() {
        queue.addAll(Arrays.asList(1, 2, 3, 4, 5));
    }

    public void retainElements() {
        /* write */ queue.retainAll(Arrays.asList(2, 4));
    }

    public int getQueueSize() {
        return queue.size();
    }

    public void displayQueueElements() {
        queue.forEach(num -> {
            System.out.println("PriorityBlockingQueue element: " + num);
        });
    }
}
