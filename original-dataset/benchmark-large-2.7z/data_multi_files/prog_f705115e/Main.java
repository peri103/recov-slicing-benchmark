public class Main {
    public static void main(String[] args) {
        PriorityQueueManager priorityQueueManager = new PriorityQueueManager();
        LinkedQueueManager linkedQueueManager = new LinkedQueueManager();

        linkedQueueManager.modifyQueue();
        int linkedQueueSize = linkedQueueManager.getLinkedQueueSize();
        System.out.println("LinkedBlockingQueue size: " + linkedQueueSize);
        linkedQueueManager.displayLinkedQueueElements();

        priorityQueueManager.retainElements();
        /* read */ int queueSize = priorityQueueManager.getQueueSize();
        System.out.println("PriorityBlockingQueue size: " + queueSize);
        priorityQueueManager.displayQueueElements();
    }
}