import java.util.List;

public class Main {
    public static void main(String[] args) {
        LongAdderWrapper longAdderWrapper = new LongAdderWrapper();
        longAdderWrapper.addValue(10);
        longAdderWrapper.resetValue();
        longAdderWrapper.addValue(5);

        Course course = new Course("Mathematics");
        Student student1 = new Student("Alice");
        Student student2 = new Student("Bob");

        student1.addScore(85);
        student1.addScore(90);

        student2.addScore(78);
        student2.addScore(82);

        course.addStudent(student1);
        course.addStudent(student2);

        for (Student student : course.getStudents()) {
            System.out.println("Student: " + student.getName());
            System.out.println("Scores: " + student.getScores());
        }

        /* read */ long sum = longAdderWrapper.getSum();
        System.out.println("Sum after reset and adding 5: " + sum);
    }
}