import java.util.concurrent.atomic.LongAdder;

public class LongAdderWrapper {
    private LongAdder longAdder = new LongAdder();

    public void addValue(long value) {
        longAdder.add(value);
    }

    public void resetValue() {
        /* write */ longAdder.reset();
    }

    public long getSum() {
        return longAdder.sum();
    }
}