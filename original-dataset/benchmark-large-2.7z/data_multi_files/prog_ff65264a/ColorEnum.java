public enum ColorEnum {
    RED, GREEN, BLUE, YELLOW, ORANGE
}