import java.util.ArrayList;
import java.util.Random;

public class NumberProcessor {
    private ArrayList<Integer> numbers = new ArrayList<>();
    private Random random = new Random();

    public NumberProcessor(int size) {
        for (int i = 0; i < size; i++) {
            numbers.add(random.nextInt(100));
        }
    }

    public ArrayList<Integer> getNumbers() {
        return numbers;
    }

    public int calculateSum() {
        int sum = 0;
        for (Integer num : numbers) {
            sum += num;
        }
        return sum;
    }
}
