import java.util.Map;
import java.util.HashMap;

public class DataProcessor {
    private Map<String, Integer> dataMap;

    public DataProcessor() {
        dataMap = new HashMap<>();
    }

    public void addData(String key, int value) {
        dataMap.put(key, value);
    }

    public void displayData() {
        for (Map.Entry<String, Integer> entry : dataMap.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }
    }
}
