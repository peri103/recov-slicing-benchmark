import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        DequeOperations dequeOps = new DequeOperations();
        dequeOps.addElement(42);
        
        Course course = new Course("Computer Science");
        Student student1 = new Student("Alice", 20);
        Student student2 = new Student("Bob", 22);
        
        course.addStudent(student1);
        course.addStudent(student2);
        
        Map<String, Integer> studentAges = new HashMap<>();
        for (Student student : course.getStudents()) {
            studentAges.put(student.getName(), student.getAge());
        }
        
        for (Map.Entry<String, Integer> entry : studentAges.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
        
        /* read */ int lastElement = dequeOps.getLastElement();
        System.out.println("Last element in deque: " + lastElement);
    }
}