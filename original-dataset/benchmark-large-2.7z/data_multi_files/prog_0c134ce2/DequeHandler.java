import java.util.concurrent.LinkedBlockingDeque;

public class DequeHandler {
    private LinkedBlockingDeque<Integer> deque;

    public DequeHandler() {
        this.deque = new LinkedBlockingDeque<>();
    }

    public void addElement(int element) {
        /* write */ deque.addLast(element);
    }

    public LinkedBlockingDeque<Integer> getDeque() {
        return deque;
    }
}
