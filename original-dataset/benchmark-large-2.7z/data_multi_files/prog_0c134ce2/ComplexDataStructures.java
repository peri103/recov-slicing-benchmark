import java.util.ArrayList;
import java.util.HashMap;

public class ComplexDataStructures {
    private ArrayList<Integer> list = new ArrayList<>();
    private HashMap<String, Integer> map = new HashMap<>();

    public ComplexDataStructures() {
        list.add(10);
        list.add(20);
        list.add(30);

        map.put("one", 1);
        map.put("two", 2);
        map.put("three", 3);
    }

    public void printListSum() {
        int sum = 0;
        for (int num : list) {
            sum += num;
        }
        System.out.println("Sum of list elements: " + sum);
    }

    public void printMapDetails() {
        for (String key : map.keySet()) {
            System.out.println("Key: " + key + ", Value: " + map.get(key));
        }

        int product = 1;
        for (int num : map.values()) {
            product *= num;
        }
        System.out.println("Product of map values: " + product);
    }
}
