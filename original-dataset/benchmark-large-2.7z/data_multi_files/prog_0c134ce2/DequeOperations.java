import java.util.concurrent.LinkedBlockingDeque;

public class DequeOperations {
    private LinkedBlockingDeque<Integer> deque = new LinkedBlockingDeque<>();

    public void addElement(int element) {
        /* write */ deque.addLast(element);
    }

    public int getLastElement() {
        return deque.getLast();
    }
}
