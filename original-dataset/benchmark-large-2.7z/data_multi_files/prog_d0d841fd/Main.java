import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        try {
            // File operations
            FileOperations fileOps = new FileOperations("example.txt");
            fileOps.writeFile("Hello, World!");

            // Create a course and add students
            Course course = new Course("Java Programming");
            Student alice = new Student("Alice");
            Student bob = new Student("Bob");
            course.addStudent(alice);
            course.addStudent(bob);

            // Display students in the course
            for (Student student : course.getStudents()) {
                System.out.println("Student: " + student.getName());
            }

            // Read file content and size
            String content = fileOps.readFile();
            System.out.println("File Content: " + content);

            long fileSize = fileOps.getFileSize();
            System.out.println("File Size: " + fileSize + " bytes");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}