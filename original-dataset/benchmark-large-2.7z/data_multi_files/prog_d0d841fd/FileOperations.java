import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;

public class FileOperations {
    private Path path;

    public FileOperations(String fileName) {
        this.path = Paths.get(fileName);
    }

    public void writeFile(String content) throws IOException {
        Files.writeString(path, content);
    }

    public String readFile() throws IOException {
        /* write */ return Files.readString(path);
    }

    public long getFileSize() throws IOException {
        /* read */ return Files.size(path);
    }
}
