import java.util.concurrent.SynchronousQueue;

public class Student {
    private String name;
    private StudentScores scores;
    private SynchronousQueue<Integer> queue;

    public Student(String name, SynchronousQueue<Integer> queue) {
        this.name = name;
        this.scores = new StudentScores();
        this.queue = queue;
    }

    public void enrollInCourse(Course course) {
        scores.addCourse(course);
    }

    public void addScore(String courseName, int score) {
        scores.addScore(courseName, score);
    }

    public void submitScoreToQueue(int score) {
        try {
            /* write */ queue.put(score);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public int receiveScoreFromQueue() {
        try {
            /* read */ return queue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
            return -1;
        }
    }

    public void printScores() {
        scores.printScores();
    }
}
