import java.util.HashMap;
import java.util.Map;

public class StudentScores {
    private Map<String, Course> courses = new HashMap<>();

    public void addCourse(Course course) {
        courses.put(course.getName(), course);
    }

    public void addScore(String courseName, int score) {
        Course course = courses.get(courseName);
        if (course != null) {
            course.addScore(score);
        }
    }

    public void printScores() {
        for (Course course : courses.values()) {
            System.out.println("Course: " + course.getName() + ", Scores: " + course.getScores());
        }
    }
}
