import java.util.concurrent.SynchronousQueue;

public class Main {
    public static void main(String[] args) {
        SynchronousQueue<Integer> queue = new SynchronousQueue<>();
        Student student = new Student("John Doe", queue);

        student.enrollInCourse(new Course("Mathematics"));
        student.enrollInCourse(new Course("Physics"));

        student.addScore("Mathematics", 85);
        student.addScore("Physics", 90);

        student.submitScoreToQueue(100); // This will execute the write operation

        student.printScores();

        int valueFromQueue = student.receiveScoreFromQueue(); // This will execute the read operation
        System.out.println("Value from queue: " + valueFromQueue);
    }
}
