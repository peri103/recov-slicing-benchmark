import java.util.concurrent.LinkedBlockingDeque;

public class DequeManager {
    private LinkedBlockingDeque<Integer> deque = new LinkedBlockingDeque<>();

    public void addToDeque(int number) {
        /* write */ deque.addLast(number);
    }

    public int getLastFromDeque() {
        return deque.getLast();
    }
}
