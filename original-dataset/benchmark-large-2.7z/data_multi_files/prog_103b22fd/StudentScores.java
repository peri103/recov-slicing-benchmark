import java.util.concurrent.LinkedBlockingDeque;

public class StudentScores {
    private LinkedBlockingDeque<Integer> scores = new LinkedBlockingDeque<>();

    public void addScore(int score) {
        /* write */ scores.addLast(score);
    }

    public int getLastScore() {
        /* read */ return scores.getLast();
    }
}
