import java.util.HashMap;
import java.util.Map;

public class Student {
    private String name;
    private CustomList scores = new CustomList();
    private Map<String, Integer> gradeMap = new HashMap<>();

    public Student(String name) {
        this.name = name;
    }

    public void addScore(int score) {
        scores.addElement(score);
    }

    public Object[] getScoresArray() {
        return scores.convertToArray();
    }

    public void addGrade(String subject, int grade) {
        gradeMap.put(subject, grade);
    }

    public Map<String, Integer> getGrades() {
        return gradeMap;
    }

    public int getScoresSize() {
        return scores.getSize();
    }
}
