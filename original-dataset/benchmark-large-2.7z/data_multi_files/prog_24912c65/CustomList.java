import java.util.concurrent.CopyOnWriteArrayList;

public class CustomList {
    private CopyOnWriteArrayList<Integer> list = new CopyOnWriteArrayList<>();

    public void addElement(int element) {
        list.add(element);
    }

    public Object[] convertToArray() {
        /* write */ return list.toArray();
    }

    public int getSize() {
        return list.size();
    }
}
