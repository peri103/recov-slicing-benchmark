public class Main {
    public static void main(String[] args) {
        Student student = new Student("John Doe");
        student.addScore(85);
        student.addScore(90);
        student.addScore(75);

        Object[] scoresArray = student.getScoresArray();

        student.addGrade("Math", 90);
        student.addGrade("Science", 85);

        for (Map.Entry<String, Integer> entry : student.getGrades().entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

        for (int i = 0; i < scoresArray.length; i++) {
            System.out.println("Score " + i + ": " + scoresArray[i]);
        }

        int totalScore = 0;
        for (Object score : scoresArray) {
            totalScore += (Integer) score;
        }
        System.out.println("Total Score: " + totalScore);

        /* read */ int size = student.getScoresSize();
        System.out.println("Number of Scores: " + size);
    }
}