import java.util.concurrent.CopyOnWriteArrayList;
import java.util.List;

public class Course {
    private CopyOnWriteArrayList<Integer> grades = new CopyOnWriteArrayList<>();

    public void addGrade(int grade) {
        grades.add(grade);
    }

    public Object[] getGradesArray() {
        /* write */ return grades.toArray();
    }

    public List<Integer> getGrades() {
        return grades;
    }
}
