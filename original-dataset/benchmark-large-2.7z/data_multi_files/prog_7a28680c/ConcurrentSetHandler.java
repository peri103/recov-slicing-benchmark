import java.util.concurrent.ConcurrentSkipListSet;

public class ConcurrentSetHandler {
    private ConcurrentSkipListSet<Integer> set = new ConcurrentSkipListSet<>();

    public void addElement(int element) {
        set.add(element);
    }

    public Object[] convertToArray() {
        /* write */ return set.toArray();
    }

    public int getSetSize() {
        return set.size();
    }
}
