public class Main {
    public static void main(String[] args) {
        ConcurrentSetHandler setHandler = new ConcurrentSetHandler();
        setHandler.addElement(1);
        setHandler.addElement(2);
        setHandler.addElement(3);

        // Convert set to array
        Object[] array = setHandler.convertToArray();

        // Create course and students
        Course course = new Course("Mathematics");
        Student student1 = new Student("Alice", 101);
        Student student2 = new Student("Bob", 102);

        // Enroll students
        course.enrollStudent(student1);
        course.enrollStudent(student2);

        // Print enrolled students
        for (Student student : course.getEnrolledStudents()) {
            System.out.println("Enrolled Student: " + student.getName() + ", ID: " + student.getId());
        }

        // Get set size
        /* read */ int size = setHandler.getSetSize();
        System.out.println("Size of set: " + size);
    }
}