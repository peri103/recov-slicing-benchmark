import java.util.stream.Stream;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Initialize a stream of integers
        Stream<Integer> stream = Stream.of(1, 2, 3, 4, 5);

        // Process the stream using DataProcessor
        DataProcessor processor = new DataProcessor(stream);
        Stream<Integer> doubledStream = processor.processStream();

        // Create a course and add students
        Course course = new Course("Mathematics");
        Student alice = new Student("Alice");
        Student bob = new Student("Bob");

        alice.addGrade(85);
        bob.addGrade(90);

        course.addStudent(alice);
        course.addStudent(bob);

        // Collect the elements of the new stream into a list
        /* read */ List<Integer> doubledList = doubledStream.collect(Collectors.toList());

        // Print the list to verify the result
        System.out.println("Doubled List: " + doubledList);

        // Display course information
        System.out.println("Course: " + course.getTitle());
        for (Student student : course.getStudents()) {
            System.out.println("Student: " + student.getName() + ", Grades: " + student.getGrades());
        }
    }
}