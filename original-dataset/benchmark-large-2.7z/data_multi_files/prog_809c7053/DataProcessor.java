import java.util.stream.Stream;
import java.util.List;
import java.util.stream.Collectors;

public class DataProcessor {
    private Stream<Integer> stream;

    public DataProcessor(Stream<Integer> stream) {
        this.stream = stream;
    }

    public Stream<Integer> processStream() {
        // Use the map method to create a new stream with each element doubled
        /* write */ return stream.map(x -> x * 2);
    }
}
