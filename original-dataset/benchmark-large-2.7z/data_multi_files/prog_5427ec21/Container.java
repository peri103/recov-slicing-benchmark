import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

public class Container {
    volatile String value;

    // Create an AtomicReferenceFieldUpdater for the 'value' field of Container
    private static final AtomicReferenceFieldUpdater<Container, String> updater =
            AtomicReferenceFieldUpdater.newUpdater(Container.class, String.class, "value");

    public void setValue(String newValue) {
        /* write */ updater.set(this, newValue);
    }

    public String getValue() {
        /* read */ return updater.get(this);
    }
}