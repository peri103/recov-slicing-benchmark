public class Student {
    private String name;
    private CollectionHandler scoresHandler = new CollectionHandler();

    public Student(String name) {
        this.name = name;
    }

    public void addScore(int score) {
        scoresHandler.addElement(score);
    }

    public Iterator<Integer> getScoresIterator() {
        return scoresHandler.getIterator();
    }
}
