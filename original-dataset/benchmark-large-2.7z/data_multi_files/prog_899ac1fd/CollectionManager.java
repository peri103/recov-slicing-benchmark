import java.util.AbstractCollection;
import java.util.ArrayList;

public class CollectionManager {
    private AbstractCollection<Integer> collection = new ArrayList<>();

    public void addToCollection(int value) {
        /* write */ collection.add(value);
    }

    public AbstractCollection<Integer> getCollection() {
        return collection;
    }
}
