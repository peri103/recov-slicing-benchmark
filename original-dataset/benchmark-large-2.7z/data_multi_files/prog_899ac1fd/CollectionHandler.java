import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Iterator;

public class CollectionHandler {
    private AbstractCollection<Integer> collection = new ArrayList<>();

    public void addElement(int element) {
        /* write */ collection.add(element);
    }

    public Iterator<Integer> getIterator() {
        return collection.iterator();
    }
}
