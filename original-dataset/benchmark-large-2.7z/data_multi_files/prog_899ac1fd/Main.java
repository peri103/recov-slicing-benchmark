public class Main {
    public static void main(String[] args) {
        Student student = new Student("Alice");
        student.addScore(42);
        
        // Perform some unrelated operations
        int sum = 0;
        for (int i = 1; i <= 5; i++) {
            sum += i;
        }
        System.out.println("Sum of first 5 natural numbers: " + sum);

        // Get scores iterator and read the score
        /* read */ Iterator<Integer> scoresIterator = student.getScoresIterator();
        if (scoresIterator.hasNext()) {
            int score = scoresIterator.next();
            System.out.println("First score: " + score);
        }

        // Another unrelated computation
        int squareSum = 0;
        for (int i = 1; i <= 3; i++) {
            squareSum += i * i;
        }
        System.out.println("Sum of squares of first 3 natural numbers: " + squareSum);
    }
}