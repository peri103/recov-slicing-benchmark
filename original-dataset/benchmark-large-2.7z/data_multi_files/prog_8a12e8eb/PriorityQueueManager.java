import java.util.concurrent.PriorityBlockingQueue;
import java.util.Arrays;

public class PriorityQueueManager {
    private PriorityBlockingQueue<Integer> queue = new PriorityBlockingQueue<>();

    public void addNumbers(Integer... numbers) {
        /* write */ queue.addAll(Arrays.asList(numbers));
    }

    public PriorityBlockingQueue<Integer> getQueue() {
        return queue;
    }
}
