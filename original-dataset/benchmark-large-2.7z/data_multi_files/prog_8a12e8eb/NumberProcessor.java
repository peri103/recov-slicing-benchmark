import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

public class NumberProcessor {
    private Set<Integer> uniqueNumbers = new HashSet<>();

    public void addUniqueNumbers(Integer... numbers) {
        uniqueNumbers.addAll(Arrays.asList(numbers));
    }

    public Set<Integer> getSortedUniqueNumbers() {
        return uniqueNumbers.stream()
                .sorted()
                .collect(Collectors.toSet());
    }

    public int calculateSum(PriorityBlockingQueue<Integer> queue) {
        int sum = 0;
        for (Integer number : queue) {
            sum += number;
        }
        return sum;
    }
}
