import java.util.Set;

public class Main {
    public static void main(String[] args) {
        PriorityQueueManager queueManager = new PriorityQueueManager();
        NumberProcessor processor = new NumberProcessor();

        queueManager.addNumbers(5, 3, 7, 1, 4);
        processor.addUniqueNumbers(10, 3, 7, 8, 1, 5, 9);

        Set<Integer> sortedUniqueNumbers = processor.getSortedUniqueNumbers();
        System.out.println("Sorted Unique Numbers: " + sortedUniqueNumbers);

        queueManager.addNumbers(sortedUniqueNumbers.toArray(new Integer[0]));

        int sum = processor.calculateSum(queueManager.getQueue());
        System.out.println("Sum of elements in the queue: " + sum);

        /* read */ Integer value = queueManager.getQueue().peek();
        System.out.println("Peek value from the queue: " + value);
    }
}