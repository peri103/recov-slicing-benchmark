import java.nio.IntBuffer;

public class BufferReader {
    private IntBuffer buffer;

    public BufferReader(IntBuffer buffer) {
        this.buffer = buffer;
        this.buffer.flip(); // Reset the position of the buffer to read the value
    }

    public int readValue() {
        /* read */ return buffer.get();
    }
}
