import java.nio.IntBuffer;

public class BufferWriter {
    private IntBuffer buffer = IntBuffer.allocate(1);

    public void writeValue(int value) {
        /* write */ buffer.put(value);
    }

    public IntBuffer getBuffer() {
        return buffer;
    }
}
