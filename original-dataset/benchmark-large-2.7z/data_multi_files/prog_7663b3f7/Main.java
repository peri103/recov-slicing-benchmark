import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Initialize the BufferWriter and BufferReader
        BufferWriter writer = new BufferWriter();
        writer.writeValue(42);

        // Create a Course and add Students
        Course course = new Course("Mathematics");
        course.addStudent(new Student("Alice"));
        course.addStudent(new Student("Bob"));

        // Access the students in the course
        ArrayList<Student> students = course.getStudents();
        for (Student student : students) {
            System.out.println("Student in " + course.getCourseName() + ": " + student.getName());
        }

        // Read the value from the buffer
        BufferReader reader = new BufferReader(writer.getBuffer());
        int value = reader.readValue();
        System.out.println("Buffer value: " + value);
    }
}