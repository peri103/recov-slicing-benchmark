public class Main {
    public static void main(String[] args) {
        DequeManager dequeManager = new DequeManager();
        Student student = new Student("Alice");

        student.printScores();
        student.printCourseGrades();

        dequeManager.clearDeque();
        dequeManager.addElementsToDeque();

        for (Integer num : dequeManager.getDeque()) {
            System.out.println("Deque Element: " + num);
        }

        /* read */ boolean isEmpty = dequeManager.isDequeEmpty();
        System.out.println("Is Deque Empty: " + isEmpty);
    }
}