import java.util.concurrent.LinkedBlockingDeque;

public class DequeManager {
    private LinkedBlockingDeque<Integer> deque = new LinkedBlockingDeque<>();

    public DequeManager() {
        deque.add(1); // Adding an element to ensure the deque is not initially empty
    }

    public void clearDeque() {
        /* write */ deque.clear();
    }

    public boolean isDequeEmpty() {
        return deque.isEmpty();
    }

    public void addElementsToDeque() {
        for (int i = 0; i < 5; i++) {
            deque.add(i);
        }
    }

    public LinkedBlockingDeque<Integer> getDeque() {
        return deque;
    }
}
