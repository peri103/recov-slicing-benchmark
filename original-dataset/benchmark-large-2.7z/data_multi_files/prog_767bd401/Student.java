import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Student {
    private String name;
    private ArrayList<Integer> scores = new ArrayList<>();
    private Map<String, Integer> courseGrades = new HashMap<>();

    public Student(String name) {
        this.name = name;
        scores.add(10);
        scores.add(20);
        scores.add(30);
        courseGrades.put("Math", 95);
        courseGrades.put("Science", 88);
        courseGrades.put("History", 92);
    }

    public void printScores() {
        for (int score : scores) {
            System.out.println("Score: " + score);
        }
    }

    public void printCourseGrades() {
        for (Map.Entry<String, Integer> entry : courseGrades.entrySet()) {
            System.out.println("Course: " + entry.getKey() + ", Grade: " + entry.getValue());
        }
    }
}
