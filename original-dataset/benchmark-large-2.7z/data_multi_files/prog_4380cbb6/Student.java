import java.util.concurrent.CopyOnWriteArrayList;

public class Student {
    private String name;
    private CopyOnWriteArrayList<Integer> grades = new CopyOnWriteArrayList<>();

    public Student(String name) {
        this.name = name;
    }

    public void addGrade(int grade) {
        /* write */ grades.add(grade);
    }

    public Integer getGrade(int index) {
        return grades.get(index);
    }

    public String getName() {
        return name;
    }
}
