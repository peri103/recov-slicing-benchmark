import java.util.concurrent.CopyOnWriteArrayList;

public class Main {
    public static void main(String[] args) {
        Student student1 = new Student("Alice");
        Student student2 = new Student("Bob");

        Course course = new Course("Math 101");
        course.enrollStudent(student1);
        course.enrollStudent(student2);

        student1.addGrade(95);
        student2.addGrade(88);

        for (Student student : course.getStudents()) {
            System.out.println("Student: " + student.getName());
            /* read */ Integer grade = student.getGrade(0);
            System.out.println("Grade: " + grade);
        }
    }
}