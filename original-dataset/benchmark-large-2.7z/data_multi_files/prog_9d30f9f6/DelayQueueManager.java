import java.util.concurrent.DelayQueue;

public class DelayQueueManager {
    private DelayQueue<DelayedElement> queue = new DelayQueue<>();

    public void addElement(DelayedElement element) {
        queue.add(element);
    }

    public void removeElement(DelayedElement element) {
        /* write */ queue.remove(element);
    }

    public DelayedElement peekElement() {
        return queue.peek();
    }
}