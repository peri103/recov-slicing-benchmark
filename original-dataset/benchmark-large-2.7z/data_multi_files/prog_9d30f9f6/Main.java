import java.util.concurrent.TimeUnit;

public class Main {
    public static void main(String[] args) {
        DelayQueueManager queueManager = new DelayQueueManager();
        DelayedElement element = new DelayedElement(1000);

        queueManager.addElement(element);
        queueManager.removeElement(element);

        // Simulate some processing
        for (int i = 0; i < 1000000; i++) {
            double dummy = Math.sin(i) * Math.cos(i);
        }

        /* read */ DelayedElement peekedElement = queueManager.peekElement();

        // This should print "null" because the element was removed
        System.out.println(peekedElement);

        // Additional complexity with Student and Course
        Student student1 = new Student("Alice", 1);
        Student student2 = new Student("Bob", 2);

        Course course = new Course("Computer Science");
        course.enrollStudent(student1);
        course.enrollStudent(student2);

        for (Student student : course.getEnrolledStudents()) {
            System.out.println("Enrolled student: " + student.getName() + ", ID: " + student.getId());
        }
    }
}