import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Student student1 = new Student("John");
        Student student2 = new Student("Jane");

        ArrayList<Integer> keysToRetain = new ArrayList<>();
        keysToRetain.add(1);
        keysToRetain.add(3);

        student1.getCourse().retainGrades(keysToRetain);

        student1.getCourse().displayGrades();
        int gradeCount = student1.getCourse().getGradeCount();
        System.out.println("Number of grades retained for " + student1.getName() + ": " + gradeCount);

        student2.getCourse().displayGrades();
    }
}