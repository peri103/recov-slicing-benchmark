import java.util.concurrent.ConcurrentSkipListMap;
import java.util.Collection;
import java.util.ArrayList;

public class Course {
    private ConcurrentSkipListMap<Integer, String> grades = new ConcurrentSkipListMap<>();

    public Course() {
        grades.put(1, "A");
        grades.put(2, "B");
        grades.put(3, "C");
    }

    public void retainGrades(Collection<Integer> keysToRetain) {
        /* write */ grades.keySet().retainAll(keysToRetain);
    }

    public int getGradeCount() {
        /* read */ return grades.size();
    }

    public void displayGrades() {
        for (Integer key : grades.keySet()) {
            System.out.println("Grade for student " + key + ": " + grades.get(key));
        }
    }
}
