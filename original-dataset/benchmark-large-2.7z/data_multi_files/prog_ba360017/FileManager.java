import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;

public class FileManager {
    private Path filePath;

    public FileManager(String fileName) {
        this.filePath = Paths.get(fileName);
    }

    public void writeFile(String content) {
        try {
            /* write */ Files.write(filePath, content.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String readFile() {
        try {
            /* read */ byte[] bytes = Files.readAllBytes(filePath);
            return new String(bytes);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
