public class Main {
    public static void main(String[] args) {
        // Initialize FileManager for file operations
        FileManager fileManager = new FileManager("example.txt");

        // Write content to file
        fileManager.writeFile("Hello, World!");

        // Initialize a student and courses
        Student student = new Student("Alice");
        Course math = new Course("Mathematics", 3);
        Course science = new Course("Science", 4);

        // Enroll student in courses
        student.enrollCourse(math);
        student.enrollCourse(science);

        // Display student and courses information
        System.out.println("Student: " + student.getName());
        for (Course course : student.getCourses()) {
            System.out.println("Enrolled in: " + course.getCourseName() + " (" + course.getCredits() + " credits)");
        }

        // Read content from file
        String content = fileManager.readFile();
        System.out.println("File content: " + content);
    }
}