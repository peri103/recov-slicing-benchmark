import java.util.concurrent.SynchronousQueue;

public class Main {
    public static void main(String[] args) {
        SynchronousQueue<Integer> syncQueue = new SynchronousQueue<>();
        
        // Create writer and reader objects for SynchronousQueue
        SyncQueueWriter writer = new SyncQueueWriter(syncQueue);
        SyncQueueReader reader = new SyncQueueReader(syncQueue);

        // Create a new thread for reading from the queue
        new Thread(() -> reader.peekValue()).start();

        // Offer a value to the queue
        writer.offerValue(42);

        // Create a course and add students
        Course course = new Course("Physics 101");
        Student alice = new Student("Alice");
        Student bob = new Student("Bob");
        course.addStudent(alice);
        course.addStudent(bob);

        // Add scores for students
        alice.addScore(85);
        bob.addScore(90);

        // Print course details
        System.out.println("Course: " + course.getCourseName());
        for (Student student : course.getStudents()) {
            System.out.println("Student: " + student.getName() + ", Scores: " + student.getScores());
        }
    }
}