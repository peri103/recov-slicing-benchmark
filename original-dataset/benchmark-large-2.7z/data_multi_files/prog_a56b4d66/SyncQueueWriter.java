import java.util.concurrent.SynchronousQueue;

public class SyncQueueWriter {
    private SynchronousQueue<Integer> queue;

    public SyncQueueWriter(SynchronousQueue<Integer> queue) {
        this.queue = queue;
    }

    public void offerValue(int value) {
        /* write */ queue.offer(value); // This will return immediately since there is no consumer
        System.out.println("Value offered to SynchronousQueue: " + value);
    }
}
