import java.util.concurrent.SynchronousQueue;

public class SyncQueueReader {
    private SynchronousQueue<Integer> queue;

    public SyncQueueReader(SynchronousQueue<Integer> queue) {
        this.queue = queue;
    }

    public void peekValue() {
        try {
            // Wait for the writer thread to perform the offer operation
            Thread.sleep(1000);
            /* read */ Integer value = queue.peek(); // This will return null as peek doesn't wait
            System.out.println("Peeked value from SynchronousQueue: " + value); // Expected to print null
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
