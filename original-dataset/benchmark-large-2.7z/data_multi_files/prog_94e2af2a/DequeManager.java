import java.util.concurrent.LinkedBlockingDeque;

public class DequeManager {
    private LinkedBlockingDeque<Integer> deque = new LinkedBlockingDeque<>();

    public DequeManager() {
        // Initialize the deque with some elements
        deque.add(1);
        deque.add(2);
        deque.add(3);
    }

    public void clearDeque() {
        /* write */ deque.clear();
    }

    public boolean isDequeEmpty() {
        return deque.isEmpty();
    }

    public void addElement(int element) {
        deque.add(element);
    }

    public int removeElement() {
        return deque.poll();
    }
}
