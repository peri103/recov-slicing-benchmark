public class Main {
    public static void main(String[] args) {
        DequeManager dequeManager = new DequeManager();

        // Perform operations on the deque
        dequeManager.addElement(4);
        dequeManager.addElement(5);

        // Create a course and add students
        Course course = new Course("Mathematics");
        Student student1 = new Student("Alice");
        Student student2 = new Student("Bob");

        student1.addGrade(85);
        student2.addGrade(90);

        course.addStudent(student1);
        course.addStudent(student2);

        // Clear the deque
        dequeManager.clearDeque();

        // Display students and their grades
        for (Student student : course.getStudents()) {
            System.out.println("Student: " + student.getName() + ", Grades: " + student.getGrades());
        }

        /* read */ boolean isEmpty = dequeManager.isDequeEmpty();
        System.out.println("Deque is empty: " + isEmpty);

        // Additional deque operations
        if (!isEmpty) {
            while (!dequeManager.isDequeEmpty()) {
                System.out.println("Removed from deque: " + dequeManager.removeElement());
            }
        }
    }
}