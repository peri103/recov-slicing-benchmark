import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

public class Person {
    private volatile String name;
    private static final AtomicReferenceFieldUpdater<Person, String> nameUpdater = AtomicReferenceFieldUpdater.newUpdater(Person.class, String.class, "name");

    public void setName(String newName) {
        nameUpdater.set(this, newName);
    }

    public String getName() {
        return nameUpdater.get(this);
    }
}
