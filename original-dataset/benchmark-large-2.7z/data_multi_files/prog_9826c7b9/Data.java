import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;

public class Data {
    volatile int value;
    private static final AtomicIntegerFieldUpdater<Data> intUpdater = AtomicIntegerFieldUpdater.newUpdater(Data.class, "value");

    public void setValue(int newValue) {
        /* write */ intUpdater.set(this, newValue);
    }

    public int getValue() {
        return intUpdater.get(this);
    }
}
