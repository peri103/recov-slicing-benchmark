public class Main {
    public static void main(String[] args) {
        Data data = new Data();
        Person person = new Person();

        person.setName("John Doe");
        System.out.println("Person Name: " + person.getName());

        data.setValue(42);
        System.out.println("Data value set.");

        // Simulate delay or other operations
        for (int i = 0; i < 3; i++) {
            System.out.println("Processing step " + i);
        }

        /* read */ int value = data.getValue();
        System.out.println("Final value: " + value);

        // More complex logic
        String finalName = person.getName();
        if (finalName != null) {
            System.out.println("Final name: " + finalName);
        }
    }
}