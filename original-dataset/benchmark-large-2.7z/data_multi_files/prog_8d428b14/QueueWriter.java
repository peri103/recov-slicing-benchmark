import java.util.concurrent.SynchronousQueue;

public class QueueWriter {
    private SynchronousQueue<Integer> synchronousQueue;

    public QueueWriter(SynchronousQueue<Integer> queue) {
        this.synchronousQueue = queue;
    }

    public void writeValue(int value) {
        /* write */ synchronousQueue.offer(value);
        System.out.println("Offered " + value + " to SynchronousQueue");
    }
}