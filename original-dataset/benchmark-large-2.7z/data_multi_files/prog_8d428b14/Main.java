import java.util.concurrent.SynchronousQueue;

public class Main {
    public static void main(String[] args) {
        // Initialize the SynchronousQueue
        SynchronousQueue<Integer> queue = new SynchronousQueue<>();

        // Create QueueWriter and QueueReader
        QueueWriter writer = new QueueWriter(queue);
        QueueReader reader = new QueueReader(queue);

        // Start threads for writing and reading
        Thread writerThread = new Thread(() -> {
            writer.writeValue(42);
        });

        Thread readerThread = new Thread(() -> {
            reader.readValue();
        });

        writerThread.start();
        readerThread.start();

        // Wait for threads to finish
        try {
            writerThread.join();
            readerThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Additional code for Course and Student
        Course course = new Course("Mathematics");
        Student student1 = new Student("Alice", 20);
        Student student2 = new Student("Bob", 22);

        course.enrollStudent(student1);
        course.enrollStudent(student2);

        for (Student student : course.getEnrolledStudents()) {
            System.out.println("Student: " + student.getName() + ", Age: " + student.getAge());
        }
    }
}