import java.util.concurrent.SynchronousQueue;

public class QueueReader {
    private SynchronousQueue<Integer> synchronousQueue;

    public QueueReader(SynchronousQueue<Integer> queue) {
        this.synchronousQueue = queue;
    }

    public void readValue() {
        try {
            // Simulate some processing
            Thread.sleep(100);
            /* read */ Integer value = synchronousQueue.peek();
            System.out.println("Peeked value from SynchronousQueue: " + value);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}