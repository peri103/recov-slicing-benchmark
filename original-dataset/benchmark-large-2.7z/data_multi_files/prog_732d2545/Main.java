import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        CustomQueue customQueue = new CustomQueue();
        customQueue.addElements(5, 3, 8, 1, 4);

        Course course = new Course("Computer Science");
        course.addStudent(new Student("Alice", 1));
        course.addStudent(new Student("Bob", 2));

        for (Student student : course.getStudents()) {
            System.out.println("Student Name: " + student.getName() + ", ID: " + student.getId());
        }

        HashMap<String, Integer> map = new HashMap<>();
        map.put("one", 1);
        map.put("two", 2);
        map.put("three", 3);

        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }

        /* read */ Integer smallestElement = customQueue.peekElement();
        System.out.println("The smallest element in the custom queue: " + smallestElement);
    }
}