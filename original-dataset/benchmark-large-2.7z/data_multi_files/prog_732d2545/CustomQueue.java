import java.util.concurrent.PriorityBlockingQueue;
import java.util.Arrays;

public class CustomQueue {
    private PriorityBlockingQueue<Integer> queue = new PriorityBlockingQueue<>();

    public void addElements(Integer... elements) {
        /* write */ queue.addAll(Arrays.asList(elements));
    }

    public Integer peekElement() {
        return queue.peek();
    }
}
