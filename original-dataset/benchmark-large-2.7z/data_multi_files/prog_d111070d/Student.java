import java.util.Optional;

public class Student {
    private String name;
    private Optional<Integer> grade;

    public Student(String name) {
        this.name = name;
    }

    public void setGrade(int grade) {
        /* write */ this.grade = Optional.of(grade);
    }

    public Optional<Integer> getGrade() {
        return grade;
    }

    public String getName() {
        return name;
    }
}
