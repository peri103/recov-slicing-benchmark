import java.util.List;

public class Main {
    public static void main(String[] args) {
        Student student1 = new Student("Alice");
        Student student2 = new Student("Bob");
        student1.setGrade(85);
        student2.setGrade(90);

        Course course = new Course("Mathematics");
        course.addStudent(student1);
        course.addStudent(student2);

        List<Student> students = course.getStudents();
        for (Student student : students) {
            System.out.println("Student: " + student.getName());
        }

        /* read */ int aliceGrade = student1.getGrade().orElse(0);
        System.out.println("Alice's Grade: " + aliceGrade);
    }
}