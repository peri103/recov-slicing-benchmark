import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class FileManager {
    private Path filePath;
    private String content;

    public FileManager(String fileName, String content) {
        this.filePath = Paths.get(fileName);
        this.content = content;
    }

    public void writeFile() throws IOException {
        /* write */ Files.write(filePath, content.getBytes(StandardCharsets.UTF_8));
    }

    public Path getFilePath() {
        return filePath;
    }
}
