import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        try {
            // File operations
            FileManager fileManager = new FileManager("example.txt", "Hello, World!");
            fileManager.writeFile();

            FileSizeReader fileSizeReader = new FileSizeReader();
            long size = fileSizeReader.readFileSize(fileManager.getFilePath());
            System.out.println("File size: " + size + " bytes");

            // Student and Course operations
            Student student1 = new Student("Alice", 101);
            Student student2 = new Student("Bob", 102);

            Course course = new Course("Computer Science");
            course.enrollStudent(student1);
            course.enrollStudent(student2);

            for (Student student : course.getEnrolledStudents()) {
                System.out.println("Student Name: " + student.getName() + ", ID: " + student.getStudentId());
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}