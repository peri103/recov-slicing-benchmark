import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;

public class FileSizeReader {
    public long readFileSize(Path filePath) throws IOException {
        /* read */ return Files.size(filePath);
    }
}
