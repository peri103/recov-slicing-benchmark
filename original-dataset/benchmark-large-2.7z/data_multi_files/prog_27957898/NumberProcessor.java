import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class NumberProcessor {
    private List<Integer> numbers;

    public NumberProcessor(List<Integer> numbers) {
        this.numbers = numbers;
    }

    public int calculateSum() {
        Stream<Integer> numberStream = numbers.stream();
        /* write */
        return numberStream.reduce(0, Integer::sum);
    }

    public List<Integer> collectNumbers() {
        Stream<Integer> newNumberStream = numbers.stream();
        /* read */
        return newNumberStream.collect(Collectors.toList());
    }
}
