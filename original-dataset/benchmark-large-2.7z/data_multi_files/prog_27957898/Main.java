import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Create a student and add grades
        Student student = new Student("John Doe");
        student.addGrade(85);
        student.addGrade(90);
        student.addGrade(78);

        // Process numbers using NumberProcessor
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);
        NumberProcessor processor = new NumberProcessor(numbers);

        int sum = processor.calculateSum();
        System.out.println("Sum of numbers: " + sum);

        List<Integer> collectedNumbers = processor.collectNumbers();
        System.out.println("Collected Numbers: " + collectedNumbers);

        // Display student's grades
        System.out.println("Student Grades: " + student.getGrades());
    }
}