import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingDeque;

public class DequeManager {
    private BlockingDeque<Integer> deque = new LinkedBlockingDeque<>();

    public void addElement(int element) {
        /* write */ deque.addFirst(element);
    }

    public BlockingDeque<Integer> getDeque() {
        return deque;
    }
}
