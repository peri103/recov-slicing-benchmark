public class Main {
    public static void main(String[] args) {
        // Initialize DequeManager and add element
        DequeManager manager = new DequeManager();
        manager.addElement(42);

        // Initialize DequeReader and read element
        DequeReader reader = new DequeReader(manager.getDeque());
        try {
            int value = reader.readElement();
            System.out.println("Read from deque: " + value);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Create a Course and add Students
        Course course = new Course("Computer Science");
        course.addStudent(new Student("Alice"));
        course.addStudent(new Student("Bob"));

        // List students in the course
        for (Student student : course.getStudents()) {
            System.out.println("Student: " + student.getName());
        }
    }
}