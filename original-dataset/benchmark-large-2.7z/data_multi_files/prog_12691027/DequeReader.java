import java.util.concurrent.BlockingDeque;

public class DequeReader {
    private BlockingDeque<Integer> deque;

    public DequeReader(BlockingDeque<Integer> deque) {
        this.deque = deque;
    }

    public int readElement() throws InterruptedException {
        /* read */ return deque.takeFirst();
    }
}
