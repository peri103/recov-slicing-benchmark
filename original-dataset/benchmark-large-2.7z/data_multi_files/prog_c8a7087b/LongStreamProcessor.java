import java.util.stream.LongStream;
import java.util.stream.Collectors;
import java.util.List;

public class LongStreamProcessor {
    private LongStream stream;

    public LongStreamProcessor(LongStream stream) {
        this.stream = stream;
    }

    public LongStream processStream() {
        /* write */ return stream.flatMap(n -> LongStream.of(n, n * n));
    }
}
