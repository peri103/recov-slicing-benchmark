import java.util.stream.LongStream;
import java.util.stream.Collectors;
import java.util.List;

public class LongStreamCollector {
    public List<Long> collect(LongStream stream) {
        /* read */ return stream.boxed().collect(Collectors.toList());
    }
}
