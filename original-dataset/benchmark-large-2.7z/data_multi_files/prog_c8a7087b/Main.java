import java.util.stream.LongStream;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        LongStreamProcessor processor = new LongStreamProcessor(LongStream.of(1, 2, 3, 4));
        LongStream modifiedStream = processor.processStream();

        LongStreamCollector collector = new LongStreamCollector();
        List<Long> result = collector.collect(modifiedStream);

        System.out.println("Modified stream result: " + result);

        // Additional code with Student and Course classes
        Student student = new Student("John Doe");
        Course math = new Course("Mathematics");
        Course science = new Course("Science");

        student.enrollInCourse(math);
        student.enrollInCourse(science);

        System.out.println("Student: " + student.getName());
        System.out.println("Enrolled courses:");
        for (Course course : student.getCourses()) {
            System.out.println(course.getCourseName());
        }
    }
}