import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;

public class FileManager {
    private Path path;

    public FileManager(String fileName) {
        this.path = Paths.get(fileName);
    }

    public void createFile() throws IOException {
        /* write */ Files.createFile(path);
    }

    public boolean fileExists() {
        /* read */ return Files.exists(path);
    }

    public void deleteFile() throws IOException {
        Files.delete(path);
    }
}
