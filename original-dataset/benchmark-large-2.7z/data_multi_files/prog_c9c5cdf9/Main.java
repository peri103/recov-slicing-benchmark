import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        FileManager fileManager = new FileManager("example.txt");
        try {
            fileManager.createFile();

            Student student1 = new Student("Alice");
            Student student2 = new Student("Bob");
            student1.addScore(95);
            student2.addScore(88);

            Course course = new Course("Mathematics");
            course.addStudent(student1);
            course.addStudent(student2);

            for (Student student : course.getStudents()) {
                System.out.println("Student: " + student.getName());
                for (int score : student.getScores()) {
                    System.out.println("Score: " + score);
                }
            }

            boolean fileExists = fileManager.fileExists();
            System.out.println("File exists: " + fileExists);

            fileManager.deleteFile();

        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
}