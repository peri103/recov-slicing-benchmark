import java.io.IOException;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        try {
            // Initialize FileManager and FileChecker
            FileManager fileManager = new FileManager();
            FileChecker fileChecker = new FileChecker();

            // Write lines to the temporary file
            fileManager.writeLines(Arrays.asList("Line 1", "Line 2", "Line 3"));

            // Check if the file exists
            boolean exists = fileChecker.checkFileExists(fileManager.getTempFile());
            System.out.println("Temp file exists: " + exists);

            // Read and print lines from the file
            for (String line : fileManager.readLines()) {
                System.out.println(line);
            }

            // Create a course and add students
            Course course = new Course("Computer Science");
            course.addStudent(new Student("Alice", 1));
            course.addStudent(new Student("Bob", 2));

            // Print student details
            for (Student student : course.getStudents()) {
                System.out.println("Student Name: " + student.getName() + ", ID: " + student.getId());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}