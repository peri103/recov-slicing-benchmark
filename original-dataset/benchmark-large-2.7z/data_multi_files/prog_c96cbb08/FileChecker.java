import java.nio.file.Files;
import java.nio.file.Path;

public class FileChecker {
    public boolean checkFileExists(Path path) {
        // Check if the file exists
        /* read */ return Files.exists(path);
    }
}
