import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;
import java.util.List;
import java.nio.charset.StandardCharsets;

public class FileManager {
    private Path tempFile;

    public FileManager() throws IOException {
        // Create a temporary file
        /* write */ tempFile = Files.createTempFile("temp", ".txt");
    }

    public Path getTempFile() {
        return tempFile;
    }

    public void writeLines(List<String> lines) throws IOException {
        Files.write(tempFile, lines, StandardCharsets.UTF_8);
    }

    public List<String> readLines() throws IOException {
        return Files.readAllLines(tempFile, StandardCharsets.UTF_8);
    }
}
