import java.nio.file.Paths;
import java.nio.file.Path;
import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        Path filePath = Paths.get("example.txt");
        
        try {
            // Create a file for demonstration
            Files.createFile(filePath);

            // Initialize file attribute handler and reader
            FileAttributeHandler attributeHandler = new FileAttributeHandler(filePath);
            FileAttributeReader attributeReader = new FileAttributeReader(filePath);

            // Set the last modified time attribute
            attributeHandler.setLastModifiedTime();

            // Perform some unrelated operations with Course and Student
            Course course = new Course("Computer Science");
            Student student1 = new Student("Alice", 1);
            Student student2 = new Student("Bob", 2);

            course.addStudent(student1);
            course.addStudent(student2);

            for (Student student : course.getStudents()) {
                System.out.println("Student: " + student.getName() + ", ID: " + student.getId());
            }

            // Get the last modified time attribute
            Object attributeValue = attributeReader.getLastModifiedTime();
            System.out.println("Last Modified Time: " + attributeValue);

            // Clean up: Delete the file after demonstration
            Files.delete(filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}