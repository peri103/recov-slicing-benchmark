import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;

public class FileAttributeReader {
    private Path filePath;

    public FileAttributeReader(Path filePath) {
        this.filePath = filePath;
    }

    public Object getLastModifiedTime() throws IOException {
        /* read */ return Files.getAttribute(filePath, "basic:lastModifiedTime");
    }
}
