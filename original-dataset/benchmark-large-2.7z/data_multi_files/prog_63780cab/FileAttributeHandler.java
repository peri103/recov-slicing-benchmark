import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;

public class FileAttributeHandler {
    private Path filePath;

    public FileAttributeHandler(Path filePath) {
        this.filePath = filePath;
    }

    public void setLastModifiedTime() throws IOException {
        /* write */ Files.setAttribute(filePath, "basic:lastModifiedTime", Files.getLastModifiedTime(filePath));
    }
}
