import java.util.HashSet;
import java.util.Set;

public class CourseMaterials {
    private Set<String> materials = new HashSet<>();

    public void addMaterial(String material) {
        /* write */ materials.add(material);
    }

    public Set<String> getMaterials() {
        return materials;
    }
}
