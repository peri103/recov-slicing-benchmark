import java.util.Set;
import java.util.TreeSet;

public class StringSet {
    private Set<String> stringSet = new TreeSet<>();

    public void addString(String value) {
        stringSet.add(value);
    }

    public boolean containsString(String value) {
        return stringSet.contains(value);
    }

    public void removeString(String value) {
        stringSet.remove(value);
    }

    public int size() {
        return stringSet.size();
    }
}
