import java.util.Set;
import java.util.HashSet;

public class DoubleSet {
    private Set<Double> doubleSet = new HashSet<>();

    public void addDouble(double value) {
        doubleSet.add(value);
    }

    public boolean containsDouble(double value) {
        return doubleSet.contains(value);
    }

    public void removeDouble(double value) {
        doubleSet.remove(value);
    }

    public int size() {
        return doubleSet.size();
    }
}
