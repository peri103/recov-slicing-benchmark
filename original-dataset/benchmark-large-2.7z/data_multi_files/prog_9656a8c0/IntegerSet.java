import java.util.AbstractSet;
import java.util.HashSet;

public class IntegerSet {
    private AbstractSet<Integer> set = new HashSet<>();

    public void addInteger(int value) {
        /* write */ set.add(value);
    }

    public boolean containsInteger(int value) {
        return set.contains(value);
    }

    public int size() {
        return set.size();
    }

    public AbstractSet<Integer> getSet() {
        return set;
    }
}
