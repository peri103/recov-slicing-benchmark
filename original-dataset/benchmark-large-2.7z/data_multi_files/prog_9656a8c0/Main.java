import java.util.Set;

public class Main {
    public static void main(String[] args) {
        Course course = new Course("Computer Science");
        course.addMaterial("Introduction to Algorithms");
        course.addMaterial("Design Patterns");
        
        Set<String> materials = course.getMaterials();
        /* read */ boolean containsMaterial = materials.contains("Introduction to Algorithms");
        System.out.println("Contains 'Introduction to Algorithms': " + containsMaterial);

        // Adding more materials
        course.addMaterial("Data Structures");
        course.addMaterial("Operating Systems");

        // Display all materials
        System.out.println("Course Materials:");
        for (String material : materials) {
            System.out.println(material);
        }
    }
}