import java.util.ArrayList;

public class DataProcessor {
    private ArrayList<Integer> dataList = new ArrayList<>();

    public void addData(int data) {
        dataList.add(data);
    }

    public ArrayList<Integer> getDataList() {
        return dataList;
    }

    public int calculateSum() {
        int sum = 0;
        for (Integer num : dataList) {
            sum += num;
        }
        return sum;
    }
}
