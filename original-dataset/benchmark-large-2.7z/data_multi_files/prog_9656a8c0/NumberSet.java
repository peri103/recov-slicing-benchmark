import java.util.AbstractSet;
import java.util.HashSet;

public class NumberSet {
    private AbstractSet<Integer> set = new HashSet<>();

    public void addNumber(int number) {
        /* write */ set.add(number);
    }

    public boolean containsNumber(int number) {
        return set.contains(number);
    }

    public AbstractSet<Integer> getSet() {
        return set;
    }
}
