import java.util.Set;

public class Course {
    private String courseName;
    private CourseMaterials courseMaterials = new CourseMaterials();

    public Course(String courseName) {
        this.courseName = courseName;
    }

    public void addMaterial(String material) {
        courseMaterials.addMaterial(material);
    }

    public Set<String> getMaterials() {
        return courseMaterials.getMaterials();
    }
}
