import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        QueueHandler queueHandler = new QueueHandler();
        queueHandler.addValue(10);

        Course course = new Course("Mathematics");
        Student student = new Student("Alice");
        student.addGrade(95);
        course.enrollStudent(student);

        Student retrievedStudent = course.getStudent("Alice");
        ArrayList<Integer> grades = retrievedStudent.getGrades();
        for (int grade : grades) {
            System.out.println("Grade: " + grade);
        }

        Integer queueValue = queueHandler.getValue();
        System.out.println("Queue value: " + queueValue);

        // Further processing with the retrieved queue value
        for (int i = 0; i < grades.size(); i++) {
            grades.set(i, grades.get(i) + queueValue);
        }

        // Display updated grades
        for (int grade : grades) {
            System.out.println("Updated Grade: " + grade);
        }
    }
}