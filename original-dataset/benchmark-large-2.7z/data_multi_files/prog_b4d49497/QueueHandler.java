import java.util.concurrent.SynchronousQueue;

public class QueueHandler {
    private SynchronousQueue<Integer> queue = new SynchronousQueue<>();

    public void addValue(int value) {
        try {
            /* write */ queue.put(value);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public Integer getValue() {
        /* read */ return queue.poll();
    }
}
