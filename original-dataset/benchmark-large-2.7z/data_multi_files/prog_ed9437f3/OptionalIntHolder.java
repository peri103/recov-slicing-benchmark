import java.util.OptionalInt;

public class OptionalIntHolder {
    private OptionalInt optionalInt;

    public void setOptionalInt(int value) {
        /* write */ optionalInt = OptionalInt.of(value);
    }

    public OptionalInt getOptionalInt() {
        return optionalInt;
    }
}
