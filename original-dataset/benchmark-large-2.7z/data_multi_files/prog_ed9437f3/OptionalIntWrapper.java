import java.util.OptionalInt;

public class OptionalIntWrapper {
    private OptionalInt optionalInt;

    public void setIntValue(int value) {
        /* write */ optionalInt = OptionalInt.of(value);
    }

    public OptionalInt getOptionalInt() {
        return optionalInt;
    }
}
