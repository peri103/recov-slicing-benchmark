import java.util.OptionalInt;

public class OptionalValue {
    private OptionalInt optionalInt;

    public void setValue(int value) {
        /* write */ optionalInt = OptionalInt.of(value);
    }

    public OptionalInt getValue() {
        return optionalInt;
    }
}
