import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Create a new course
        Course course = new Course("Mathematics");

        // Create students
        Student alice = new Student("Alice");
        Student bob = new Student("Bob");

        // Add grades to students
        alice.addGrade(85);
        bob.addGrade(90);

        // Add students to the course
        course.addStudent(alice);
        course.addStudent(bob);

        // Create OptionalIntWrapper and set a value
        OptionalIntWrapper optionalIntWrapper = new OptionalIntWrapper();
        optionalIntWrapper.setIntValue(42);

        // Perform operations with course and students
        for (Student student : course.getStudents()) {
            System.out.println("Student: " + student.getName());
            System.out.println("Grades: " + student.getGrades());
        }

        // Access the value from the OptionalIntWrapper
        /* read */ int value = optionalIntWrapper.getOptionalInt().getAsInt();
        System.out.println("Read value: " + value);
    }
}