import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileTime;
import java.io.IOException;

public class FileAttributes {
    private Path filePath;

    public FileAttributes(Path filePath) {
        this.filePath = filePath;
    }

    public void setLastModifiedTime() throws IOException {
        FileTime fileTime = FileTime.fromMillis(System.currentTimeMillis());
        /* write */ Files.setAttribute(filePath, "basic:lastModifiedTime", fileTime);
    }
}
