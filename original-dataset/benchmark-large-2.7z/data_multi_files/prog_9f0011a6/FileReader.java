import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileTime;
import java.io.IOException;
import java.util.List;
import java.nio.charset.StandardCharsets;

public class FileReader {
    private Path filePath;

    public FileReader(Path filePath) {
        this.filePath = filePath;
    }

    public List<String> readFileContent() throws IOException {
        return Files.readAllLines(filePath, StandardCharsets.UTF_8);
    }

    public FileTime getLastModifiedTime() throws IOException {
        /* read */ return (FileTime) Files.getAttribute(filePath, "basic:lastModifiedTime");
    }
}
