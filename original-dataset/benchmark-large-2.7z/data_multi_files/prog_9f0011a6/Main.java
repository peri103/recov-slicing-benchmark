import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        try {
            Path filePath = Paths.get("example.txt");
            
            // Ensure the file exists
            if (!Files.exists(filePath)) {
                Files.createFile(filePath);
            }
            
            // Create FileAttributes and FileReader instances
            FileAttributes fileAttributes = new FileAttributes(filePath);
            FileReader fileReader = new FileReader(filePath);
            
            // Set the last modified time
            fileAttributes.setLastModifiedTime();

            // Create a course and enroll students
            Course course = new Course("Java Programming");
            Student student1 = new Student("Alice");
            Student student2 = new Student("Bob");
            course.enrollStudent(student1);
            course.enrollStudent(student2);

            // Print enrolled students
            for (Student student : course.getEnrolledStudents()) {
                System.out.println("Enrolled Student: " + student.getName());
            }

            // Read file content and last modified time
            System.out.println("File Content:");
            for (String line : fileReader.readFileContent()) {
                System.out.println(line);
            }

            FileTime lastModifiedTime = fileReader.getLastModifiedTime();
            System.out.println("Last Modified Time: " + lastModifiedTime);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}