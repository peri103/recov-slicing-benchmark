import java.util.concurrent.atomic.AtomicReference;

public class AtomicOperations {
    private AtomicReference<Integer> atomicReference = new AtomicReference<>(0);

    public void incrementAtomicReference() {
        /* write */ atomicReference.updateAndGet(value -> value + 1);
    }

    public int getAtomicValue() {
        return atomicReference.get();
    }
}
