import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        AtomicOperations atomicOperations = new AtomicOperations();
        Student student = new Student("John");

        // Add scores to the student
        student.addScore(85);
        student.addScore(90);
        student.addScore(78);

        // Increment atomic reference
        atomicOperations.incrementAtomicReference();

        // Print student details
        System.out.println("Student: " + student.getName());
        System.out.println("Scores: " + student.getScores());

        // Calculate average score
        ArrayList<Integer> scores = student.getScores();
        int sum = 0;
        for (int score : scores) {
            sum += score;
        }
        int average = sum / scores.size();
        System.out.println("Average Score: " + average);

        // Get and print atomic value
        /* read */ int atomicValue = atomicOperations.getAtomicValue();
        System.out.println("AtomicReference value: " + atomicValue);
    }
}