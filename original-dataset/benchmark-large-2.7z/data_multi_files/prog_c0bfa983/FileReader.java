import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;

public class FileReader {
    private Path filePath;

    public FileReader(Path filePath) {
        this.filePath = filePath;
    }

    public Object getLastModifiedTime() {
        try {
            /* read */ return Files.getAttribute(filePath, "basic:lastModifiedTime");
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
