import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;

public class FileHandler {
    private Path filePath;

    public FileHandler(String fileName) {
        this.filePath = Paths.get(fileName);
        try {
            if (!Files.exists(filePath)) {
                Files.createFile(filePath);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setLastModifiedTime(long timeInMillis) {
        try {
            /* write */ Files.setAttribute(filePath, "basic:lastModifiedTime", timeInMillis);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Path getFilePath() {
        return filePath;
    }
}
