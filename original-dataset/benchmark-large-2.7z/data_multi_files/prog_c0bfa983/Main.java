public class Main {
    public static void main(String[] args) {
        FileHandler fileHandler = new FileHandler("example.txt");
        
        // Set a new last modified time
        fileHandler.setLastModifiedTime(System.currentTimeMillis() + 10000);

        // Create and manage a course
        Course course = new Course("Computer Science");
        Student student1 = new Student("Alice");
        Student student2 = new Student("Bob");
        
        course.addStudent(student1);
        course.addStudent(student2);

        for (Student student : course.getStudents()) {
            System.out.println("Student: " + student.getName());
        }

        // Read the last modified time
        FileReader fileReader = new FileReader(fileHandler.getFilePath());
        Object lastModifiedTime = fileReader.getLastModifiedTime();
        System.out.println("Last Modified Time: " + lastModifiedTime);
    }
}