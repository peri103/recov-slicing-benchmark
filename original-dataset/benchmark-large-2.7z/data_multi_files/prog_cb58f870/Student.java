import java.util.LinkedHashMap;

public class Student {
    private String name;
    private LinkedHashMap<String, Integer> subjectScores = new LinkedHashMap<>();

    public Student(String name) {
        this.name = name;
    }

    public void addScore(String subject, int score) {
        subjectScores.put(subject, score);
    }

    public void removeScore(String subject) {
        /* write */ subjectScores.remove(subject);
    }

    public Integer getScore(String subject) {
        return subjectScores.get(subject);
    }

    public String getName() {
        return name;
    }
}
