import java.util.List;

public class Main {
    public static void main(String[] args) {
        Student student1 = new Student("Alice");
        Student student2 = new Student("Bob");

        student1.addScore("Math", 85);
        student1.addScore("Science", 90);
        student2.addScore("Math", 78);
        student2.addScore("Science", 88);

        Course course = new Course("High School");
        course.addStudent(student1);
        course.addStudent(student2);

        student1.removeScore("Math");

        List<Student> students = course.getStudents();
        for (Student student : students) {
            System.out.println("Scores for " + student.getName() + ":");
            System.out.println("Math: " + student.getScore("Math"));
            System.out.println("Science: " + student.getScore("Science"));
        }

        /* read */ Integer aliceMathScore = student1.getScore("Math");
        System.out.println("Alice's Math score after removal: " + aliceMathScore);
    }
}