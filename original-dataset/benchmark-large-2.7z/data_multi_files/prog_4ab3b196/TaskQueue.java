import java.util.concurrent.DelayQueue;

public class TaskQueue {
    private DelayQueue<DelayedElement> queue = new DelayQueue<>();

    public void addTask(String task, long delay) {
        /* write */ queue.offer(new DelayedElement(task, delay));
    }

    public DelayedElement peekTask() {
        return queue.peek();
    }
}