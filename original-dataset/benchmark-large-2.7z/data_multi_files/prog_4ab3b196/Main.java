public class Main {
    public static void main(String[] args) {
        TaskQueue taskQueue = new TaskQueue();
        taskQueue.addTask("Complete Homework", 1000);

        // Unrelated code: Create a student and enroll them in courses
        Student student = new Student("John Doe");
        student.enrollCourse("Math");
        student.enrollCourse("Science");

        // Display student information
        System.out.println("Student: " + student.getName());
        System.out.println("Enrolled Courses: " + student.getCourses());

        // Simulate some delay
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        /* read */ DelayedElement element = taskQueue.peekTask();

        if (element != null) {
            System.out.println("Task in queue: " + element.getElement());
        } else {
            System.out.println("Queue is empty");
        }
    }
}