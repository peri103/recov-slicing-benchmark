import java.util.ArrayList;

public class Course {
    private String title;
    private ArrayList<Student> students = new ArrayList<>();

    public Course(String title) {
        this.title = title;
    }

    public void addStudent(Student student) {
        students.add(student);
    }

    public ArrayList<Student> getStudents() {
        return students;
    }

    public String getTitle() {
        return title;
    }
}
