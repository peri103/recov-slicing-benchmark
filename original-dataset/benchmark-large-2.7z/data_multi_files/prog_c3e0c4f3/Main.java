public class Main {
    public static void main(String[] args) {
        DataStore dataStore = new DataStore();
        dataStore.putValue("key", 10);

        Course course = new Course("Mathematics");
        Student student1 = new Student("Alice", 20);
        Student student2 = new Student("Bob", 22);

        course.addStudent(student1);
        course.addStudent(student2);

        for (Student student : course.getStudents()) {
            System.out.println("Student Name: " + student.getName() + ", Age: " + student.getAge());
        }

        /* read */ Integer value = dataStore.getValue("key");
        System.out.println("Value from DataStore: " + value);
    }
}