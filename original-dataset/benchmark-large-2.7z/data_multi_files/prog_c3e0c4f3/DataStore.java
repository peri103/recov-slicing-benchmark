import java.util.concurrent.ConcurrentSkipListMap;

public class DataStore {
    private ConcurrentSkipListMap<String, Integer> map = new ConcurrentSkipListMap<>();

    public void putValue(String key, int value) {
        /* write */ map.put(key, value);
    }

    public Integer getValue(String key) {
        return map.get(key);
    }
}
