import java.util.concurrent.CopyOnWriteArrayList;

public class Student {
    private String name;
    private CopyOnWriteArrayList<String> courses;

    public Student(String name) {
        this.name = name;
        this.courses = new CopyOnWriteArrayList<>();
    }

    public void enrollCourse(String course) {
        courses.add(course);
    }

    public void dropCourse(String course) {
        /* write */ courses.remove(course);
    }

    public CopyOnWriteArrayList<String> getCourses() {
        return courses;
    }

    public String getName() {
        return name;
    }
}
