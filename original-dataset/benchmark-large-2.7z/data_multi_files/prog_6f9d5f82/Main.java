public class Main {
    public static void main(String[] args) {
        Student student = new Student("John Doe");
        student.enrollCourse("Math");
        student.enrollCourse("Science");
        student.dropCourse("Math");

        Course mathCourse = new Course("Math");
        mathCourse.addStudent(student.getName(), 95);

        Course scienceCourse = new Course("Science");
        scienceCourse.addStudent(student.getName(), 88);

        int mathGrade = mathCourse.getStudentGrade(student.getName());
        int scienceGrade = scienceCourse.getStudentGrade(student.getName());

        System.out.println("Math Grade: " + mathGrade);
        System.out.println("Science Grade: " + scienceGrade);

        /* read */ String remainingCourse = student.getCourses().get(0);
        System.out.println("Remaining Course: " + remainingCourse);
    }
}