import java.util.HashMap;

public class Course {
    private String courseName;
    private HashMap<String, Integer> studentGrades;

    public Course(String courseName) {
        this.courseName = courseName;
        this.studentGrades = new HashMap<>();
    }

    public void addStudent(String studentName, int grade) {
        studentGrades.put(studentName, grade);
    }

    public int getStudentGrade(String studentName) {
        return studentGrades.getOrDefault(studentName, -1);
    }

    public String getCourseName() {
        return courseName;
    }
}
