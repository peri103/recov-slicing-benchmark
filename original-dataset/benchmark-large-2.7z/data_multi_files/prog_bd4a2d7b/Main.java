import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Create a course and add students
        Course course = new Course("Mathematics");
        Student alice = new Student("Alice");
        Student bob = new Student("Bob");

        course.enrollStudent(alice);
        course.enrollStudent(bob);

        // Add scores to students
        alice.addScore(85);
        bob.addScore(90);

        // Retrieve and print scores
        List<Integer> aliceScores = alice.getScores().getCollectedScores();
        System.out.println("Alice's Scores: " + aliceScores);

        List<Integer> bobScores = bob.getScores().getCollectedScores();
        System.out.println("Bob's Scores: " + bobScores);
    }
}