import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StudentScores {
    private Stream<Integer> scoreStream = Stream.of();

    public void addScore(int score) {
        /* write */ scoreStream = Stream.concat(scoreStream, Stream.of(score));
    }

    public List<Integer> getCollectedScores() {
        /* read */ return scoreStream.collect(Collectors.toList());
    }
}
