import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class DataProcessor {
    public Stream<Integer> processStream(Stream<Integer> stream) {
        /* write */ return stream.map(x -> x * 2);
    }
}
