import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ResultCollector {
    public List<Integer> collectResults(Stream<Integer> stream) {
        /* read */ return stream.collect(Collectors.toList());
    }
}
