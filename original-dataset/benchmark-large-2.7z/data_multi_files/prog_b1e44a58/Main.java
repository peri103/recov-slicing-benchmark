import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Student student = new Student("Alice");
        student.addScore(95);

        Course course = new Course("Mathematics");
        course.enrollStudent(student);

        ArrayList<Student> students = course.getEnrolledStudents();
        if (!students.isEmpty()) {
            Student firstStudent = students.get(0);
            ArrayList<Integer> scores = firstStudent.getScores();
            /* read */ int score = scores.get(0);
            System.out.println("First student's first score: " + score);
        }

        // Additional logic
        Student student2 = new Student("Bob");
        student2.addScore(88);
        course.enrollStudent(student2);

        for (Student s : course.getEnrolledStudents()) {
            System.out.println("Student: " + s.getScores());
        }
    }
}