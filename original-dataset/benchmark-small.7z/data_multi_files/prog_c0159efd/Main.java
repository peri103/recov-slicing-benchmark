public class Main {
    public static void main(String[] args) {
        StackHandler stackHandler = new StackHandler();
        Course course = new Course("Mathematics");
        
        Student student1 = new Student("Alice");
        Student student2 = new Student("Bob");

        student1.addScore(85);
        student2.addScore(90);

        course.enrollStudent(student1);
        course.enrollStudent(student2);

        stackHandler.pushToStack(1);
        
        for (Student student : course.getStudents()) {
            System.out.println("Student: " + student.getName());
            for (int score : student.getScores()) {
                System.out.println("Score: " + score);
            }
        }

        /* read */ int value = stackHandler.popFromStack();
        System.out.println("Popped value from stack: " + value);

        System.out.println("Final Stack Size: " + stackHandler.getStackSize());
    }
}