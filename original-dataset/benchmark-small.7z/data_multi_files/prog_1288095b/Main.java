public class Main {
    public static void main(String[] args) {
        Student student1 = new Student("Alice", 1);
        Student student2 = new Student("Bob", 2);

        Course course = new Course("Java Programming");

        course.addStudentGrade(student1.getId(), "A");
        course.addStudentGrade(student2.getId(), "B");

        // Reading the grade of student1
        /* read */ String grade = course.getStudentGrade(student1.getId());
        System.out.println("Grade for " + student1.getName() + ": " + grade);

        // Reading the grade of student2
        String grade2 = course.getStudentGrade(student2.getId());
        System.out.println("Grade for " + student2.getName() + ": " + grade2);
    }
}