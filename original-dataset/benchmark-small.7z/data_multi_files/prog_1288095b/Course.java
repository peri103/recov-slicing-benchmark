import java.util.SortedMap;
import java.util.TreeMap;

public class Course {
    private String courseName;
    private SortedMap<Integer, String> studentGrades = new TreeMap<>();

    public Course(String courseName) {
        this.courseName = courseName;
    }

    public void addStudentGrade(int studentId, String grade) {
        /* write */ studentGrades.put(studentId, grade);
    }

    public String getStudentGrade(int studentId) {
        return studentGrades.get(studentId);
    }
}
