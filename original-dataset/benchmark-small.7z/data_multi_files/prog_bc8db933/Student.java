import java.util.ArrayList;
import java.util.HashMap;

public class Student {
    private String name;
    private ArrayList<Integer> scores = new ArrayList<>();
    private HashMap<String, Integer> attributes = new HashMap<>();

    public Student(String name) {
        this.name = name;
    }

    public void addScore(int score) {
        scores.add(score);
    }

    public ArrayList<Integer> getScores() {
        return scores;
    }

    public void addAttribute(String key, Integer value) {
        attributes.put(key, value);
    }

    public Integer getAttribute(String key) {
        return attributes.get(key);
    }
}
