import java.util.SortedMap;
import java.util.TreeMap;

public class SortedMapManager {
    private SortedMap<String, Integer> sortedMap = new TreeMap<>();

    public void addEntry(String key, Integer value) {
        /* write */ sortedMap.put(key, value);
    }

    public Integer getEntry(String key) {
        return sortedMap.get(key);
    }

    public SortedMap<String, Integer> getSortedMap() {
        return sortedMap;
    }
}
