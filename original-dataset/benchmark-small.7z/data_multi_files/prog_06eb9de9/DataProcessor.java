import java.util.Map;

public class DataProcessor {
    private SortedMapManager sortedMapManager;

    public DataProcessor(SortedMapManager sortedMapManager) {
        this.sortedMapManager = sortedMapManager;
    }

    public void processEntries() {
        for (Map.Entry<String, Integer> entry : sortedMapManager.getSortedMap().entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }

    public void addSampleData() {
        sortedMapManager.addEntry("key2", 200);
        sortedMapManager.addEntry("key3", 300);
    }
}
