public class Main {
    public static void main(String[] args) {
        ConcurrentSetManager manager = new ConcurrentSetManager();
        manager.addValue(42);

        Course course = new Course("Math 101");
        Student alice = new Student("Alice");
        alice.addScore(95);
        course.addStudent(alice);

        Student bob = new Student("Bob");
        bob.addScore(85);
        course.addStudent(bob);

        for (Student student : course.getStudents()) {
            System.out.println("Student: " + student.getName());
            System.out.println("Scores: " + student.getScores());
        }

        /* read */ boolean containsValue = manager.containsValue(42);
        System.out.println("Set contains 42: " + containsValue);
    }
}