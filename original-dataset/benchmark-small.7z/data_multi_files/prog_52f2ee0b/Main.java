import java.util.Vector;

public class Main {
    public static void main(String[] args) {
        // Vector operations
        VectorOperations vectorOps = new VectorOperations();
        vectorOps.addElement(42);

        // Course and Student operations
        Course course = new Course("Computer Science");
        Student student1 = new Student("Alice", 20, "CS101");
        Student student2 = new Student("Bob", 22, "CS102");

        course.addStudent(student1);
        course.addStudent(student2);

        for (Student student : course.getStudents()) {
            System.out.println("Student Name: " + student.getName());
            System.out.println("Student Age: " + student.getAge());
            System.out.println("Student ID: " + student.getStudentID());
        }

        // Original read method
        /* read */ int value = vectorOps.getElementAt(0);
        System.out.println("Read value from Vector: " + value);
    }
}