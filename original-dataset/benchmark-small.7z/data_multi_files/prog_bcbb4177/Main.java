import java.util.concurrent.BlockingDeque;

public class Main {
    public static void main(String[] args) {
        DequeOperations dequeOps = new DequeOperations();
        PersonManager personManager = new PersonManager();

        personManager.addPerson(new Person("Alice", 25));
        personManager.addPerson(new Person("Bob", 30));
        personManager.addPerson(new Person("Charlie", 35));

        for (Person person : personManager.getPeople()) {
            System.out.println("Name: " + person.getName());
        }

        for (Map.Entry<String, Integer> entry : personManager.getAgeMap().entrySet()) {
            System.out.println(entry.getKey() + " is " + entry.getValue() + " years old.");
        }

        dequeOps.addToFront(42);

        try {
            Thread.sleep(1000); // Simulate some processing delay
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        BlockingDeque<Integer> deque = dequeOps.getDeque();
        try {
            /* read */ int value = deque.takeFirst();
            System.out.println("Deque value: " + value);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        int sumOfAges = 0;
        for (int age : personManager.getAgeMap().values()) {
            sumOfAges += age;
        }
        System.out.println("Total age: " + sumOfAges);
    }
}