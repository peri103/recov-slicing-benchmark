import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class PersonManager {
    private ArrayList<Person> people = new ArrayList<>();
    private HashMap<String, Integer> ageMap = new HashMap<>();

    public void addPerson(Person person) {
        people.add(person);
        ageMap.put(person.getName(), person.getAge());
    }

    public ArrayList<Person> getPeople() {
        return people;
    }

    public HashMap<String, Integer> getAgeMap() {
        return ageMap;
    }
}
