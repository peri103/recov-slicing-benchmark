import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;

public class Main {
    public static void main(String[] args) {
        QueueManager queueManager = new QueueManager();
        queueManager.addValue(42);

        Course course = new Course("Computer Science");
        Student student1 = new Student("Alice");
        Student student2 = new Student("Bob");

        student1.addGrade(85);
        student2.addGrade(90);

        course.addStudent(student1);
        course.addStudent(student2);

        List<Student> students = course.getStudents();
        for (Student student : students) {
            System.out.println("Student: " + student.getName());
            System.out.println("Grades: " + student.getGrades());
        }

        try {
            LinkedBlockingQueue<Integer> queue = queueManager.getQueue();
            /* read */ int value = queue.take();
            System.out.println("Value from queue: " + value);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}