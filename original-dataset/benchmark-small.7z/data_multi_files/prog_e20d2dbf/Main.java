public class Main {
    public static void main(String[] args) {
        DequeOperations dequeOps = new DequeOperations();
        QueueOperations queueOps = new QueueOperations();

        // Queue operations
        queueOps.addElement("Hello");
        queueOps.addElement("World");
        queueOps.processQueue();

        // Deque operations
        dequeOps.addElementToFront(42);
        dequeOps.addElementToFront(10);
        dequeOps.addElementToFront(20);

        int lastElement = dequeOps.removeLastElement();
        System.out.println("Removed last element: " + lastElement);

        int sum = dequeOps.calculateSum();
        System.out.println("Sum of elements in deque: " + sum);

        /* read */ int firstElement = dequeOps.getDeque().getFirst();
        System.out.println("First element: " + firstElement);
    }
}