import java.util.Deque;
import java.util.LinkedList;

public class DequeOperations {
    private Deque<Integer> deque = new LinkedList<>();

    public void addElementToFront(int element) {
        /* write */ deque.addFirst(element);
    }

    public int removeLastElement() {
        return deque.removeLast();
    }

    public int calculateSum() {
        int sum = 0;
        for (int num : deque) {
            sum += num;
        }
        return sum;
    }

    public Deque<Integer> getDeque() {
        return deque;
    }
}
