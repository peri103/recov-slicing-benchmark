import java.util.LinkedList;
import java.util.Queue;

public class QueueOperations {
    private Queue<String> queue = new LinkedList<>();

    public void addElement(String element) {
        queue.add(element);
    }

    public void processQueue() {
        while (!queue.isEmpty()) {
            String element = queue.poll();
            System.out.println(element);
        }
    }
}
