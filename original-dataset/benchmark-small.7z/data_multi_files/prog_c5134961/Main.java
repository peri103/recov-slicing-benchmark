public class Main {
    public static void main(String[] args) {
        CustomSet customSet = new CustomSet();
        customSet.addElement(42);
        
        Course course = new Course("Mathematics");
        Student student = new Student("Alice");
        student.addGrade(95);
        student.addGrade(85);
        
        course.enrollStudent(student);
        
        Student retrievedStudent = course.getStudent("Alice");
        if (retrievedStudent != null) {
            System.out.println("Grades for " + retrievedStudent.getName() + " in " + course.getCourseName() + ":");
            for (int grade : retrievedStudent.getGrades()) {
                System.out.println(grade);
            }
        }

        /* read */ boolean contains = customSet.containsElement(42);
        System.out.println("CustomSet contains 42: " + contains);
    }
}