import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingDeque;

public class DequeOperations {
    private BlockingDeque<Integer> deque = new LinkedBlockingDeque<>();

    public void addValue(int value) {
        /* write */ deque.addLast(value);
    }

    public int removeLastValue() throws InterruptedException {
        /* read */ return deque.takeLast();
    }

    public int removeFirstValue() throws InterruptedException {
        return deque.takeFirst();
    }

    public BlockingDeque<Integer> getDeque() {
        return deque;
    }
}
