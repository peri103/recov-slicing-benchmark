public class Main {
    public static void main(String[] args) {
        DequeOperations dequeOps = new DequeOperations();
        MessageQueue messageQueue = new MessageQueue();
        DoubleQueue doubleQueue = new DoubleQueue();

        // Add elements to the deque
        dequeOps.addValue(42);
        dequeOps.addValue(84);
        dequeOps.addValue(168);

        // Add messages to the queue
        messageQueue.addMessage("Hello");
        messageQueue.addMessage("World");

        // Process the message queue
        while (messageQueue.hasMessages()) {
            try {
                String message = messageQueue.processMessage();
                System.out.println("Processing message: " + message);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Perform some unrelated calculations
        int sum = 0;
        for (int i = 0; i < 10; i++) {
            sum += i;
        }
        System.out.println("Sum of first 10 numbers: " + sum);

        // Process the deque
        try {
            int firstElement = dequeOps.removeFirstValue();
            System.out.println("First element taken: " + firstElement);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Add and process doubles
        for (double d = 0.5; d < 5; d += 0.5) {
            doubleQueue.addDouble(d);
        }

        while (doubleQueue.hasDoubles()) {
            double value = doubleQueue.processDouble();
            System.out.println("Processing double value: " + value);
        }

        // Final read operation
        try {
            int lastValue = dequeOps.removeLastValue();
            System.out.println("Last element taken: " + lastValue);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}