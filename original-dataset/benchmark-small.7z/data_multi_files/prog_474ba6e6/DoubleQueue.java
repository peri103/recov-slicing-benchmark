import java.util.Queue;
import java.util.LinkedList;

public class DoubleQueue {
    private Queue<Double> doubleQueue = new LinkedList<>();

    public void addDouble(double value) {
        doubleQueue.add(value);
    }

    public Double processDouble() {
        return doubleQueue.poll();
    }

    public boolean hasDoubles() {
        return !doubleQueue.isEmpty();
    }
}
