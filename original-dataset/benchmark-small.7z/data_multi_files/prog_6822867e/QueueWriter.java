import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class QueueWriter {
    private BlockingQueue<Integer> queue = new LinkedBlockingQueue<>();

    public void addValue(int value) {
        try {
            /* write */ queue.put(value);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public BlockingQueue<Integer> getQueue() {
        return queue;
    }
}
