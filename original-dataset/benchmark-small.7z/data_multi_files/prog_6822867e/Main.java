import java.util.concurrent.BlockingQueue;

public class Main {
    public static void main(String[] args) {
        // Working with QueueWriter and QueueReader
        QueueWriter writer = new QueueWriter();
        writer.addValue(1);

        BlockingQueue<Integer> queue = writer.getQueue();
        QueueReader reader = new QueueReader(queue);

        int readValue = reader.readValue();
        System.out.println("Read Value from Queue: " + readValue);

        // Working with Student and Course
        Student student1 = new Student("Alice");
        Student student2 = new Student("Bob");

        Course course = new Course("Computer Science");
        course.addStudent(student1);
        course.addStudent(student2);

        student1.addGrade(85);
        student2.addGrade(90);

        System.out.println("Course: " + course.getCourseName());
        for (Student student : course.getStudents()) {
            System.out.println("Student: " + student.getName() + ", Grades: " + student.getGrades());
        }
    }
}