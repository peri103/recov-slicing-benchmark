import java.util.concurrent.BlockingQueue;

public class QueueReader {
    private BlockingQueue<Integer> queue;

    public QueueReader(BlockingQueue<Integer> queue) {
        this.queue = queue;
    }

    public int readValue() {
        try {
            /* read */ return queue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
            return -1; // return a default value in case of exception
        }
    }
}
