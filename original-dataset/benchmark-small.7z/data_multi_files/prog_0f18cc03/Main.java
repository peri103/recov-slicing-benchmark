public class Main {
    public static void main(String[] args) {
        TransferQueueManager queueManager = new TransferQueueManager();
        queueManager.addValue(1);

        Course course = new Course("Mathematics");
        Student alice = new Student("Alice");
        alice.addGrade(95);
        course.addStudent(alice);

        Student bob = new Student("Bob");
        bob.addGrade(89);
        course.addStudent(bob);

        // Retrieve and print student grades
        System.out.println("Course: " + course.getCourseName());
        for (String studentName : new String[]{"Alice", "Bob"}) {
            Student student = course.getStudent(studentName);
            System.out.println("Student: " + student.getName() + ", Grades: " + student.getGrades());
        }

        /* read */ Integer value = queueManager.retrieveValue();
        System.out.println("LinkedTransferQueue: " + value);
    }
}