import java.util.concurrent.LinkedTransferQueue;

public class TransferQueueManager {
    private LinkedTransferQueue<Integer> queue = new LinkedTransferQueue<>();

    public void addValue(int value) {
        /* write */ queue.offer(value);
    }

    public Integer retrieveValue() {
        return queue.poll();
    }
}
