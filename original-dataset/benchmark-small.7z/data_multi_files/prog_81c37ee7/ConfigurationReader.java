import java.util.Properties;

public class ConfigurationReader {
    private Properties properties;

    public ConfigurationReader(Properties properties) {
        this.properties = properties;
    }

    public String getConfig(String key) {
        /* read */ return properties.getProperty(key);
    }
}