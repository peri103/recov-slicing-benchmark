import java.util.Properties;

public class Main {
    public static void main(String[] args) {
        // Initialize configuration
        Configuration config = new Configuration();
        config.setConfig("course", "Java Programming");

        // Create a course and students
        Course course = new Course("Java Programming");
        Student student1 = new Student("Alice", 20);
        Student student2 = new Student("Bob", 22);

        // Add students to the course
        course.addStudent(student1);
        course.addStudent(student2);

        // Output course details
        System.out.println("Course: " + course.getCourseName());
        for (Student student : course.getStudents()) {
            System.out.println("Student: " + student.getName() + ", Age: " + student.getAge());
        }

        // Retrieve configuration
        Properties properties = config.getProperties();
        /* read */ String courseName = properties.getProperty("course");
        System.out.println("Configured Course: " + courseName);
    }
}