import java.util.Properties;

public class ConfigurationWriter {
    private Properties properties;

    public ConfigurationWriter() {
        properties = new Properties();
    }

    public void setConfig(String key, String value) {
        /* write */ properties.setProperty(key, value);
    }

    public Properties getProperties() {
        return properties;
    }
}