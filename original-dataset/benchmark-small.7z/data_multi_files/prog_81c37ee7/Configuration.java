import java.util.Properties;

public class Configuration {
    private Properties properties = new Properties();

    public void setConfig(String key, String value) {
        /* write */ properties.setProperty(key, value);
    }

    public Properties getProperties() {
        return properties;
    }
}
