import java.util.HashMap;
import java.util.Map;

public class Application {
    private String appName;
    private Configuration configuration = new Configuration();
    private HashMap<String, String> appData = new HashMap<>();

    public Application(String appName) {
        this.appName = appName;
    }

    public void addData(String key, String value) {
        appData.put(key, value);
    }

    public void configureApp(String key, String value) {
        configuration.setConfig(key, value);
    }

    public String readConfig(String key) {
        return configuration.getProperties().getProperty(key);
    }

    public void displayAppData() {
        for (Map.Entry<String, String> entry : appData.entrySet()) {
            System.out.println("App Data Key: " + entry.getKey() + ", App Data Value: " + entry.getValue());
        }
    }
}
