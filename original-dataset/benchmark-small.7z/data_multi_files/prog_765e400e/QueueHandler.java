import java.util.concurrent.ConcurrentLinkedQueue;

public class QueueHandler {
    private ConcurrentLinkedQueue<Integer> queue = new ConcurrentLinkedQueue<>();

    public void addToQueue(int value) {
        /* write */ queue.offer(value);
    }

    public Integer pollFromQueue() {
        return queue.poll();
    }

    public boolean isQueueEmpty() {
        return queue.isEmpty();
    }
}
