public class Main {
    public static void main(String[] args) {
        QueueHandler queueHandler = new QueueHandler();
        DataProcessor dataProcessor = new DataProcessor();

        queueHandler.addToQueue(42);

        dataProcessor.populateArrayList();
        dataProcessor.printArrayList();

        dataProcessor.populateHashMap();
        dataProcessor.printHashMap();

        int sum = dataProcessor.calculateSum(10);
        System.out.println("Sum of first 10 natural numbers: " + sum);

        queueHandler.addToQueue(100);
        queueHandler.addToQueue(200);

        Integer firstElement = queueHandler.pollFromQueue();
        System.out.println("First element removed from queue: " + firstElement);

        while (!queueHandler.isQueueEmpty()) {
            /* read */ Integer value = queueHandler.pollFromQueue();
            System.out.println("Processed value from queue: " + value);
        }
    }
}