import java.util.List;

public class Main {
    public static void main(String[] args) {
        Student student = new Student("Alice");
        student.addScore(95);
        student.addScore(88);
        student.addScore(76);

        List<Integer> allScores = student.getScores().getAllScores();
        for (Integer score : allScores) {
            System.out.println("Score: " + score);
        }

        /* read */ Integer latestScore = student.getScores().getLatestScore();
        System.out.println("Latest Score: " + latestScore);
    }
}