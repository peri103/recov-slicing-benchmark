import java.util.HashMap;

public class Course {
    private String title;
    private HashMap<String, Student> enrolledStudents = new HashMap<>();

    public Course(String title) {
        this.title = title;
    }

    public void enrollStudent(Student student) {
        enrolledStudents.put(student.getName(), student);
    }

    public Student getStudent(String name) {
        return enrolledStudents.get(name);
    }

    public String getTitle() {
        return title;
    }
}
