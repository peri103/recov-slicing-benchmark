import java.util.Deque;
import java.util.LinkedList;
import java.util.Queue;

public class Main {
    public static void main(String[] args) {
        Deque<Integer> deque = new LinkedList<>();
        Queue<String> queue = new LinkedList<>();
        
        // Adding elements to the queue
        queue.add("Hello");
        queue.add("World");
        
        // Processing the queue
        while (!queue.isEmpty()) {
            String element = queue.poll();
            System.out.println(element);
        }
        
        // Adding more elements to the deque
        deque.addLast(10);
        deque.addLast(20);
        
        /* write */ deque.addFirst(42);
        
        // Manipulating the deque
        int lastElement = deque.removeLast();
        System.out.println("Removed last element: " + lastElement);
        
        // Performing some calculations
        int sum = 0;
        for (int num : deque) {
            sum += num;
        }
        System.out.println("Sum of elements in deque: " + sum);
        
        /* read */ int value = deque.getFirst();
        System.out.println("First element: " + value);
        
        // Adding more complexity with nested loops
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                deque.addLast(i * j);
            }
        }
        
        // Printing all elements in the deque
        System.out.println("All elements in deque:");
        for (int num : deque) {
            System.out.println(num);
        }
    }
}