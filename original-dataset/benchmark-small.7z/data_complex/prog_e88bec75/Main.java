import java.util.Hashtable;
import java.util.ArrayList;
import java.util.HashSet;

public class Main {
    public static void main(String[] args) {
        Hashtable<String, Integer> hashtable = new Hashtable<>();
        ArrayList<Integer> arrayList = new ArrayList<>();
        HashSet<String> hashSet = new HashSet<>();

        // Additional code using ArrayList
        for (int i = 0; i < 5; i++) {
            arrayList.add(i * 10);
        }

        // Additional code using HashSet
        hashSet.add("apple");
        hashSet.add("banana");
        hashSet.add("cherry");

        /* write */ hashtable.put("key", 42);

        // Iterate over ArrayList
        for (int num : arrayList) {
            System.out.println("ArrayList item: " + num);
        }

        // Check if a specific item is in the HashSet
        if (hashSet.contains("banana")) {
            System.out.println("HashSet contains banana");
        }

        // Perform some operations on the ArrayList
        arrayList.remove(0);
        arrayList.add(50);

        // More operations on HashSet
        hashSet.remove("apple");
        hashSet.add("date");

        // Final operation on Hashtable
        hashtable.put("anotherKey", 100);

        /* read */ int value = hashtable.get("key");
        System.out.println("Value from Hashtable: " + value);

        // More complex logic
        int sum = 0;
        for (Integer num : arrayList) {
            sum += num;
        }
        System.out.println("Sum of ArrayList: " + sum);

        // Print all items in HashSet
        System.out.println("Items in HashSet:");
        for (String fruit : hashSet) {
            System.out.println(fruit);
        }
    }
}