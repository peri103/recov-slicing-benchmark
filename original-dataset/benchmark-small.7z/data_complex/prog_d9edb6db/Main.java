import java.util.concurrent.ConcurrentSkipListSet;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        ConcurrentSkipListSet<Integer> set = new ConcurrentSkipListSet<>();
        ConcurrentSkipListSet<Integer> anotherSet = new ConcurrentSkipListSet<>();
        HashMap<Integer, String> map = new HashMap<>();
        
        // Adding elements to anotherSet
        anotherSet.add(100);
        anotherSet.add(200);
        
        // Add elements to the map
        map.put(1, "One");
        map.put(2, "Two");
        
        /* write */ set.add(42);
        
        // Perform some operations on anotherSet
        if (anotherSet.contains(100)) {
            anotherSet.remove(100);
        }
        
        // Iterate over the map
        for (Map.Entry<Integer, String> entry : map.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }
        
        // Add more elements to set
        set.add(50);
        set.add(60);
        
        // Check if map contains a key
        if (map.containsKey(2)) {
            System.out.println("Map contains key 2");
        }
        
        /* read */ boolean containsValue = set.contains(42);
        System.out.println("Set contains 42: " + containsValue);
        
        // Additional operations to make the program more complex
        for (int i = 0; i < 10; i++) {
            set.add(i * 10);
        }
        
        // Print all elements in the set
        for (Integer num : set) {
            System.out.println("Set element: " + num);
        }
    }
}