import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;
import java.util.PriorityQueue;
import java.util.concurrent.LinkedBlockingQueue;

class DelayedElement implements Delayed {
    private final long delay;
    private final long expire;
    private final String name;

    public DelayedElement(long delay, String name) {
        this.delay = delay;
        this.expire = System.currentTimeMillis() + delay;
        this.name = name;
    }

    @Override
    public long getDelay(TimeUnit unit) {
        long remaining = expire - System.currentTimeMillis();
        return unit.convert(remaining, TimeUnit.MILLISECONDS);
    }

    @Override
    public int compareTo(Delayed other) {
        if (this.expire < ((DelayedElement) other).expire) {
            return -1;
        }
        if (this.expire > ((DelayedElement) other).expire) {
            return 1;
        }
        return 0;
    }

    @Override
    public String toString() {
        return "DelayedElement{" + "name=" + name + ", delay=" + delay + '}';
    }
}

public class Main {
    public static void main(String[] args) {
        DelayQueue<DelayedElement> delayQueue = new DelayQueue<>();
        DelayedElement element1 = new DelayedElement(1000, "Element1"); // 1 second delay
        DelayedElement element2 = new DelayedElement(2000, "Element2"); // 2 seconds delay

        // PriorityQueue example
        PriorityQueue<Integer> priorityQueue = new PriorityQueue<>();
        priorityQueue.add(3);
        priorityQueue.add(1);
        priorityQueue.add(2);

        // LinkedBlockingQueue example
        LinkedBlockingQueue<String> linkedBlockingQueue = new LinkedBlockingQueue<>();
        linkedBlockingQueue.add("First");
        linkedBlockingQueue.add("Second");

        /* write */ delayQueue.put(element1);
        delayQueue.put(element2);

        // Process PriorityQueue elements
        while (!priorityQueue.isEmpty()) {
            System.out.println("PriorityQueue element: " + priorityQueue.poll());
        }

        // Process LinkedBlockingQueue elements
        while (!linkedBlockingQueue.isEmpty()) {
            System.out.println("LinkedBlockingQueue element: " + linkedBlockingQueue.poll());
        }

        // Additional logic before reading from DelayQueue
        System.out.println("Performing other operations...");

        try {
            /* read */ DelayedElement retrievedElement1 = delayQueue.take();
            System.out.println("Retrieved from DelayQueue: " + retrievedElement1);

            DelayedElement retrievedElement2 = delayQueue.take();
            System.out.println("Retrieved from DelayQueue: " + retrievedElement2);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println("Thread was interrupted");
        }
    }
}