import java.util.TreeMap;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        TreeMap<Integer, String> map = new TreeMap<>();
        HashMap<String, Integer> hashMap = new HashMap<>();
        List<String> list = new ArrayList<>();

        // Adding elements to the HashMap
        hashMap.put("One", 1);
        hashMap.put("Two", 2);
        hashMap.put("Three", 3);

        // Adding elements to the List
        list.add("Alpha");
        list.add("Beta");
        list.add("Gamma");

        // Manipulating the TreeMap
        /* write */ map.put(1, "Hello");
        map.put(2, "World");
        map.put(3, "Java");

        // Iterating over the HashMap and printing its contents
        for (String key : hashMap.keySet()) {
            System.out.println("Key: " + key + ", Value: " + hashMap.get(key));
        }

        // Iterating over the List and printing its contents
        for (String element : list) {
            System.out.println("Element: " + element);
        }

        // Perform some unrelated operations
        int sum = 0;
        for (int value : hashMap.values()) {
            sum += value;
        }
        System.out.println("Sum of values in HashMap: " + sum);

        // Perform some operations on the TreeMap
        if (map.containsKey(2)) {
            System.out.println("TreeMap contains key 2");
        }

        // Read from the TreeMap
        /* read */ String value = map.get(1);
        System.out.println("Value read from TreeMap: " + value);

        // Additional operations on the List
        list.add("Delta");
        list.add("Epsilon");

        System.out.println("List size: " + list.size());

        for (String element : list) {
            System.out.println("Updated Element: " + element);
        }
    }
}