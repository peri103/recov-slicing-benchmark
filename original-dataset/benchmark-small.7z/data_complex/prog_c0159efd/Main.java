import java.util.Stack;
import java.util.ArrayList;
import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();
        ArrayList<Integer> arrayList = new ArrayList<>();
        LinkedList<Integer> linkedList = new LinkedList<>();

        // Push elements to the ArrayList
        for (int i = 0; i < 5; i++) {
            arrayList.add(i * 2);
        }

        // Push elements to the LinkedList
        for (int i = 0; i < 5; i++) {
            linkedList.add(i * 3);
        }

        // Add elements from ArrayList to Stack
        for (Integer num : arrayList) {
            stack.push(num);
        }

        // Add elements from LinkedList to Stack
        for (Integer num : linkedList) {
            stack.push(num);
        }

        // Perform some operations before using the main write-read pair
        linkedList.addFirst(100);
        linkedList.addLast(200);
        arrayList.remove(0);

        /* write */ stack.push(1);

        // Additional operations
        for (int i = 0; i < stack.size(); i++) {
            System.out.println("Stack element at index " + i + ": " + stack.get(i));
        }

        // Some unrelated computation
        int sum = 0;
        for (int i = 0; i < arrayList.size(); i++) {
            sum += arrayList.get(i);
        }
        System.out.println("Sum of ArrayList elements: " + sum);

        // More operations with LinkedList
        linkedList.removeFirst();
        linkedList.removeLast();

        /* read */ int value = stack.pop();
        System.out.println("Popped value from stack: " + value);

        // Final operations
        System.out.println("Final Stack Size: " + stack.size());
        System.out.println("Final ArrayList Size: " + arrayList.size());
        System.out.println("Final LinkedList Size: " + linkedList.size());
    }
}