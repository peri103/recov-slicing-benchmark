import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class Main {
    public static void main(String[] args) {
        SynchronousQueue<Integer> synchronousQueue = new SynchronousQueue<>();

        // Additional queue for more complexity
        BlockingQueue<String> blockingQueue = new LinkedBlockingQueue<>();

        // Thread to perform the write operation on the SynchronousQueue
        Thread writerThread = new Thread(() -> {
            try {
                /* write */ synchronousQueue.put(10);
                System.out.println("Value written to SynchronousQueue: 10");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.out.println("Write operation interrupted");
            }
        });

        // Thread to perform the read operation on the SynchronousQueue
        Thread readerThread = new Thread(() -> {
            try {
                /* read */ int value = synchronousQueue.take();
                System.out.println("Value read from SynchronousQueue: " + value);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.out.println("Read operation interrupted");
            }
        });

        // Start both threads for SynchronousQueue
        writerThread.start();
        readerThread.start();

        // Additional threads for the BlockingQueue
        Thread producerThread = new Thread(() -> {
            try {
                for (int i = 1; i <= 5; i++) {
                    blockingQueue.put("Message " + i);
                    System.out.println("Message " + i + " added to BlockingQueue");
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.out.println("Producer operation interrupted");
            }
        });

        Thread consumerThread = new Thread(() -> {
            try {
                for (int i = 1; i <= 5; i++) {
                    String message = blockingQueue.take();
                    System.out.println("Processed: " + message);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.out.println("Consumer operation interrupted");
            }
        });

        // Start additional threads for BlockingQueue
        producerThread.start();
        consumerThread.start();

        // Wait for all threads to finish
        try {
            writerThread.join();
            readerThread.join();
            producerThread.join();
            consumerThread.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println("Main thread interrupted");
        }
    }
}