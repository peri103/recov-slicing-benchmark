import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class Main {
    public static void main(String[] args) {
        SynchronousQueue<Integer> queue = new SynchronousQueue<>();
        BlockingQueue<String> stringQueue = new LinkedBlockingQueue<>();

        // Start a new thread to write to the SynchronousQueue
        new Thread(() -> {
            try {
                /* write */ queue.put(42);
                System.out.println("Value written to the SynchronousQueue: 42");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("Write operation interrupted");
            }
        }).start();

        // Start a new thread to write to the LinkedBlockingQueue
        new Thread(() -> {
            try {
                stringQueue.put("Hello");
                System.out.println("String written to the LinkedBlockingQueue: Hello");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("Write operation interrupted");
            }
        }).start();

        // Start a new thread to read from the LinkedBlockingQueue
        new Thread(() -> {
            try {
                String message = stringQueue.take();
                System.out.println("String read from the LinkedBlockingQueue: " + message);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("Read operation interrupted");
            }
        }).start();

        // Start a new thread to perform some unrelated computation
        new Thread(() -> {
            int sum = 0;
            for (int i = 1; i <= 100; i++) {
                sum += i;
            }
            System.out.println("Sum of numbers from 1 to 100: " + sum);
        }).start();

        // Start a new thread to read from the SynchronousQueue
        new Thread(() -> {
            try {
                /* read */ int value = queue.take();
                System.out.println("Value read from the SynchronousQueue: " + value);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("Read operation interrupted");
            }
        }).start();
    }
}