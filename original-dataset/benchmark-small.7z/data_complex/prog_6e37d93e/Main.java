import java.util.LinkedList;
import java.util.ArrayList;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        LinkedList<Integer> list = new LinkedList<>();
        ArrayList<String> stringList = new ArrayList<>();
        HashMap<String, Integer> map = new HashMap<>();

        // Add some strings to the stringList
        stringList.add("Hello");
        stringList.add("World");
        stringList.add("Java");

        // Populate the map with some data
        map.put("One", 1);
        map.put("Two", 2);
        map.put("Three", 3);

        // Perform some operations on stringList
        for (String str : stringList) {
            System.out.println("String: " + str);
        }

        // Perform some operations on map
        for (String key : map.keySet()) {
            System.out.println("Key: " + key + ", Value: " + map.get(key));
        }

        // Simulate some complex operations
        int sum = 0;
        for (int i = 1; i <= 10; i++) {
            sum += i;
        }
        System.out.println("Sum of first 10 natural numbers: " + sum);

        // Write operation in LinkedList
        /* write */ list.addLast(10);

        // More operations
        for (int i = 0; i < 5; i++) {
            list.add(i * 2);
        }

        // Read operation in LinkedList
        /* read */ int value = list.getLast();
        System.out.println("Last value in LinkedList: " + value);

        // Additional operations
        LinkedList<Double> doubleList = new LinkedList<>();
        for (double d = 0.5; d < 5.0; d += 0.5) {
            doubleList.add(d);
        }
        for (double d : doubleList) {
            System.out.println("Double value: " + d);
        }
    }
}