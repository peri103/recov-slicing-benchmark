import java.util.LinkedList;
import java.util.ArrayList;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        LinkedList<Integer> list = new LinkedList<>();
        ArrayList<String> names = new ArrayList<>();
        HashMap<String, Integer> nameToAge = new HashMap<>();

        // Adding some names and ages to the HashMap
        nameToAge.put("Alice", 30);
        nameToAge.put("Bob", 25);
        nameToAge.put("Charlie", 35);

        // Adding names to the ArrayList
        names.add("Alice");
        names.add("Bob");
        names.add("Charlie");

        // Iterate over the names and print their ages
        for (String name : names) {
            if (nameToAge.containsKey(name)) {
                System.out.println("Age of " + name + ": " + nameToAge.get(name));
            }
        }

        // Adding elements to the LinkedList
        list.add(100);
        list.add(200);
        /* write */ list.addFirst(42);
        list.add(300);

        // Perform some operations on the LinkedList
        int sum = 0;
        for (int num : list) {
            sum += num;
        }
        System.out.println("Sum of all elements in the list: " + sum);

        // Find and print the first element
        /* read */ int firstValue = list.getFirst();
        System.out.println("First element in the list: " + firstValue);

        // Adding more complexity with another LinkedList
        LinkedList<Double> doubleList = new LinkedList<>();
        doubleList.add(1.1);
        doubleList.add(2.2);
        doubleList.add(3.3);

        // Calculating the average of the doubleList
        double total = 0;
        for (double d : doubleList) {
            total += d;
        }
        double average = total / doubleList.size();
        System.out.println("Average of elements in doubleList: " + average);
    }
}