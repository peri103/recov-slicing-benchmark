import java.util.HashMap;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        HashMap<String, Integer> map = new HashMap<>();
        ArrayList<Integer> valuesList = new ArrayList<>();
        
        // Add some values to the ArrayList
        for (int i = 0; i < 5; i++) {
            valuesList.add(i * 10);
        }
        
        // Use a different HashMap for some operations
        HashMap<String, String> stringMap = new HashMap<>();
        stringMap.put("first", "Hello");
        stringMap.put("second", "World");
        
        // Print values from the stringMap
        System.out.println(stringMap.get("first") + " " + stringMap.get("second"));
        
        // Manipulate valuesList
        for (int i = 0; i < valuesList.size(); i++) {
            System.out.println("Value from list: " + valuesList.get(i));
        }
        
        // Original write operation
        /* write */ map.put("key", 42);
        
        // Perform some unrelated operations
        int sum = 0;
        for (int value : valuesList) {
            sum += value;
        }
        System.out.println("Sum of list values: " + sum);
        
        // Original read operation
        /* read */ int value = map.get("key");
        System.out.println("Value from map: " + value);
        
        // Additional operations
        HashMap<Integer, String> numberMap = new HashMap<>();
        numberMap.put(1, "One");
        numberMap.put(2, "Two");
        numberMap.put(3, "Three");
        
        // Print all entries in numberMap
        for (Integer key : numberMap.keySet()) {
            System.out.println("Key: " + key + ", Value: " + numberMap.get(key));
        }
    }
}