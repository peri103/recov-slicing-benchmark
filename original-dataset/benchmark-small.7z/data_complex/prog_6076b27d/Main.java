import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

public class Main {
    public static void main(String[] args) {
        LinkedBlockingQueue<Integer> queue = new LinkedBlockingQueue<>();
        LinkedBlockingQueue<String> stringQueue = new LinkedBlockingQueue<>();
        
        try {
            stringQueue.put("Hello");
            stringQueue.put("World");
            
            /* write */ queue.put(42);
            
            // Simulating some unrelated complex operations
            for (int i = 0; i < 3; i++) {
                stringQueue.put("Message " + i);
            }

            while (!stringQueue.isEmpty()) {
                System.out.println("String Queue: " + stringQueue.take());
            }

            // More complex operations
            if (queue.offer(100, 2, TimeUnit.SECONDS)) {
                System.out.println("Successfully added 100 to the queue");
            }

            // Simulating a delay
            Thread.sleep(1000);

            /* read */ int value = queue.take();
            System.out.println("Value from queue: " + value);
            
            // Additional operations
            for (int i = 0; i < 5; i++) {
                queue.put(i * 10);
            }
            
            while (!queue.isEmpty()) {
                System.out.println("Queue element: " + queue.take());
            }
            
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}