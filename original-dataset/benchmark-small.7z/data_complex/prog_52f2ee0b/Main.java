import java.util.Vector;
import java.util.ArrayList;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        // Original Vector write-read pair
        Vector<Integer> vector = new Vector<>();
        /* write */ vector.addElement(42);

        // Additional complex code
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("Hello");
        arrayList.add("World");

        HashMap<String, Integer> hashMap = new HashMap<>();
        hashMap.put("One", 1);
        hashMap.put("Two", 2);

        int sum = 0;
        for (String key : hashMap.keySet()) {
            sum += hashMap.get(key);
        }

        System.out.println("Sum of HashMap values: " + sum);

        for (String str : arrayList) {
            System.out.println(str);
        }

        // Simulating some operations
        int product = 1;
        for (int i = 1; i <= 5; i++) {
            product *= i;
        }
        System.out.println("Product of numbers from 1 to 5: " + product);

        // More operations
        int max = Integer.MIN_VALUE;
        for (int num : vector) {
            if (num > max) {
                max = num;
            }
        }
        System.out.println("Max value in Vector: " + max);

        // Original read method
        /* read */ int value = vector.elementAt(0);
        System.out.println("Read value from Vector: " + value);
    }
}