import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;
import java.util.PriorityQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class Main {
    public static void main(String[] args) {
        // Custom Delayed element
        class DelayedElement implements Delayed {
            private final long delayTime;
            private final long creationTime;

            public DelayedElement(long delay, TimeUnit unit) {
                this.delayTime = System.currentTimeMillis() + unit.toMillis(delay);
                this.creationTime = System.currentTimeMillis();
            }

            @Override
            public long getDelay(TimeUnit unit) {
                long diff = delayTime - System.currentTimeMillis();
                return unit.convert(diff, TimeUnit.MILLISECONDS);
            }

            @Override
            public int compareTo(Delayed o) {
                if (this.getDelay(TimeUnit.MILLISECONDS) < o.getDelay(TimeUnit.MILLISECONDS)) {
                    return -1;
                }
                if (this.getDelay(TimeUnit.MILLISECONDS) > o.getDelay(TimeUnit.MILLISECONDS)) {
                    return 1;
                }
                return 0;
            }

            @Override
            public String toString() {
                return "DelayedElement{" +
                        "creationTime=" + creationTime +
                        ", delayTime=" + delayTime +
                        '}';
            }
        }

        // Original DelayQueue
        DelayQueue<DelayedElement> queue = new DelayQueue<>();

        /* write */
        DelayedElement element = new DelayedElement(5, TimeUnit.SECONDS);
        queue.put(element);

        // Additional PriorityQueue usage
        PriorityQueue<Integer> priorityQueue = new PriorityQueue<>();
        priorityQueue.add(10);
        priorityQueue.add(5);
        priorityQueue.add(20);

        System.out.println("PriorityQueue elements:");
        while (!priorityQueue.isEmpty()) {
            System.out.println(priorityQueue.poll());
        }

        // Additional BlockingQueue usage
        BlockingQueue<String> blockingQueue = new LinkedBlockingQueue<>();
        try {
            blockingQueue.put("Hello");
            blockingQueue.put("World");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("BlockingQueue elements:");
        while (!blockingQueue.isEmpty()) {
            try {
                System.out.println(blockingQueue.take());
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Simulate some complex operations
        for (int i = 0; i < 3; i++) {
            System.out.println("Performing complex operation " + i);
            try {
                Thread.sleep(1000); // Simulate time-consuming task
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        try {
            /* read */
            DelayedElement takenElement = queue.take();
            System.out.println("Taken element: " + takenElement);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}