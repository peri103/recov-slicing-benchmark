import java.util.Properties;
import java.util.HashMap;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Original Properties usage
        Properties properties = new Properties();
        /* write */ properties.setProperty("key", "value");

        // Additional HashMap usage
        HashMap<String, Integer> map = new HashMap<>();
        map.put("one", 1);
        map.put("two", 2);
        map.put("three", 3);

        // Iterate through HashMap
        for (String key : map.keySet()) {
            System.out.println("Key: " + key + ", Value: " + map.get(key));
        }

        // Additional ArrayList usage
        ArrayList<String> list = new ArrayList<>();
        list.add("apple");
        list.add("banana");
        list.add("cherry");

        // Iterate through ArrayList
        for (String fruit : list) {
            System.out.println("Fruit: " + fruit);
        }

        // Additional Properties usage
        properties.setProperty("anotherKey", "anotherValue");
        String anotherValue = properties.getProperty("anotherKey");
        System.out.println("Another Value: " + anotherValue);

        // Read from the original Properties
        /* read */ String value = properties.getProperty("key");
        System.out.println("Original Value: " + value);
    }
}