import java.util.concurrent.LinkedTransferQueue;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.Queue;
import java.util.Stack;

public class Main {
    public static void main(String[] args) {
        LinkedTransferQueue<Integer> queue = new LinkedTransferQueue<>();
        ArrayBlockingQueue<String> stringQueue = new ArrayBlockingQueue<>(10);
        Stack<Double> stack = new Stack<>();
        
        try {
            stringQueue.put("Hello");
            stringQueue.put("World");
            
            stack.push(3.14);
            stack.push(2.71);
            
            /* write */ queue.put(42);
            
            while (!stack.isEmpty()) {
                System.out.println("Stack element: " + stack.pop());
            }
            
            Queue<String> tempQueue = new ArrayBlockingQueue<>(10);
            tempQueue.add(stringQueue.take());
            tempQueue.add(stringQueue.take());
            
            for (String s : tempQueue) {
                System.out.println("String Queue element: " + s);
            }
            
            /* read */ int value = queue.take();
            System.out.println("Read value from LinkedTransferQueue: " + value);
            
            for (int i = 0; i < 5; i++) {
                queue.put(i * 10);
            }
            
            while (!queue.isEmpty()) {
                System.out.println("Queue element: " + queue.take());
            }
            
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}