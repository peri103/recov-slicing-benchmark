import java.util.concurrent.CopyOnWriteArrayList;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        CopyOnWriteArrayList<Integer> list = new CopyOnWriteArrayList<>();
        CopyOnWriteArrayList<String> stringList = new CopyOnWriteArrayList<>();
        Map<String, Integer> map = new HashMap<>();
        
        /* write */ list.add(42);
        stringList.add("Hello");
        stringList.add("World");
        
        map.put("One", 1);
        map.put("Two", 2);
        
        for (String str : stringList) {
            System.out.println("StringList Element: " + str);
        }
        
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println("Map Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }
        
        int sum = 0;
        for (int i = 0; i < 10; i++) {
            sum += i;
        }
        System.out.println("Sum of first 10 numbers is: " + sum);
        
        /* read */ int value = list.get(0);
        System.out.println("Value from list: " + value);
        
        CopyOnWriteArrayList<Double> doubleList = new CopyOnWriteArrayList<>();
        for (double i = 0.5; i < 5; i += 0.5) {
            doubleList.add(i);
        }
        
        double total = 0;
        for (Double d : doubleList) {
            total += d;
        }
        System.out.println("Total of doubleList: " + total);
    }
}