import java.util.TreeSet;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        TreeSet<Integer> treeSet = new TreeSet<>();
        HashMap<String, Integer> map = new HashMap<>();
        ArrayList<Integer> list = new ArrayList<>();

        // Adding some elements to the map
        map.put("One", 1);
        map.put("Two", 2);
        map.put("Three", 3);

        // Adding elements to the list
        for (int i = 10; i <= 50; i += 10) {
            list.add(i);
        }

        // Process map entries
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }

        // Working with TreeSet
        /* write */ treeSet.add(42);
        
        // Additional operations on TreeSet
        treeSet.add(15);
        treeSet.add(30);
        treeSet.add(60);

        // Iterate over the list and add to TreeSet
        for (Integer num : list) {
            treeSet.add(num);
        }

        // Check if specific elements exist in TreeSet
        System.out.println("TreeSet contains 15: " + treeSet.contains(15));
        System.out.println("TreeSet contains 60: " + treeSet.contains(60));

        // Perform some calculations
        int sum = 0;
        for (Integer num : list) {
            sum += num;
        }
        System.out.println("Sum of list elements: " + sum);

        // More complex operations
        ArrayList<Integer> newList = new ArrayList<>();
        for (Integer num : treeSet) {
            if (num % 2 == 0) {
                newList.add(num);
            }
        }
        System.out.println("Even numbers in TreeSet: " + newList);

        // Final read
        /* read */ boolean containsValue = treeSet.contains(42);
        System.out.println("TreeSet contains 42: " + containsValue);
    }
}