import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;

public class Main {
    public static void main(String[] args) {
        ConcurrentHashMap<String, Integer> map = new ConcurrentHashMap<>();
        ConcurrentLinkedQueue<String> queue = new ConcurrentLinkedQueue<>();
        AtomicInteger counter = new AtomicInteger(0);

        // Adding some initial values to the queue
        queue.add("first");
        queue.add("second");
        queue.add("third");

        // Using AtomicInteger to count elements processed
        while (!queue.isEmpty()) {
            String element = queue.poll();
            System.out.println("Processing: " + element);
            counter.incrementAndGet();
        }

        // Using putIfAbsent to ensure the key-value pair is added only if absent
        /* write */ map.putIfAbsent("key", 100);

        // Performing some unrelated calculations
        int sum = 0;
        for (int i = 0; i < 10; i++) {
            sum += i;
        }
        System.out.println("Sum of first 10 numbers: " + sum);

        // Simulating some delay or additional operations
        try {
            Thread.sleep(200);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Reading the value from the map
        /* read */ Integer value = map.get("key");
        System.out.println("Value from map: " + value);

        // Displaying the count of processed elements
        System.out.println("Total elements processed: " + counter.get());

        // Adding more complex operations
        for (int i = 1; i <= 5; i++) {
            map.put("key" + i, i * 10);
        }

        for (int i = 1; i <= 5; i++) {
            System.out.println("Value for key" + i + ": " + map.get("key" + i));
        }
    }
}