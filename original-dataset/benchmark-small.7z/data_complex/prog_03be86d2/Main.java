import java.util.PriorityQueue;
import java.util.ArrayList;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        PriorityQueue<Integer> queue = new PriorityQueue<>();
        ArrayList<String> names = new ArrayList<>();
        HashMap<String, Integer> nameToAgeMap = new HashMap<>();
        
        // Adding some names to the list
        names.add("Alice");
        names.add("Bob");
        names.add("Charlie");
        
        // Adding some ages to the map
        nameToAgeMap.put("Alice", 30);
        nameToAgeMap.put("Bob", 25);
        nameToAgeMap.put("Charlie", 35);
        
        // Displaying names and their ages
        for (String name : names) {
            System.out.println(name + " is " + nameToAgeMap.get(name) + " years old.");
        }
        
        /* write */ queue.offer(10);
        queue.offer(20);
        queue.offer(5);
        
        // Performing some operations on the queue
        int size = queue.size();
        System.out.println("Size of the queue: " + size);
        
        // Adding more elements to the queue
        queue.offer(15);
        queue.offer(25);
        
        // Displaying all elements in the queue
        System.out.println("Elements in the queue:");
        for (Integer num : queue) {
            System.out.println(num);
        }
        
        // Some unrelated calculations
        int sum = 0;
        for (int i = 0; i < 10; i++) {
            sum += i;
        }
        System.out.println("Sum of numbers from 0 to 9: " + sum);
        
        /* read */ int value = queue.poll();
        System.out.println("Polled value from the queue: " + value);
        
        // More operations on the map
        nameToAgeMap.put("David", 40);
        System.out.println("David's age is " + nameToAgeMap.get("David"));
        
        // Final display of the queue
        System.out.println("Final elements in the queue:");
        while (!queue.isEmpty()) {
            System.out.println(queue.poll());
        }
    }
}