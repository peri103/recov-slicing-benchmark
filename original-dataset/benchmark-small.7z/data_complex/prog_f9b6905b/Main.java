import java.util.concurrent.PriorityBlockingQueue;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        PriorityBlockingQueue<Integer> queue = new PriorityBlockingQueue<>();
        HashMap<String, String> map = new HashMap<>();
        map.put("key1", "value1");
        map.put("key2", "value2");

        // Additional queue operations
        PriorityBlockingQueue<Integer> additionalQueue = new PriorityBlockingQueue<>();
        additionalQueue.offer(100);
        additionalQueue.offer(200);

        /* write */ queue.offer(42);

        // Simulate some processing
        for (Map.Entry<String, String> entry : map.entrySet()) {
            System.out.println("Processing: " + entry.getKey() + " -> " + entry.getValue());
        }

        // More operations on additionalQueue
        Integer additionalValue = additionalQueue.poll();
        System.out.println("Additional Queue Value: " + additionalValue);

        // Complex operations with map
        if (map.containsKey("key1")) {
            System.out.println("Found key1: " + map.get("key1"));
        }

        // Further processing
        for (int i = 0; i < 5; i++) {
            additionalQueue.offer(i * 10);
        }

        /* read */ Integer value = queue.poll();
        System.out.println("Original Queue Value: " + value);

        // Process remaining values in additionalQueue
        while (!additionalQueue.isEmpty()) {
            System.out.println("Processing additional queue value: " + additionalQueue.poll());
        }
    }
}