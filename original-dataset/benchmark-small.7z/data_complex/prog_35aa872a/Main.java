import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        BlockingQueue<Integer> queue = new LinkedBlockingQueue<>();
        List<Integer> numberList = new ArrayList<>();
        
        // Add some numbers to the list
        for (int i = 0; i < 10; i++) {
            numberList.add(i * 10);
        }
        
        // Process the list and add to the queue
        for (Integer number : numberList) {
            try {
                queue.put(number);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Do some unrelated computation
        int sum = 0;
        for (int i = 0; i < numberList.size(); i++) {
            sum += numberList.get(i);
        }
        System.out.println("Sum of numbers: " + sum);

        // Remove an element from the queue
        try {
            /* write */ queue.put(42);
            int firstValue = queue.take(); // Take the first element
            System.out.println("First value taken from queue: " + firstValue);
            
            // Process more elements from the queue
            while (!queue.isEmpty()) {
                int value = queue.take();
                System.out.println("Value from queue: " + value);
            }
            
            /* read */ int finalValue = queue.take();
            System.out.println("Final value taken from queue: " + finalValue);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}