import java.util.SortedMap;
import java.util.TreeMap;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        SortedMap<String, Integer> sortedMap = new TreeMap<>();
        HashMap<String, String> hashMap = new HashMap<>();
        Map<Integer, String> numberMap = new TreeMap<>();

        // Add some values to the hashMap
        hashMap.put("A", "Apple");
        hashMap.put("B", "Banana");
        hashMap.put("C", "Cherry");

        // Add some values to the numberMap
        numberMap.put(1, "One");
        numberMap.put(2, "Two");
        numberMap.put(3, "Three");

        // Iterate over hashMap and print keys and values
        for (Map.Entry<String, String> entry : hashMap.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

        // Perform some operations on numberMap
        numberMap.remove(2);
        numberMap.put(4, "Four");

        // Print numberMap contents
        for (Map.Entry<Integer, String> entry : numberMap.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

        /* write */ sortedMap.put("key1", 100);

        // Do some unrelated computations
        int sum = 0;
        for (int i = 0; i < 10; i++) {
            sum += i;
        }
        System.out.println("Sum of first 10 numbers: " + sum);

        // More complex operations
        for (String key : hashMap.keySet()) {
            sortedMap.put(key, key.length() * 10);
        }

        // Print the sortedMap values
        for (Map.Entry<String, Integer> entry : sortedMap.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

        /* read */ Integer value = sortedMap.get("key1");
        System.out.println("Value for 'key1': " + value);

        // Additional complex logic
        Map<String, Integer> combinedMap = new TreeMap<>();
        combinedMap.putAll(sortedMap);
        combinedMap.put("D", 400);

        for (Map.Entry<String, Integer> entry : combinedMap.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
}