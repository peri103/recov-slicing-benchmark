import java.util.SortedMap;
import java.util.TreeMap;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        SortedMap<Integer, String> sortedMap = new TreeMap<>();
        HashMap<Integer, String> hashMap = new HashMap<>();
        
        // Writing to the sortedMap
        /* write */ sortedMap.put(1, "Hello");

        // Adding more elements to sortedMap
        sortedMap.put(2, "World");
        sortedMap.put(3, "Java");
        
        // Writing to hashMap
        hashMap.put(1, "HashMapValue1");
        hashMap.put(2, "HashMapValue2");

        // Processing elements in hashMap
        for (Map.Entry<Integer, String> entry : hashMap.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }

        // Some unrelated code to make the program more complex
        int sum = 0;
        for (int i = 0; i < 10; i++) {
            sum += i;
        }
        System.out.println("Sum of first 10 numbers: " + sum);

        // Reading from sortedMap
        /* read */ String value = sortedMap.get(1);
        System.out.println(value);

        // Further processing of sortedMap
        for (Map.Entry<Integer, String> entry : sortedMap.entrySet()) {
            System.out.println("SortedMap Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }
    }
}