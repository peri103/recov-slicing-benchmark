import java.util.PriorityQueue;
import java.util.ArrayList;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        PriorityQueue<Integer> queue = new PriorityQueue<>();
        ArrayList<String> names = new ArrayList<>();
        HashMap<String, Integer> nameMap = new HashMap<>();

        // Adding elements to the ArrayList
        names.add("Alice");
        names.add("Bob");
        names.add("Charlie");

        // Mapping names to their lengths
        for (String name : names) {
            nameMap.put(name, name.length());
        }

        // Adding elements to the PriorityQueue
        queue.offer(15);
        queue.offer(30);
        /* write */ queue.offer(42);
        queue.offer(50);

        // Processing the elements in the HashMap
        for (String key : nameMap.keySet()) {
            System.out.println("Name: " + key + ", Length: " + nameMap.get(key));
        }

        // Performing some operations with the ArrayList
        for (String name : names) {
            System.out.println("Hello, " + name + "!");
        }

        // Simulating some complex operations
        int sum = 0;
        for (int i = 0; i < 10; i++) {
            sum += i;
        }
        System.out.println("Sum of numbers from 0 to 9: " + sum);

        // Reading from the PriorityQueue
        /* read */ Integer value = queue.peek();
        System.out.println("Peek value from PriorityQueue: " + value);

        // Further operations with PriorityQueue
        while (!queue.isEmpty()) {
            Integer polledValue = queue.poll();
            System.out.println("Polled value: " + polledValue);
        }
    }
}