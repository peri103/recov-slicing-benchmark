import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        BlockingDeque<Integer> deque = new LinkedBlockingDeque<>();
        ArrayList<String> names = new ArrayList<>();
        names.add("Alice");
        names.add("Bob");
        names.add("Charlie");

        HashMap<String, Integer> ageMap = new HashMap<>();
        ageMap.put("Alice", 25);
        ageMap.put("Bob", 30);
        ageMap.put("Charlie", 35);

        /* write */ deque.addFirst(42);

        for (String name : names) {
            System.out.println("Name: " + name);
        }

        for (Map.Entry<String, Integer> entry : ageMap.entrySet()) {
            System.out.println(entry.getKey() + " is " + entry.getValue() + " years old.");
        }

        try {
            Thread.sleep(1000); // Simulate some processing delay
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        try {
            /* read */ int value = deque.takeFirst();
            System.out.println("Deque value: " + value);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        int sumOfAges = 0;
        for (int age : ageMap.values()) {
            sumOfAges += age;
        }
        System.out.println("Total age: " + sumOfAges);
    }
}