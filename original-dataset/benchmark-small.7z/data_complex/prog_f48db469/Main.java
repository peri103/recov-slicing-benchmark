import java.util.TreeSet;
import java.util.HashSet;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        TreeSet<Integer> set = new TreeSet<>();
        HashSet<String> hashSet = new HashSet<>();
        ArrayList<Double> arrayList = new ArrayList<>();
        
        // Adding elements to hashSet
        hashSet.add("Hello");
        hashSet.add("World");

        // Adding elements to arrayList
        arrayList.add(3.14);
        arrayList.add(1.618);

        // Performing operations on hashSet
        if (hashSet.contains("Hello")) {
            System.out.println("HashSet contains 'Hello'");
        }

        // Performing operations on arrayList
        for (Double d : arrayList) {
            System.out.println("ArrayList element: " + d);
        }

        // Introducing a loop to add elements to set
        for (int i = 0; i < 5; i++) {
            /* write */ set.add(i * 10);
        }

        // Performing operations on set without affecting the original write-read pair
        set.remove(20); // Removing an element

        // Introducing a loop to check if elements are present in set
        for (int i = 0; i < 50; i += 10) {
            /* read */ boolean containsValue = set.contains(i);
            System.out.println("TreeSet contains " + i + ": " + containsValue);
        }

        // More complex operations with arrayList
        arrayList.add(Math.sqrt(16));
        arrayList.add(Math.pow(2, 3));

        for (Double d : arrayList) {
            System.out.println("Updated ArrayList element: " + d);
        }
    }
}