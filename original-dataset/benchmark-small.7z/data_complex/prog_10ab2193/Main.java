import java.util.concurrent.LinkedTransferQueue;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;

public class Main {
    public static void main(String[] args) {
        LinkedTransferQueue<Integer> queue = new LinkedTransferQueue<>();
        ArrayBlockingQueue<String> stringQueue = new ArrayBlockingQueue<>(10);
        Map<String, Integer> map = new HashMap<>();

        // Adding some elements to the map
        map.put("One", 1);
        map.put("Two", 2);
        map.put("Three", 3);

        // Operating on the map
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        // Adding elements to another queue
        stringQueue.offer("Hello");
        stringQueue.offer("World");

        // Processing the stringQueue
        while (!stringQueue.isEmpty()) {
            System.out.println("StringQueue Element: " + stringQueue.poll());
        }

        /* write */ queue.offer(42);

        // Doing some unrelated computations
        int sum = 0;
        for (int i = 0; i < 10; i++) {
            sum += i;
        }
        System.out.println("Sum of first 10 natural numbers: " + sum);

        // More unrelated computations
        int factorial = 1;
        for (int i = 1; i <= 5; i++) {
            factorial *= i;
        }
        System.out.println("Factorial of 5: " + factorial);

        /* read */ Integer value = queue.poll();
        System.out.println("Polled value from queue: " + value);

        // Further processing with the map
        map.put("Four", 4);
        if (map.containsKey("Four")) {
            System.out.println("Map contains 'Four'");
        }
    }
}