import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        PriorityBlockingQueue<Integer> queue = new PriorityBlockingQueue<>();
        ArrayBlockingQueue<String> stringQueue = new ArrayBlockingQueue<>(10);
        ArrayList<Integer> numbers = new ArrayList<>();

        // Add some elements to ArrayBlockingQueue
        stringQueue.offer("Hello");
        stringQueue.offer("World");

        // Add some numbers to ArrayList
        for (int i = 0; i < 5; i++) {
            numbers.add(i * 2);
        }

        // Process the ArrayList elements
        for (Integer num : numbers) {
            System.out.println("Number: " + num);
        }

        /* write */ queue.offer(10);

        // Process the ArrayBlockingQueue
        while (!stringQueue.isEmpty()) {
            String str = stringQueue.poll();
            System.out.println("String from queue: " + str);
        }

        // Add more elements to PriorityBlockingQueue
        queue.offer(20);
        queue.offer(30);

        // Some unrelated computation
        int sum = 0;
        for (int i = 0; i < 10; i++) {
            sum += i;
        }
        System.out.println("Sum of first 10 natural numbers: " + sum);

        /* read */ Integer value = queue.poll();
        System.out.println("Polled value from PriorityBlockingQueue: " + value);

        // Further processing of PriorityBlockingQueue
        while (!queue.isEmpty()) {
            Integer num = queue.poll();
            System.out.println("Remaining number in PriorityBlockingQueue: " + num);
        }
    }
}