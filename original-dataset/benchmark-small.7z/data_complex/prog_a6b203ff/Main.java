import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Initialize the BlockingDeque
        BlockingDeque<Integer> deque = new LinkedBlockingDeque<>();

        // Additional data structure
        List<String> stringList = new ArrayList<>();

        // Write operation: add an element to the front of the deque
        /* write */ deque.addFirst(42);

        // Populate the stringList with some data
        stringList.add("Hello");
        stringList.add("World");
        stringList.add("!");

        // Process the stringList
        for (String str : stringList) {
            System.out.println("Processing string: " + str);
        }

        // Add more elements to the deque
        deque.addLast(100);
        deque.addLast(200);

        // Perform some unrelated operations
        int sum = 0;
        for (int i = 0; i < 10; i++) {
            sum += i;
        }
        System.out.println("Sum of first 10 numbers: " + sum);

        try {
            // Read operation: take the first element from the deque
            /* read */ int value = deque.takeFirst();
            System.out.println("First value in deque: " + value);

            // Take another element from the deque
            int secondValue = deque.takeFirst();
            System.out.println("Second value in deque: " + secondValue);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Additional logic
        for (int i = 0; i < 5; i++) {
            stringList.add("Extra " + i);
        }

        // Print all elements in stringList
        for (String str : stringList) {
            System.out.println("StringList element: " + str);
        }
    }
}