import java.util.Vector;
import java.util.ArrayList;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        Vector<Integer> vector = new Vector<>();
        ArrayList<String> stringList = new ArrayList<>();
        HashMap<String, Integer> map = new HashMap<>();
        
        // Adding some strings to the ArrayList
        stringList.add("Hello");
        stringList.add("World");
        
        // Adding key-value pairs to HashMap
        map.put("One", 1);
        map.put("Two", 2);

        // Performing some operations on the HashMap
        if (map.containsKey("One")) {
            System.out.println("Map contains key 'One'");
        }

        // Working with Vector
        /* write */ vector.add(42);
        
        // Performing operations on the ArrayList
        for (String str : stringList) {
            System.out.println("String in list: " + str);
        }

        // Performing operations on the HashMap
        for (String key : map.keySet()) {
            System.out.println("Key: " + key + ", Value: " + map.get(key));
        }

        // More unrelated computations
        int sum = 0;
        for (int i = 1; i <= 10; i++) {
            sum += i;
        }
        System.out.println("Sum of numbers from 1 to 10: " + sum);

        // Reading from the Vector
        /* read */ int value = vector.get(0);
        System.out.println("Value from vector: " + value);

        // Additional operations on Vector
        vector.add(100);
        vector.add(200);
        for (int i = 0; i < vector.size(); i++) {
            System.out.println("Vector element at index " + i + ": " + vector.get(i));
        }
    }
}