import java.util.TreeSet;
import java.util.HashMap;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        TreeSet<Integer> set = new TreeSet<>();
        HashMap<String, Integer> map = new HashMap<>();
        ArrayList<Integer> list = new ArrayList<>();

        map.put("first", 10);
        map.put("second", 20);
        
        for (String key : map.keySet()) {
            list.add(map.get(key));
        }

        /* write */ set.add(42);

        for (int i = 0; i < list.size(); i++) {
            System.out.println("List element: " + list.get(i));
        }

        if (map.containsKey("first")) {
            System.out.println("Map contains key 'first' with value: " + map.get("first"));
        }

        int sum = 0;
        for (Integer num : set) {
            sum += num;
        }
        System.out.println("Sum of elements in set: " + sum);

        /* read */ boolean contains = set.contains(42);
        System.out.println("Set contains 42: " + contains);

        set.add(100);
        set.add(200);

        for (Integer num : set) {
            System.out.println("Set element: " + num);
        }
    }
}