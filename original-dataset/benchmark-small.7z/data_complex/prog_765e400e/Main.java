import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        ConcurrentLinkedQueue<Integer> queue = new ConcurrentLinkedQueue<>();
        ArrayList<Integer> arrayList = new ArrayList<>();
        HashMap<String, Integer> hashMap = new HashMap<>();

        /* write */ queue.offer(42);

        // Adding elements to the ArrayList
        for (int i = 0; i < 5; i++) {
            arrayList.add(i * 10);
        }

        // Adding elements to the HashMap
        hashMap.put("A", 1);
        hashMap.put("B", 2);
        hashMap.put("C", 3);

        // Iterating over the ArrayList
        for (int i = 0; i < arrayList.size(); i++) {
            System.out.println("ArrayList element: " + arrayList.get(i));
        }

        // Iterating over the HashMap
        for (Map.Entry<String, Integer> entry : hashMap.entrySet()) {
            System.out.println("HashMap key: " + entry.getKey() + ", value: " + entry.getValue());
        }

        // Simulating some processing
        int sum = 0;
        for (int i = 0; i < 10; i++) {
            sum += i;
        }
        System.out.println("Sum of first 10 natural numbers: " + sum);

        // More operations on the queue
        queue.offer(100);
        queue.offer(200);

        // Removing an element from the queue
        Integer firstElement = queue.poll();
        System.out.println("First element removed from queue: " + firstElement);

        // Continue with more operations on the queue
        while (!queue.isEmpty()) {
            /* read */ Integer value = queue.poll();
            System.out.println("Processed value from queue: " + value);
        }
    }
}