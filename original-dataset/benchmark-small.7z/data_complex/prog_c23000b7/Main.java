import java.util.Vector;
import java.util.ArrayList;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        Vector<Integer> vector = new Vector<>();
        ArrayList<String> arrayList = new ArrayList<>();
        HashMap<String, Integer> map = new HashMap<>();

        // Adding elements to the ArrayList
        arrayList.add("First");
        arrayList.add("Second");
        arrayList.add("Third");

        // Adding elements to the HashMap
        map.put("One", 1);
        map.put("Two", 2);
        map.put("Three", 3);

        // Perform some operations on the ArrayList
        for (String str : arrayList) {
            System.out.println("ArrayList Element: " + str);
        }

        // Perform some operations on the HashMap
        for (String key : map.keySet()) {
            System.out.println("HashMap Key: " + key + ", Value: " + map.get(key));
        }

        // Add an element to the Vector
        /* write */ vector.addElement(10);

        // Perform some unrelated operations
        for (int i = 0; i < 5; i++) {
            vector.addElement(i * 2);
        }

        // Do some calculations
        int sum = 0;
        for (int i = 0; i < vector.size(); i++) {
            sum += vector.elementAt(i);
        }
        System.out.println("Sum of Vector elements: " + sum);

        // Read the first element of the Vector
        /* read */ int value = vector.elementAt(0);
        System.out.println("First element in Vector: " + value);

        // Add more elements to the Vector
        for (int i = 5; i < 10; i++) {
            vector.addElement(i * 3);
        }

        // Print all elements in the Vector
        for (int i = 0; i < vector.size(); i++) {
            System.out.println("Vector Element at index " + i + ": " + vector.elementAt(i));
        }
    }
}