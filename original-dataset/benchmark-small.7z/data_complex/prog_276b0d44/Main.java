import java.util.LinkedList;
import java.util.ArrayList;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        LinkedList<Integer> list = new LinkedList<>();
        ArrayList<String> stringList = new ArrayList<>();
        HashMap<String, Integer> map = new HashMap<>();

        // Adding elements to the LinkedList
        list.add(10);
        list.add(20);
        list.add(30);

        // Adding elements to the ArrayList
        stringList.add("Hello");
        stringList.add("World");

        // Adding key-value pairs to the HashMap
        map.put("One", 1);
        map.put("Two", 2);
        map.put("Three", 3);

        // Perform some operations with the ArrayList
        for (String str : stringList) {
            System.out.println("String from ArrayList: " + str);
        }

        // Perform some operations with the HashMap
        for (String key : map.keySet()) {
            System.out.println("Key: " + key + ", Value: " + map.get(key));
        }

        // Adding more elements to the LinkedList
        list.add(40);
        list.add(50);

        // Complex operation: sum of all elements in the LinkedList
        int sum = 0;
        for (int num : list) {
            sum += num;
        }
        System.out.println("Sum of LinkedList elements: " + sum);

        // Original write-read pair
        /* write */ list.addLast(42);
        
        // More operations
        if (!list.isEmpty()) {
            System.out.println("First element in LinkedList: " + list.getFirst());
        }

        // Another complex operation: find the maximum in the LinkedList
        int max = Integer.MIN_VALUE;
        for (int num : list) {
            if (num > max) {
                max = num;
            }
        }
        System.out.println("Maximum element in LinkedList: " + max);

        // Original read
        /* read */ int value = list.getLast();
        System.out.println("Last element in LinkedList: " + value);
    }
}