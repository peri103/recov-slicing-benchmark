import java.util.HashSet;
import java.util.ArrayList;
import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {
        HashSet<Integer> set = new HashSet<>();
        ArrayList<Integer> list = new ArrayList<>();
        LinkedList<String> queue = new LinkedList<>();

        // Add elements to the list
        for (int i = 0; i < 5; i++) {
            list.add(i * 5);
        }

        // Add elements to the queue
        queue.add("Hello");
        queue.add("World");

        // Print all elements in the list
        for (int number : list) {
            System.out.println("List contains: " + number);
        }

        // Print all elements in the queue
        while (!queue.isEmpty()) {
            System.out.println("Queue element: " + queue.poll());
        }

        /* write */ set.add(10);

        // Add more elements to the set
        set.add(20);
        set.add(30);

        // Check if certain elements exist in the set
        boolean containsTwenty = set.contains(20);
        boolean containsForty = set.contains(40);

        /* read */ boolean containsValue = set.contains(10);

        // Print the results of the contains checks
        System.out.println("Set contains 10: " + containsValue);
        System.out.println("Set contains 20: " + containsTwenty);
        System.out.println("Set contains 40: " + containsForty);

        // Add all elements from the list to the set
        set.addAll(list);

        // Print all elements in the set
        System.out.println("All elements in the set:");
        for (int number : set) {
            System.out.println(number);
        }
    }
}