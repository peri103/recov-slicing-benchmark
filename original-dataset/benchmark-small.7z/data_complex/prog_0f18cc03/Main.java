import java.util.concurrent.LinkedTransferQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.ArrayList;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        LinkedTransferQueue<Integer> queue = new LinkedTransferQueue<>();
        LinkedBlockingQueue<String> blockingQueue = new LinkedBlockingQueue<>();
        ArrayList<Integer> arrayList = new ArrayList<>();
        HashMap<String, Integer> map = new HashMap<>();

        /* write */ queue.offer(1);
        
        // Adding elements to the blocking queue
        blockingQueue.offer("Hello");
        blockingQueue.offer("World");
        
        // Adding elements to the array list
        for (int i = 0; i < 5; i++) {
            arrayList.add(i * 2);
        }
        
        // Adding key-value pairs to the map
        map.put("One", 1);
        map.put("Two", 2);
        
        // Processing elements in the blocking queue
        while (!blockingQueue.isEmpty()) {
            System.out.println("BlockingQueue: " + blockingQueue.poll());
        }
        
        // Processing elements in the array list
        for (int value : arrayList) {
            System.out.println("ArrayList: " + value);
        }
        
        // Processing elements in the map
        for (String key : map.keySet()) {
            System.out.println("Map: " + key + " -> " + map.get(key));
        }
        
        /* read */ Integer value = queue.poll();
        System.out.println("LinkedTransferQueue: " + value);
    }
}