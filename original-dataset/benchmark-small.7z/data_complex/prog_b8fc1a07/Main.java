import java.util.HashSet;
import java.util.ArrayList;
import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {
        HashSet<Integer> set = new HashSet<>();
        ArrayList<Integer> arrayList = new ArrayList<>();
        LinkedList<String> linkedList = new LinkedList<>();

        // Adding elements to ArrayList
        for (int i = 1; i <= 5; i++) {
            arrayList.add(i * 10);
        }

        // Adding elements to LinkedList
        linkedList.add("Hello");
        linkedList.add("World");
        
        // Iterating over ArrayList
        for (Integer num : arrayList) {
            System.out.println("ArrayList item: " + num);
        }

        // Iterating over LinkedList
        for (String str : linkedList) {
            System.out.println("LinkedList item: " + str);
        }
        
        // Performing operations on HashSet
        /* write */ set.add(42);
        set.add(55);
        set.remove(55);
        
        // Some unrelated computation
        int sum = 0;
        for (int i = 0; i < 10; i++) {
            sum += i;
        }
        System.out.println("Sum of first 10 numbers: " + sum);

        // Further operations on HashSet
        if (set.add(99)) {
            System.out.println("99 was added to the set.");
        } else {
            System.out.println("99 was already in the set.");
        }

        // Checking for presence of elements
        /* read */ boolean containsValue = set.contains(42);
        System.out.println("Contains 42: " + containsValue);
        
        // More unrelated code
        int product = 1;
        for (int i = 1; i <= 5; i++) {
            product *= i;
        }
        System.out.println("Product of first 5 numbers: " + product);

        // Final operations
        set.clear();
        System.out.println("HashSet cleared. Size: " + set.size());
    }
}