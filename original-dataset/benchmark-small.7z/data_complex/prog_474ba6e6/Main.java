import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.Queue;

public class Main {
    public static void main(String[] args) {
        BlockingDeque<Integer> deque = new LinkedBlockingDeque<>();
        BlockingQueue<String> queue = new LinkedBlockingQueue<>();
        
        /* write */ deque.addLast(42);
        
        // Add elements to the queue
        queue.add("Hello");
        queue.add("World");

        // Process the queue
        while (!queue.isEmpty()) {
            try {
                String message = queue.take();
                System.out.println("Processing message: " + message);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Perform some unrelated calculations
        int sum = 0;
        for (int i = 0; i < 10; i++) {
            sum += i;
        }
        System.out.println("Sum of first 10 numbers: " + sum);

        // Add more elements to the deque
        deque.addLast(84);
        deque.addLast(168);

        // Perform operations on the deque
        try {
            Integer firstElement = deque.takeFirst();
            System.out.println("First element taken: " + firstElement);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // More complex data manipulation
        Queue<Double> doubleQueue = new LinkedBlockingQueue<>();
        for (double d = 0.5; d < 5; d += 0.5) {
            doubleQueue.add(d);
        }

        // Process the double queue
        while (!doubleQueue.isEmpty()) {
            double value = doubleQueue.poll();
            System.out.println("Processing double value: " + value);
        }

        // Final read operation
        try {
            /* read */ int value = deque.takeLast();
            System.out.println("Last element taken: " + value);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}