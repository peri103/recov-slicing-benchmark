import java.util.concurrent.ConcurrentSkipListMap;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        ConcurrentSkipListMap<Integer, String> map = new ConcurrentSkipListMap<>();
        ArrayList<Integer> numberList = new ArrayList<>();
        HashMap<String, Integer> wordCountMap = new HashMap<>();
        
        // Fill numberList with some values
        for (int i = 0; i < 10; i++) {
            numberList.add(i * 2);
        }
        
        // Fill wordCountMap with some values
        wordCountMap.put("apple", 3);
        wordCountMap.put("banana", 2);
        wordCountMap.put("cherry", 5);

        // Add some values to the map
        map.put(2, "Two");
        map.put(3, "Three");
        map.put(4, "Four");
        
        /* write */ map.put(1, "Hello World");
        
        // Perform some operations on numberList
        int sum = 0;
        for (Integer number : numberList) {
            sum += number;
        }
        System.out.println("Sum of numbers: " + sum);
        
        // Perform some operations on wordCountMap
        for (String key : wordCountMap.keySet()) {
            System.out.println("Word: " + key + ", Count: " + wordCountMap.get(key));
        }
        
        // Simulate some delay or different operations
        List<String> greetings = new ArrayList<>();
        greetings.add("Hi");
        greetings.add("Hello");
        greetings.add("Hey");
        
        for (String greeting : greetings) {
            System.out.println(greeting);
        }

        /* read */ String value = map.get(1);
        System.out.println(value);
    }
}