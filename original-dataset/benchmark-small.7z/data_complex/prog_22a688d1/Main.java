import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.PriorityBlockingQueue;

public class Main {
    public static void main(String[] args) {
        try {
            ArrayBlockingQueue<Integer> queue = new ArrayBlockingQueue<>(10);
            LinkedBlockingQueue<String> stringQueue = new LinkedBlockingQueue<>();
            PriorityBlockingQueue<Double> priorityQueue = new PriorityBlockingQueue<>();

            // Add some elements to the stringQueue
            stringQueue.put("Hello");
            stringQueue.put("World");

            // Add some elements to the priorityQueue
            priorityQueue.put(3.14);
            priorityQueue.put(1.59);
            priorityQueue.put(2.65);

            /* write */ queue.put(42);

            // Process elements from stringQueue
            while (!stringQueue.isEmpty()) {
                String str = stringQueue.take();
                System.out.println("StringQueue: " + str);
            }

            // Process elements from priorityQueue
            while (!priorityQueue.isEmpty()) {
                Double num = priorityQueue.take();
                System.out.println("PriorityQueue: " + num);
            }

            // Perform some calculations
            int sum = 0;
            for (int i = 0; i < 5; i++) {
                sum += i * 2;
            }
            System.out.println("Sum of first 5 even numbers: " + sum);

            /* read */ int value = queue.take();
            System.out.println("ArrayBlockingQueue value: " + value);

            // Another unrelated computation
            int factorial = 1;
            for (int i = 1; i <= 5; i++) {
                factorial *= i;
            }
            System.out.println("Factorial of 5: " + factorial);

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}