import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.Stack;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        ConcurrentLinkedDeque<Integer> deque = new ConcurrentLinkedDeque<>();
        Stack<Integer> stack = new Stack<>();
        HashMap<String, String> map = new HashMap<>();
        
        // Add some elements to the stack
        stack.push(10);
        stack.push(20);
        stack.push(30);

        // Adding elements to the map
        map.put("A", "Apple");
        map.put("B", "Banana");

        // Perform some operations with the stack
        int stackValue = stack.pop();
        System.out.println("Popped from stack: " + stackValue);

        // Perform operations with the map
        String fruit = map.get("A");
        System.out.println("Fruit associated with A: " + fruit);

        /* write */ deque.addFirst(42);

        // Perform more operations with stack
        stack.push(50);
        stack.push(60);
        System.out.println("Top of stack: " + stack.peek());

        // Add another element to the map
        map.put("C", "Cherry");
        System.out.println("Fruit associated with C: " + map.get("C"));

        // Perform more operations with the deque
        deque.addFirst(84);
        deque.addLast(21);

        // Iterate over the deque
        for (Integer val : deque) {
            System.out.println("Deque element: " + val);
        }

        /* read */ Integer value = deque.peekFirst();
        System.out.println("Peeked from deque: " + value);

        // More operations with stack
        while (!stack.isEmpty()) {
            System.out.println("Popped from stack: " + stack.pop());
        }
    }
}