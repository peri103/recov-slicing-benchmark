import java.util.concurrent.ConcurrentHashMap;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        ConcurrentHashMap<String, Integer> map = new ConcurrentHashMap<>();
        HashMap<String, String> simpleMap = new HashMap<>();
        List<Integer> numberList = new ArrayList<>();

        // Adding elements to simpleMap
        simpleMap.put("A", "Apple");
        simpleMap.put("B", "Banana");
        simpleMap.put("C", "Cherry");

        // Adding numbers to numberList
        for (int i = 1; i <= 5; i++) {
            numberList.add(i * 10);
        }

        // Processing numberList
        for (int number : numberList) {
            System.out.println("Number: " + number);
        }

        // Using ConcurrentHashMap
        /* write */ map.putIfAbsent("key", 42);

        // Simulating some complex operations
        for (String key : simpleMap.keySet()) {
            String fruit = simpleMap.get(key);
            System.out.println("Fruit: " + fruit);
        }

        // More operations on numberList
        for (int i = 0; i < numberList.size(); i++) {
            numberList.set(i, numberList.get(i) + 5);
        }

        // Final read operation
        /* read */ Integer value = map.get("key");
        System.out.println("Value from map: " + value);

        // Final operations on numberList
        for (int number : numberList) {
            System.out.println("Updated Number: " + number);
        }
    }
}