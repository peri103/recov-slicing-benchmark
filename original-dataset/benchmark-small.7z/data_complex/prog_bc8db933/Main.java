import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        ConcurrentLinkedDeque<Integer> deque = new ConcurrentLinkedDeque<>();
        ArrayList<Integer> arrayList = new ArrayList<>();
        HashMap<String, Integer> map = new HashMap<>();

        // Adding elements to the ArrayList
        for (int i = 0; i < 5; i++) {
            arrayList.add(i * 10);
        }

        // Adding elements to the HashMap
        map.put("one", 1);
        map.put("two", 2);
        map.put("three", 3);

        // Processing elements in the ArrayList
        for (int value : arrayList) {
            /* write */ deque.addLast(value);
        }

        // Performing some operations on the HashMap
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }

        // Additional operations
        int sum = 0;
        for (int value : arrayList) {
            sum += value;
        }
        System.out.println("Sum of ArrayList values: " + sum);

        // More unrelated operations
        if (map.containsKey("two")) {
            System.out.println("Map contains key 'two'");
        }

        // Finally reading the last element added to the deque
        /* read */ Integer lastValue = deque.peekLast();
        System.out.println("Last value in deque: " + lastValue);
    }
}