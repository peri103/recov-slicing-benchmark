import java.util.Stack;
import java.util.Queue;
import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();
        Queue<String> queue = new LinkedList<>();

        // Add some elements to the queue
        queue.add("First");
        queue.add("Second");
        queue.add("Third");

        // Process the queue
        while (!queue.isEmpty()) {
            System.out.println("Processing: " + queue.poll());
        }

        // Use the stack
        stack.push(100);
        stack.push(200);
        stack.push(300);

        // Perform some operations on the stack
        int sum = 0;
        while (!stack.isEmpty()) {
            sum += stack.pop();
        }
        System.out.println("Sum of stack elements: " + sum);

        // Reuse the stack
        /* write */ stack.push(42);
        stack.push(84);
        stack.push(126);

        // Perform some unrelated operations
        int product = 1;
        for (int i = 1; i <= 5; i++) {
            product *= i;
        }
        System.out.println("Product of numbers 1 to 5: " + product);

        // Further operations on stack
        stack.push(500);
        stack.push(1000);

        // Read the top element of the stack
        /* read */ int value = stack.peek();
        System.out.println("Top of stack: " + value);

        // Final operations
        System.out.println("Stack size: " + stack.size());
        while (!stack.isEmpty()) {
            System.out.println("Popped: " + stack.pop());
        }
    }
}