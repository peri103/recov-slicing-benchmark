import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.Queue;

public class Main {
    public static void main(String[] args) {
        LinkedBlockingDeque<Integer> deque = new LinkedBlockingDeque<>();
        LinkedBlockingQueue<String> queue = new LinkedBlockingQueue<>();
        
        // Insert some unrelated code
        queue.add("Hello");
        queue.add("World");
        System.out.println("Queue elements:");
        for (String s : queue) {
            System.out.println(s);
        }
        
        // Perform some operations on a different data structure
        Queue<Integer> numberQueue = new LinkedBlockingQueue<>();
        for (int i = 1; i <= 5; i++) {
            numberQueue.add(i);
        }
        System.out.println("Number queue elements:");
        while (!numberQueue.isEmpty()) {
            System.out.println(numberQueue.poll());
        }
        
        /* write */ deque.addLast(42);
        
        // More complex operations
        for (int i = 0; i < 3; i++) {
            deque.addLast(i * 10);
        }
        System.out.println("Deque elements after adding more items:");
        for (Integer num : deque) {
            System.out.println(num);
        }
        
        // Perform some unrelated calculations
        int sum = 0;
        for (int i = 1; i <= 10; i++) {
            sum += i;
        }
        System.out.println("Sum of numbers from 1 to 10: " + sum);
        
        try {
            /* read */ int value = deque.takeLast();
            System.out.println("Read value from deque: " + value);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        // Further operations on deque
        deque.addLast(99);
        System.out.println("Final state of deque:");
        for (Integer num : deque) {
            System.out.println(num);
        }
    }
}