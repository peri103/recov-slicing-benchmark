import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        BlockingQueue<Integer> queue = new LinkedBlockingQueue<>();
        ArrayList<Integer> list = new ArrayList<>();
        HashMap<String, Integer> map = new HashMap<>();

        // Populate the list with some data
        for (int i = 0; i < 5; i++) {
            list.add(i * 10);
        }

        // Populate the map with some data
        map.put("one", 1);
        map.put("two", 2);
        map.put("three", 3);

        // Add elements from the list to the queue
        for (int num : list) {
            try {
                queue.put(num);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Add a specific value to the queue
        try {
            /* write */ queue.put(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Process the map
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }

        // Read and print all elements from the queue
        for (int i = 0; i < list.size() + 1; i++) {
            try {
                int value = queue.take();
                System.out.println("Queue Value: " + value);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Finally read the specific value we inserted
        try {
            /* read */ int value = queue.take();
            System.out.println("Final Read Value: " + value);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}