import java.util.concurrent.ConcurrentSkipListMap;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ConcurrentSkipListMap<String, Integer> map = new ConcurrentSkipListMap<>();
        ArrayList<String> keys = new ArrayList<>();
        keys.add("key1");
        keys.add("key2");
        keys.add("key3");

        /* write */ map.put("key1", 100);

        map.put("key2", 200);
        map.put("key3", 300);

        for (String key : keys) {
            if (map.containsKey(key)) {
                System.out.println("Map contains: " + key);
            } else {
                System.out.println("Map does not contain: " + key);
            }
        }

        Integer sum = 0;
        for (String key : keys) {
            sum += map.get(key);
        }

        /* read */ Integer value = map.get("key1");
        System.out.println("Read value: " + value);
        System.out.println("Sum of values: " + sum);

        ArrayList<Integer> values = new ArrayList<>();
        for (String key : keys) {
            values.add(map.get(key));
        }

        System.out.println("Values in map:");
        for (Integer val : values) {
            System.out.println(val);
        }

        int maxValue = Integer.MIN_VALUE;
        for (Integer val : values) {
            if (val > maxValue) {
                maxValue = val;
            }
        }

        System.out.println("Max value in map: " + maxValue);
    }
}