import java.util.concurrent.atomic.AtomicReference;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class Main {
    public static void main(String[] args) {
        AtomicReference<Integer> atomicReference = new AtomicReference<>(0);
        AtomicInteger atomicCounter = new AtomicInteger(5);
        HashMap<String, Integer> map = new HashMap<>();
        
        // Initialize the map with some values
        map.put("A", 1);
        map.put("B", 2);
        map.put("C", 3);

        // Update the atomic counter
        atomicCounter.updateAndGet(value -> value * 2);

        // Perform some operations on the map
        for (String key : map.keySet()) {
            map.put(key, map.get(key) + atomicCounter.get());
        }

        /* write */
        atomicReference.updateAndGet(value -> value + 1);

        // Perform more operations on the map
        map.put("D", atomicCounter.get());

        // Additional computations
        int sum = 0;
        for (int value : map.values()) {
            sum += value;
        }

        // Print the sum
        System.out.println("Sum of values in map: " + sum);

        /* read */
        int value = atomicReference.get();

        System.out.println("AtomicReference value: " + value);

        // Further operations on atomicCounter
        int finalCounterValue = atomicCounter.updateAndGet(x -> x - 3);
        System.out.println("Final AtomicCounter value: " + finalCounterValue);
    }
}