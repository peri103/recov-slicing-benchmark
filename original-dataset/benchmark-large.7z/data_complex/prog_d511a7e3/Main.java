import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.PosixFilePermission;
import java.util.Set;
import java.util.HashSet;
import java.nio.file.StandardOpenOption;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class Main {
    public static void main(String[] args) {
        try {
            // Path for the file
            Path path = Paths.get("example.txt");

            // Define a set of permissions
            Set<PosixFilePermission> permissions = new HashSet<>();
            permissions.add(PosixFilePermission.OWNER_READ);
            permissions.add(PosixFilePermission.OWNER_WRITE);
            
            // Ensure the file exists
            if (!Files.exists(path)) {
                Files.createFile(path);
            }
            
            // Set the file permissions
            /* write */ Files.setPosixFilePermissions(path, permissions);
            
            // Unrelated code: Writing some content to the file
            String content = "Hello, World!";
            Files.write(path, content.getBytes(StandardCharsets.UTF_8), StandardOpenOption.WRITE);
            
            // More unrelated code: Reading the content back
            String fileContent = new String(Files.readAllBytes(path), StandardCharsets.UTF_8);
            System.out.println("File content: " + fileContent);
            
            // Unrelated code: Modify the content and append
            String additionalContent = "\nWelcome to the file!";
            Files.write(path, additionalContent.getBytes(StandardCharsets.UTF_8), StandardOpenOption.APPEND);
            
            // Read the file permissions
            /* read */ Set<PosixFilePermission> readPermissions = Files.posixFilePermissions(path);
            
            // Output the permissions
            System.out.println("File permissions: " + readPermissions);
            
            // Unrelated code: Display the modified content
            String modifiedContent = new String(Files.readAllBytes(path), StandardCharsets.UTF_8);
            System.out.println("Modified file content: " + modifiedContent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}