import java.util.stream.Stream;
import java.util.List;
import java.util.Arrays;
import java.util.stream.Collectors;
import java.util.Set;
import java.util.HashSet;

public class Main {
    public static void main(String[] args) {
        List<List<Integer>> nestedList = Arrays.asList(
            Arrays.asList(1, 2, 3),
            Arrays.asList(4, 5, 6),
            Arrays.asList(7, 8, 9)
        );

        Stream<List<Integer>> stream = nestedList.stream();
        
        /* write */ Stream<Integer> flatStream = stream.flatMap(List::stream);

        // Additional unrelated code to make the program more complex
        Set<Integer> uniqueNumbers = new HashSet<>();
        for (int i = 10; i < 20; i++) {
            uniqueNumbers.add(i);
        }
        
        // Processing on the uniqueNumbers Set
        Stream<Integer> uniqueStream = uniqueNumbers.stream();
        List<Integer> processedList = uniqueStream
            .filter(num -> num % 2 == 0)
            .map(num -> num * 2)
            .collect(Collectors.toList());
        
        System.out.println("Processed even numbers doubled: " + processedList);

        // More unrelated code
        List<String> words = Arrays.asList("apple", "banana", "cherry");
        Stream<String> wordStream = words.stream();
        List<String> capitalizedWords = wordStream
            .map(String::toUpperCase)
            .collect(Collectors.toList());
        
        System.out.println("Capitalized words: " + capitalizedWords);

        // Continue with the original write-read pair
        // Some unrelated operations in between
        int sum = 0;
        for (int i = 0; i < 5; i++) {
            sum += i;
        }
        System.out.println("Sum of first 5 numbers: " + sum);

        /* read */ List<Integer> flatList = flatStream.collect(Collectors.toList());
        
        System.out.println("Flattened list: " + flatList);
    }
}