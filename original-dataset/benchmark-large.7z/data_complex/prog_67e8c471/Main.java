import java.util.concurrent.ConcurrentSkipListMap;
import java.util.Map;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        ConcurrentSkipListMap<Integer, String> map = new ConcurrentSkipListMap<>();
        Map<Integer, String> dataToAdd = new HashMap<>();
        dataToAdd.put(1, "value1");
        dataToAdd.put(2, "value2");

        ConcurrentHashMap<Integer, String> concurrentMap = new ConcurrentHashMap<>();
        concurrentMap.put(3, "value3");
        concurrentMap.put(4, "value4");

        List<Integer> keys = new ArrayList<>();
        keys.add(3);
        keys.add(4);
        
        /* write */ map.putAll(dataToAdd);

        for (Integer key : keys) {
            concurrentMap.put(key, "newValue" + key);
        }

        for (Map.Entry<Integer, String> entry : concurrentMap.entrySet()) {
            System.out.println("ConcurrentMap Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }

        // Adding more data to the map
        map.put(5, "value5");
        map.put(6, "value6");

        System.out.println("Iterating over map:");
        for (Map.Entry<Integer, String> entry : map.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }

        /* read */ String value = map.get(1);
        System.out.println("Read value: " + value);

        // Additional logic to manipulate data
        List<String> valuesList = new ArrayList<>();
        for (String val : map.values()) {
            valuesList.add(val.toUpperCase());
        }

        System.out.println("Transformed values:");
        for (String val : valuesList) {
            System.out.println(val);
        }
    }
}