import java.util.concurrent.atomic.LongAdder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        LongAdder longAdder = new LongAdder();
        ArrayList<Integer> numbers = new ArrayList<>();
        HashMap<Integer, String> map = new HashMap<>();
        Random random = new Random();

        // Adding elements to numbers list
        for (int i = 0; i < 10; i++) {
            numbers.add(random.nextInt(100));
        }

        // Populating the map with some values
        for (int i = 0; i < 5; i++) {
            map.put(i, "Value" + i);
        }

        // Increment the LongAdder
        /* write */ longAdder.increment();

        // Perform some operations on the numbers list
        for (int num : numbers) {
            if (num % 2 == 0) {
                System.out.println("Even number: " + num);
            }
        }

        // Accessing values from the map
        for (int key : map.keySet()) {
            System.out.println("Key: " + key + ", Value: " + map.get(key));
        }

        // Sum the LongAdder
        /* read */ long value = longAdder.sum();
        System.out.println("LongAdder value: " + value);

        // More complex operations
        ArrayList<Integer> squaredNumbers = new ArrayList<>();
        for (int num : numbers) {
            squaredNumbers.add(num * num);
        }

        for (int square : squaredNumbers) {
            System.out.println("Squared number: " + square);
        }
    }
}