import java.util.Optional;
import java.util.ArrayList;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        // Initialize an ArrayList and add elements
        ArrayList<String> stringList = new ArrayList<>();
        stringList.add("Hello");
        stringList.add("World");

        // Initialize a HashMap and put some key-value pairs
        HashMap<String, Integer> map = new HashMap<>();
        map.put("one", 1);
        map.put("two", 2);

        // Use Optional to wrap a value
        Optional<Integer> optionalValue;
        /* write */ optionalValue = Optional.of(42);

        // Perform some operations on the ArrayList
        for (String str : stringList) {
            System.out.println(str);
        }

        // Perform some operations on the HashMap
        if (map.containsKey("one")) {
            System.out.println("Value for 'one': " + map.get("one"));
        }

        // More complex operations
        stringList.add("Optional");
        for (int i = 0; i < stringList.size(); i++) {
            System.out.println("Element " + i + ": " + stringList.get(i));
        }

        // Read the value from Optional
        /* read */ int value = optionalValue.orElse(-1);
        System.out.println("Optional value: " + value);

        // Additional complex logic
        map.put("three", 3);
        map.put("four", 4);
        for (String key : map.keySet()) {
            System.out.println("Key: " + key + ", Value: " + map.get(key));
        }
    }
}