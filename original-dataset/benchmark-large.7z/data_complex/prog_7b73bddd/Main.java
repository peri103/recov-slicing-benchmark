import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);

        // Create a stream from the list
        Stream<Integer> stream = numbers.stream();
        
        /* write */ int sum = stream.reduce(0, (a, b) -> a + b);

        // Unrelated computation using a different stream
        List<String> words = Arrays.asList("apple", "banana", "cherry");
        Stream<String> wordStream = words.stream();
        String concatenated = wordStream.reduce("", (a, b) -> a + b);
        System.out.println("Concatenated Words: " + concatenated);

        // Additional logic to make the program more complex
        List<Double> decimals = Arrays.asList(1.1, 2.2, 3.3);
        Stream<Double> decimalStream = decimals.stream();
        double product = decimalStream.reduce(1.0, (a, b) -> a * b);
        System.out.println("Product of Decimals: " + product);

        // Since the original stream has already been operated upon or closed, create a new stream
        stream = numbers.stream();

        // Additional logic to filter and collect
        List<Integer> evenNumbers = numbers.stream()
                                           .filter(n -> n % 2 == 0)
                                           .collect(Collectors.toList());
        System.out.println("Even Numbers: " + evenNumbers);

        /* read */ List<Integer> collected = stream.collect(Collectors.toList());

        System.out.println("Sum: " + sum);
        System.out.println("Collected: " + collected);
    }
}