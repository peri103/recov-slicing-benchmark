import java.util.concurrent.CopyOnWriteArrayList;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        CopyOnWriteArrayList<Integer> list = new CopyOnWriteArrayList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        
        // Unrelated code: Using a HashMap to store some values
        Map<String, Integer> map = new HashMap<>();
        map.put("A", 10);
        map.put("B", 20);
        map.put("C", 30);

        // More unrelated operations
        int sum = 0;
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            sum += entry.getValue();
        }
        System.out.println("Sum of map values: " + sum);

        // Another list with different operations
        CopyOnWriteArrayList<String> stringList = new CopyOnWriteArrayList<>();
        stringList.add("Hello");
        stringList.add("World");
        
        // Perform some operations on stringList
        for (String str : stringList) {
            System.out.println("StringList item: " + str);
        }

        /* write */ list.remove(1); // Removes the element at index 1, which is the value 2

        // Additional operations with the integer list
        list.add(4);
        list.add(5);
        
        // Print all elements in the list
        System.out.println("List contents:");
        for (Integer num : list) {
            System.out.println(num);
        }

        /* read */ int value = list.get(1); // Now, the element at index 1 is the value 3
        System.out.println("Value at index 1: " + value);

        // Further unrelated operations
        CopyOnWriteArrayList<Double> doubleList = new CopyOnWriteArrayList<>();
        doubleList.add(1.1);
        doubleList.add(2.2);
        doubleList.add(3.3);

        double total = 0.0;
        for (Double d : doubleList) {
            total += d;
        }
        System.out.println("Total of doubleList: " + total);
    }
}