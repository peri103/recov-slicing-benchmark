import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {
    public static void main(String[] args) {
        try {
            Path path = Paths.get("exampleDir");
            /* write */ Files.createDirectory(path);

            // Create a file inside the directory
            Path filePath = path.resolve("exampleFile.txt");
            Files.write(filePath, "Hello, World!".getBytes(), StandardOpenOption.CREATE);

            // Read all files in the directory
            try (Stream<Path> paths = Files.list(path)) {
                List<Path> fileList = paths.collect(Collectors.toList());
                System.out.println("Files in directory:");
                for (Path file : fileList) {
                    System.out.println(file.getFileName());
                }
            }

            // Read file attributes
            BasicFileAttributes attrs = Files.readAttributes(filePath, BasicFileAttributes.class);
            System.out.println("File size: " + attrs.size() + " bytes");
            System.out.println("File creation time: " + attrs.creationTime());

            // Check if the directory exists
            /* read */ boolean exists = Files.exists(path);
            System.out.println("Directory exists: " + exists);

            // Delete the file
            Files.delete(filePath);
            System.out.println("File deleted.");

            // Delete the directory
            Files.delete(path);
            System.out.println("Directory deleted.");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}