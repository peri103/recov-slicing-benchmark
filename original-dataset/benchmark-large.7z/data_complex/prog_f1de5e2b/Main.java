import java.util.Optional;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Optional<Integer> optional = Optional.of(1);
        Optional<Integer> otherOptional = Optional.of(1);
        
        /* write */ boolean isEqual = optional.equals(otherOptional);
        
        // Additional complex code
        ArrayList<Optional<Integer>> optionalList = new ArrayList<>();
        optionalList.add(optional);
        optionalList.add(Optional.empty());
        optionalList.add(otherOptional);
        
        for (Optional<Integer> opt : optionalList) {
            if (opt.isPresent()) {
                System.out.println("Value: " + opt.get());
            } else {
                System.out.println("Empty Optional");
            }
        }
        
        int sum = 0;
        for (Optional<Integer> opt : optionalList) {
            sum += opt.orElse(0);
        }
        System.out.println("Sum of present values: " + sum);

        // More unrelated code
        ArrayList<Integer> numbers = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            numbers.add(i * 10);
        }
        
        for (int number : numbers) {
            System.out.println("Number: " + number);
        }
        
        /* read */ boolean isPresent = optional.isPresent();
        
        System.out.println("Is Equal: " + isEqual);
        System.out.println("Is Present: " + isPresent);
    }
}