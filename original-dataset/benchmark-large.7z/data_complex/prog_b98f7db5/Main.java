import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);
        Stream<Integer> stream = numbers.stream();
        
        /* write */ stream = stream.skip(2);
        
        // Unrelated code to increase complexity
        Map<String, Integer> map = new HashMap<>();
        map.put("One", 1);
        map.put("Two", 2);
        map.put("Three", 3);
        
        Set<String> keys = map.keySet();
        for (String key : keys) {
            System.out.println(key + " : " + map.get(key));
        }
        
        // Another stream operation
        List<String> stringList = Arrays.asList("a", "b", "c", "d");
        Stream<String> stringStream = stringList.stream();
        stringStream = stringStream.map(String::toUpperCase);
        List<String> upperCaseList = stringStream.collect(Collectors.toList());
        System.out.println(upperCaseList);
        
        // Back to the original stream operations
        /* read */ List<Integer> result = stream.collect(Collectors.toList());
        
        System.out.println(result);
    }
}