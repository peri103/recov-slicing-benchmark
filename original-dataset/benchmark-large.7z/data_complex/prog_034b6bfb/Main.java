import java.util.Optional;
import java.util.ArrayList;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        // Initialize a variable with a value
        String initialValue = "Hello, World!";
        
        // Use Optional to wrap the initial value
        /* write */ Optional<String> optionalValue = Optional.ofNullable(initialValue);
        
        // Unrelated complex code: Working with an ArrayList
        ArrayList<Integer> numbers = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            numbers.add(i * 2);
        }

        // Unrelated complex code: Working with a HashMap
        HashMap<String, Integer> map = new HashMap<>();
        for (int i = 0; i < numbers.size(); i++) {
            map.put("Key" + i, numbers.get(i));
        }

        // Process the map and print its contents
        for (String key : map.keySet()) {
            System.out.println(key + " : " + map.get(key));
        }

        // More unrelated code: Calculate sum of numbers
        int sum = 0;
        for (int num : numbers) {
            sum += num;
        }
        System.out.println("Sum of numbers: " + sum);

        // Read the value from the Optional, providing a default value in case it's null
        /* read */ String value = optionalValue.orElse("Default Value");
        
        // Print the read value
        System.out.println(value);
    }
}