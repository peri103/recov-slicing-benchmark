import java.util.concurrent.LinkedBlockingDeque;
import java.util.Arrays;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Original LinkedBlockingDeque and retainAll-size pair
        LinkedBlockingDeque<Integer> deque = new LinkedBlockingDeque<>(Arrays.asList(1, 2, 3, 4, 5));
        LinkedBlockingDeque<Integer> elementsToRetain = new LinkedBlockingDeque<>(Arrays.asList(2, 3, 4));
        
        /* write */ deque.retainAll(elementsToRetain);
        
        // Adding complexity: Another LinkedBlockingDeque and operations
        LinkedBlockingDeque<String> stringDeque = new LinkedBlockingDeque<>();
        stringDeque.add("Apple");
        stringDeque.add("Banana");
        stringDeque.add("Cherry");

        LinkedBlockingQueue<String> queue = new LinkedBlockingQueue<>(Arrays.asList("Banana", "Cherry"));
        stringDeque.retainAll(queue);
        
        // Iterate over the stringDeque
        for (String fruit : stringDeque) {
            System.out.println("Fruit: " + fruit);
        }
        
        // Adding complexity: Integer operations
        int sum = 0;
        for (Integer num : deque) {
            sum += num;
        }
        System.out.println("Sum of deque elements: " + sum);
        
        // Adding complexity: List operations
        List<Integer> numberList = Arrays.asList(10, 20, 30);
        for (Integer number : numberList) {
            System.out.println("Number: " + number);
        }

        // More unrelated code to increase complexity
        int product = 1;
        for (int i = 1; i <= 3; i++) {
            product *= i;
        }
        System.out.println("Product of first 3 numbers: " + product);
        
        /* read */ int size = deque.size();
        
        System.out.println("Size of deque after retainAll: " + size);
    }
}