import java.util.concurrent.atomic.AtomicBooleanFieldUpdater;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

public class Main {
    private static class MyClass {
        volatile boolean flag;
        volatile int number;
        volatile String text;
    }

    public static void main(String[] args) {
        MyClass myObject = new MyClass();

        // AtomicBooleanFieldUpdater
        AtomicBooleanFieldUpdater<MyClass> booleanUpdater = AtomicBooleanFieldUpdater.newUpdater(MyClass.class, "flag");
        /* write */ booleanUpdater.set(myObject, true);

        // AtomicIntegerFieldUpdater
        AtomicIntegerFieldUpdater<MyClass> integerUpdater = AtomicIntegerFieldUpdater.newUpdater(MyClass.class, "number");
        integerUpdater.set(myObject, 42);

        // AtomicReferenceFieldUpdater
        AtomicReferenceFieldUpdater<MyClass, String> referenceUpdater = AtomicReferenceFieldUpdater.newUpdater(MyClass.class, String.class, "text");
        referenceUpdater.set(myObject, "Hello, World!");

        // Complex operations
        for (int i = 0; i < 5; i++) {
            integerUpdater.addAndGet(myObject, i);
        }

        String currentText = referenceUpdater.get(myObject);
        if (currentText.equals("Hello, World!")) {
            referenceUpdater.set(myObject, currentText + " Welcome!");
        }

        // More unrelated code
        int currentNumber = integerUpdater.get(myObject);
        System.out.println("Current number: " + currentNumber);

        boolean flagStatus = booleanUpdater.get(myObject);
        System.out.println("Flag status: " + flagStatus);

        /* read */ boolean value = booleanUpdater.get(myObject);
        System.out.println("Final flag value: " + value);

        String finalText = referenceUpdater.get(myObject);
        System.out.println("Final text: " + finalText);
    }
}