import java.util.stream.IntStream;
import java.util.List;
import java.util.ArrayList;
import java.util.OptionalInt;

public class Main {
    public static void main(String[] args) {
        IntStream numbers = IntStream.of(1, 2, 3, 4, 5);
        /* write */ IntStream mappedNumbers = numbers.map(x -> x * 2);

        // Additional logic to demonstrate complexity
        List<Integer> numberList = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            numberList.add(i);
        }
        
        // Perform some transformations on the list
        IntStream listStream = numberList.stream().mapToInt(Integer::intValue);
        IntStream filteredStream = listStream.filter(x -> x % 2 == 0);
        
        OptionalInt max = filteredStream.max();
        max.ifPresent(maxValue -> System.out.println("Max even number: " + maxValue));
        
        // More unrelated code
        List<String> names = new ArrayList<>();
        names.add("Alice");
        names.add("Bob");
        names.add("Charlie");
        
        names.forEach(name -> System.out.println("Hello, " + name));
        
        // Continue with the original read operation
        /* read */ int sum = mappedNumbers.reduce(0, (a, b) -> a + b);
        System.out.println("Sum of mapped numbers: " + sum);
    }
}