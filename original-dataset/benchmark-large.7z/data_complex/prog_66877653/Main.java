import java.util.LinkedHashSet;
import java.util.HashSet;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        LinkedHashSet<Integer> set = new LinkedHashSet<>();
        set.add(1);
        set.add(2);
        set.add(3);

        HashSet<String> stringSet = new HashSet<>();
        stringSet.add("Hello");
        stringSet.add("World");

        ArrayList<Integer> list = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            list.add(i * 2);
        }

        for (int i = 0; i < list.size(); i++) {
            System.out.println("List element: " + list.get(i));
        }

        /* write */ set.remove(2);

        for (String s : stringSet) {
            System.out.println("StringSet element: " + s);
        }

        System.out.println("Adding more elements to the set...");
        set.add(4);
        set.add(5);

        for (Integer num : set) {
            System.out.println("Set element: " + num);
        }

        /* read */ boolean contains = set.contains(2);
        System.out.println("Does set contain 2? " + contains); // This should print 'false' since 2 was removed

        System.out.println("Iterating over the set again...");
        for (Integer num : set) {
            System.out.println("Set element: " + num);
        }
    }
}