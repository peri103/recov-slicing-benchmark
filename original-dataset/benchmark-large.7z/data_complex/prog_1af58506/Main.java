import java.util.concurrent.CopyOnWriteArrayList;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        CopyOnWriteArrayList<Integer> list = new CopyOnWriteArrayList<>();
        CopyOnWriteArrayList<Integer> list2 = new CopyOnWriteArrayList<>();
        HashMap<Integer, String> map = new HashMap<>();

        // Adding elements to the first list
        list.add(1);
        list.add(2);
        list.add(3);

        // Adding elements to the second list
        list2.add(4);
        list2.add(5);

        // Adding elements to the map
        map.put(1, "One");
        map.put(2, "Two");
        map.put(3, "Three");

        // Convert list to array
        /* write */ Object[] array = list.toArray();

        // Perform operations on the map
        for (int key : map.keySet()) {
            System.out.println("Key: " + key + ", Value: " + map.get(key));
        }

        // Add elements from list2 to list
        for (Integer num : list2) {
            list.add(num);
        }

        // Calculate and print the size of the list
        /* read */ int size = list.size();
        System.out.println("Size of the list after adding elements from list2: " + size);

        // Print all elements in the list
        System.out.println("Elements in the list:");
        for (Integer num : list) {
            System.out.println(num);
        }
    }
}