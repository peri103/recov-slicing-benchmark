import java.util.Properties;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        Properties properties = new Properties();
        properties.setProperty("key", "value");
        
        // Additional unrelated code to make the program more complex
        Map<String, Integer> map = new HashMap<>();
        map.put("one", 1);
        map.put("two", 2);
        map.put("three", 3);
        
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
        
        // Another Properties object to demonstrate similar API usage
        Properties otherProperties = new Properties();
        otherProperties.setProperty("anotherKey", "anotherValue");
        
        otherProperties.remove("anotherKey");
        String anotherValue = otherProperties.getProperty("anotherKey");
        System.out.println(anotherValue); // This will print 'null' since the key was removed
        
        /* write */ properties.remove("key");
        
        // Additional logic to manipulate the map
        map.put("four", 4);
        map.put("five", 5);
        
        int total = 0;
        for (Integer value : map.values()) {
            total += value;
        }
        System.out.println("Total: " + total);
        
        /* read */ String value = properties.getProperty("key");
        
        System.out.println(value); // This will print 'null' since the key was removed
    }
}