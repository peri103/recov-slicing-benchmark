import java.util.concurrent.PriorityBlockingQueue;
import java.util.Arrays;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        // Initialize the PriorityBlockingQueue with some elements
        PriorityBlockingQueue<Integer> queue = new PriorityBlockingQueue<>();
        queue.addAll(Arrays.asList(1, 2, 3, 4, 5));

        // Create a collection with elements to retain
        PriorityBlockingQueue<Integer> retainQueue = new PriorityBlockingQueue<>();
        retainQueue.addAll(Arrays.asList(2, 3));

        // Use retainAll method to retain only the elements in retainQueue
        /* write */ queue.retainAll(retainQueue);

        // Initialize a HashMap to demonstrate additional complexity
        HashMap<String, Integer> map = new HashMap<>();
        map.put("A", 10);
        map.put("B", 20);
        map.put("C", 30);

        // Perform some operations on the map
        int sum = 0;
        for (String key : map.keySet()) {
            sum += map.get(key);
        }
        System.out.println("Sum of values in the map: " + sum);

        // Create another PriorityBlockingQueue and perform operations
        PriorityBlockingQueue<Integer> anotherQueue = new PriorityBlockingQueue<>();
        anotherQueue.addAll(Arrays.asList(10, 20, 30, 40, 50));
        anotherQueue.remove(30);

        // Calculate the size of anotherQueue
        int anotherSize = anotherQueue.size();
        System.out.println("Size of another queue: " + anotherSize);

        // Read the size of the original queue after retaining elements
        /* read */ int size = queue.size();

        // Print the size
        System.out.println("Size of the queue after retainAll operation: " + size);

        // Further manipulate the queues
        anotherQueue.add(60);
        anotherQueue.add(70);
        for (Integer element : anotherQueue) {
            System.out.println("Element in anotherQueue: " + element);
        }
    }
}