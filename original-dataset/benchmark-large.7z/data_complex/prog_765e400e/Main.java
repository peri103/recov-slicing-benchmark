import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.HashMap;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ConcurrentLinkedQueue<Integer> queue = new ConcurrentLinkedQueue<>();
        HashMap<String, Integer> map = new HashMap<>();
        ArrayList<String> list = new ArrayList<>();

        // Adding some elements to the map
        map.put("one", 1);
        map.put("two", 2);
        map.put("three", 3);

        // Adding some elements to the list
        list.add("first");
        list.add("second");
        list.add("third");

        // Iterating over the map
        for (String key : map.keySet()) {
            System.out.println("Key: " + key + ", Value: " + map.get(key));
        }

        // Iterating over the list
        for (String item : list) {
            System.out.println("List item: " + item);
        }

        // Perform some computation
        int result = 0;
        for (int i = 0; i < 10; i++) {
            result += i;
        }
        System.out.println("Computation result: " + result);

        /* write */ queue.offer(42);

        // More complex logic
        int counter = 0;
        while (counter < 5) {
            System.out.println("Counter: " + counter);
            counter++;
        }

        // Final operations
        for (int i = 0; i < 3; i++) {
            System.out.println("Final loop iteration: " + i);
        }

        /* read */ Integer value = queue.poll();
        System.out.println("Polled value from queue: " + value);

        // More unrelated operations
        int sum = 0;
        for (int i = 0; i < 100; i++) {
            sum += i;
        }
        System.out.println("Sum of first 100 numbers: " + sum);
    }
}