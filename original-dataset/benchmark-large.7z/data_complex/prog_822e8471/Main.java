import java.util.concurrent.CopyOnWriteArrayList;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        CopyOnWriteArrayList<Integer> list = new CopyOnWriteArrayList<>();
        list.add(1); // Adding an element to the list to ensure it is not empty
        list.add(2);
        list.add(3);

        // Unrelated code to add complexity
        Map<String, Integer> map = new HashMap<>();
        map.put("One", 1);
        map.put("Two", 2);
        map.put("Three", 3);

        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }

        // Another unrelated operation
        int sum = 0;
        for (Integer num : list) {
            sum += num;
        }
        System.out.println("Sum of elements in the list: " + sum);

        /* write */ Object[] array = list.toArray();

        // More unrelated code
        CopyOnWriteArrayList<String> stringList = new CopyOnWriteArrayList<>();
        stringList.add("A");
        stringList.add("B");
        stringList.add("C");

        for (String str : stringList) {
            System.out.println("String element: " + str);
        }

        // Perform some operations on the array obtained from the list
        for (Object obj : array) {
            System.out.println("Array element: " + obj);
        }

        /* read */ int size = list.size();
        System.out.println("Array length: " + array.length);
        System.out.println("List size: " + size);

        // Another unrelated operation
        int product = 1;
        for (int i = 1; i <= 5; i++) {
            product *= i;
        }
        System.out.println("Product of numbers 1 to 5: " + product);
    }
}