import java.util.stream.Stream;
import java.util.List;
import java.util.Arrays;
import java.util.stream.Collectors;
import java.util.function.Predicate;

public class Main {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(3, 1, 4, 1, 5, 9, 2, 6, 5);

        Stream<Integer> numberStream = numbers.stream();
        
        // Additional logic: Filter even numbers
        Predicate<Integer> isEven = n -> n % 2 == 0;
        Stream<Integer> evenNumberStream = numberStream.filter(isEven);

        /* write */ Stream<Integer> sortedStream = evenNumberStream.sorted();

        // Unrelated logic: Calculate the sum of the original list
        int sum = numbers.stream().mapToInt(Integer::intValue).sum();
        System.out.println("Sum of numbers: " + sum);

        // Additional logic: Map the sorted even numbers to their squares
        Stream<Integer> squaredStream = sortedStream.map(n -> n * n);

        // Unrelated logic: Find the maximum in the original list
        int max = numbers.stream().max(Integer::compareTo).orElse(-1);
        System.out.println("Max of numbers: " + max);

        /* read */ List<Integer> sortedList = squaredStream.collect(Collectors.toList());

        System.out.println("Sorted and squared even numbers: " + sortedList);

        // Additional logic: Find the average of the sorted and squared even numbers
        double average = sortedList.stream().mapToInt(Integer::intValue).average().orElse(0.0);
        System.out.println("Average of sorted and squared even numbers: " + average);
    }
}