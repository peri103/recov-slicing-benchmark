import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Path path = Paths.get("example.txt");
        try {
            /* write */ List<String> lines = Files.readAllLines(path);

            // Additional logic to process the lines
            List<String> processedLines = new ArrayList<>();
            for (String line : lines) {
                processedLines.add(line.toUpperCase());
            }

            // Further processing unrelated to the original read-write pair
            List<Integer> numbers = new ArrayList<>();
            for (int i = 0; i < processedLines.size(); i++) {
                numbers.add(i * 2);
            }

            // Simulate some unrelated computation
            int sum = 0;
            for (int number : numbers) {
                sum += number;
            }
            System.out.println("Sum of numbers: " + sum);

            // More complex logic
            for (String processedLine : processedLines) {
                if (processedLine.contains("ERROR")) {
                    System.err.println("Error line found: " + processedLine);
                }
            }

            /* read */ int size = lines.size();
            System.out.println("Number of lines: " + size);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}