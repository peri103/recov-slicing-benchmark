import java.util.stream.Stream;
import java.util.stream.LongStream;
import java.util.List;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Create a Stream of Integer
        Stream<Integer> integerStream = Stream.of(1, 2, 3, 4, 5);

        // Use mapToLong to convert Stream<Integer> to LongStream
        /* write */ LongStream longStream = integerStream.mapToLong(Integer::longValue);

        // Create a list to store squared values
        List<Integer> squaredList = new ArrayList<>();
        
        // Create another stream to demonstrate additional complexity
        Stream<Integer> anotherStream = Stream.of(6, 7, 8, 9, 10);
        anotherStream.forEach(num -> squaredList.add(num * num));

        // Process the squaredList to find the max value
        int maxSquare = squaredList.stream().mapToInt(Integer::intValue).max().orElse(-1);
        System.out.println("Max squared value: " + maxSquare);

        // Use sum to read the sum of the LongStream
        /* read */ long sum = longStream.sum();
        System.out.println("Sum of the original stream: " + sum);

        // Further process the squaredList to calculate the sum of squared values
        int sumOfSquares = squaredList.stream().mapToInt(Integer::intValue).sum();
        System.out.println("Sum of squared values: " + sumOfSquares);
    }
}