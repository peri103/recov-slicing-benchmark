import java.util.HashSet;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        HashSet<Integer> set = new HashSet<>();
        set.add(1);
        set.add(2);
        set.add(3);
        
        ArrayList<Integer> numbers = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            numbers.add(i);
        }

        for (int number : numbers) {
            if (number % 2 == 0) {
                set.add(number);
            }
        }

        /* write */ set.remove(2);

        int sum = 0;
        for (int number : numbers) {
            if (set.contains(number)) {
                sum += number;
            }
        }

        System.out.println("Sum of numbers present in set: " + sum);

        for (int i = 0; i < 5; i++) {
            set.add(i + 10);
        }

        int count = 0;
        for (int i = 0; i < 20; i++) {
            if (set.contains(i)) {
                count++;
            }
        }

        /* read */ boolean contains = set.contains(2);

        System.out.println("Contains 2: " + contains); // Should print false, since 2 was removed
        System.out.println("Count of numbers in set: " + count);
    }
}