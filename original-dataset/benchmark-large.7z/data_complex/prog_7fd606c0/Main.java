import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;
import java.util.stream.Stream;
import java.util.List;
import java.util.ArrayList;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) {
        try {
            // Initialize the directory path
            Path directory = Paths.get("example_directory");
            if (!Files.exists(directory)) {
                Files.createDirectory(directory);
            }
            
            // List files in the directory
            /* write */ Stream<Path> filesStream = Files.list(directory);
            
            // Perform some unrelated operations
            List<Integer> numbers = new ArrayList<>();
            for (int i = 0; i < 10; i++) {
                numbers.add(i * 2);
            }
            
            // Sort the list of numbers
            numbers.sort(Comparator.naturalOrder());
            
            // Print sorted numbers
            System.out.println("Sorted numbers:");
            for (Integer number : numbers) {
                System.out.println(number);
            }
            
            // Count the number of files in the directory
            /* read */ long count = filesStream.count();
            System.out.println("Number of files: " + count);
            
            // Perform additional operations on the directory
            filesStream.close();
            
            // Create more files in the directory for demonstration
            for (int i = 0; i < 5; i++) {
                Path filePath = directory.resolve("file" + i + ".txt");
                if (!Files.exists(filePath)) {
                    Files.createFile(filePath);
                }
            }
            
            // List files again to verify creation
            Stream<Path> newFilesStream = Files.list(directory);
            System.out.println("Files in the directory after creation:");
            newFilesStream.forEach(System.out::println);
            newFilesStream.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}