import java.util.concurrent.PriorityBlockingQueue;
import java.util.HashMap;
import java.util.HashSet;

public class Main {
    public static void main(String[] args) {
        PriorityBlockingQueue<Integer> queue = new PriorityBlockingQueue<>();
        HashMap<String, Integer> map = new HashMap<>();
        HashSet<Integer> set = new HashSet<>();

        // Add some elements to the queue for demonstration
        queue.add(10);
        queue.add(20);
        queue.add(30);

        // Add elements to map and set
        map.put("A", 1);
        map.put("B", 2);
        map.put("C", 3);
        set.add(100);
        set.add(200);
        set.add(300);

        /* write */ Object[] array = queue.toArray();

        // Perform operations on map and set
        if (map.containsKey("B")) {
            int value = map.get("B");
            System.out.println("Value for key 'B': " + value);
        }

        set.remove(200);

        for (int num : set) {
            System.out.println("Set contains: " + num);
        }

        // Add more elements to the queue
        queue.add(40);
        queue.add(50);

        // Perform some calculations
        int sum = 0;
        for (int i = 0; i < array.length; i++) {
            sum += (Integer) array[i];
        }
        System.out.println("Sum of elements in queue: " + sum);

        // Final read operation
        /* read */ int size = queue.size();
        System.out.println("Size of the queue: " + size);
    }
}