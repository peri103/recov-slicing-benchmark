import java.util.*;
import java.util.stream.*;

public class Main {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(5, 3, 1, 4, 2);

        // Additional unrelated code to add complexity
        List<String> words = Arrays.asList("banana", "apple", "cherry", "date");
        Stream<String> wordStream = words.stream();
        List<String> sortedWords = wordStream.sorted().collect(Collectors.toList());
        System.out.println("Sorted words: " + sortedWords);

        // Additional code to demonstrate similar API usage
        List<Double> decimals = Arrays.asList(3.14, 1.59, 2.65, 5.35);
        Stream<Double> decimalStream = decimals.stream();
        decimalStream.forEach(System.out::println);

        /* write */ Stream<Integer> sortedStream = numbers.stream().sorted();

        // Additional unrelated code to add complexity
        Map<String, Integer> map = new HashMap<>();
        map.put("one", 1);
        map.put("two", 2);
        map.put("three", 3);
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        // Complex logic before using the read method
        int sum = 0;
        for (int i = 0; i < numbers.size(); i++) {
            sum += numbers.get(i);
        }
        System.out.println("Sum of numbers: " + sum);

        /* read */ List<Integer> sortedList = sortedStream.collect(Collectors.toList());

        System.out.println("Sorted numbers: " + sortedList);

        // More complex logic after the read method
        List<Integer> squaredList = new ArrayList<>();
        for (Integer num : sortedList) {
            squaredList.add(num * num);
        }
        System.out.println("Squared numbers: " + squaredList);
    }
}