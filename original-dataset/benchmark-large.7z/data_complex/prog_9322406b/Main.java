import java.util.stream.Stream;
import java.util.List;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Initial stream with duplicate elements
        Stream<String> stream = Stream.of("apple", "banana", "apple", "orange", "banana");
        
        // Another stream for demonstration
        Stream<String> fruitStream = Stream.of("kiwi", "mango", "berry", "kiwi", "grape");

        // Creating a list from the fruitStream
        List<String> fruitList = new ArrayList<>();
        fruitStream.forEach(fruitList::add);

        // Perform distinct operation on the original stream
        /* write */ Stream<String> distinctStream = stream.distinct();

        // Perform some unrelated operations
        int sum = 0;
        for (int i = 0; i < fruitList.size(); i++) {
            sum += fruitList.get(i).length();
            System.out.println("Fruit: " + fruitList.get(i) + ", Length: " + fruitList.get(i).length());
        }

        // Use the distinctStream to count unique elements
        /* read */ long count = distinctStream.count();
        
        // Output the count of distinct elements
        System.out.println("Count of distinct elements: " + count);

        // Additional unrelated computation
        int totalFruitLength = fruitList.stream().mapToInt(String::length).sum();
        System.out.println("Total length of all fruits: " + totalFruitLength);
    }
}