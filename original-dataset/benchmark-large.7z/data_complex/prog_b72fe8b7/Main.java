import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        ConcurrentLinkedDeque<Integer> deque = new ConcurrentLinkedDeque<>();
        ArrayList<String> stringList = new ArrayList<>();
        LinkedList<Double> doubleList = new LinkedList<>();
        HashMap<String, Integer> map = new HashMap<>();

        // Add elements to stringList
        stringList.add("Hello");
        stringList.add("World");

        // Add elements to doubleList
        doubleList.add(3.14);
        doubleList.add(2.71);

        // Add elements to map
        map.put("Key1", 100);
        map.put("Key2", 200);

        // Perform some operations
        for (String s : stringList) {
            System.out.println("String: " + s);
        }

        for (Double d : doubleList) {
            System.out.println("Double: " + d);
        }

        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

        // Original write operation
        /* write */ deque.addFirst(42);

        // Additional operations on deque
        deque.addLast(24);
        deque.offerFirst(84);
        deque.offerLast(48);

        // More complex operations
        if (!deque.isEmpty()) {
            System.out.println("Deque is not empty.");
            Integer lastValue = deque.pollLast();
            System.out.println("Polled last value: " + lastValue);
        }

        // Original read operation
        /* read */ Integer value = deque.peekFirst();
        System.out.println("Peeked first value: " + value);

        // Further operations
        System.out.println("Deque size: " + deque.size());
        for (Integer num : deque) {
            System.out.println("Deque element: " + num);
        }
    }
}