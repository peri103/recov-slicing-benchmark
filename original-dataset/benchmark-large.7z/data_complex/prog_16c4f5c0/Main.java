import java.util.concurrent.atomic.AtomicLong;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;

public class Main {
    public static void main(String[] args) {
        AtomicLong atomicLong = new AtomicLong(0);
        AtomicInteger atomicInteger = new AtomicInteger(10);
        ArrayList<Integer> numbers = new ArrayList<>();

        // Initialize the ArrayList with some values
        for (int i = 0; i < 5; i++) {
            numbers.add(i * 10);
        }

        // Perform some operations on atomicInteger
        atomicInteger.incrementAndGet();
        atomicInteger.addAndGet(5);

        // Perform some operations on the ArrayList
        for (int i = 0; i < numbers.size(); i++) {
            numbers.set(i, numbers.get(i) + atomicInteger.get());
        }

        // Write operation on atomicLong
        /* write */ boolean success = atomicLong.compareAndSet(0, 100);

        // More operations on the ArrayList
        for (Integer number : numbers) {
            System.out.println("Modified number: " + number);
        }

        // Read operation on atomicLong
        if (success) {
            /* read */ long value = atomicLong.get();
            System.out.println("Value successfully updated to: " + value);
        } else {
            System.out.println("Failed to update the value.");
        }

        // Additional operations to make the program more complex
        ArrayList<String> strings = new ArrayList<>();
        strings.add("Hello");
        strings.add("World");

        for (String str : strings) {
            System.out.println("String value: " + str);
        }
    }
}