import java.util.Optional;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Original write-read pair using Optional
        Optional<Integer> optionalValue;
        /* write */ optionalValue = Optional.ofNullable(42);

        // Additional code to make the program more complex
        ArrayList<Integer> numberList = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            numberList.add(i * 5);
        }

        Optional<Integer> anotherOptional = Optional.ofNullable(numberList.get(5));
        int anotherValue = anotherOptional.orElse(-1);
        System.out.println("Another value: " + anotherValue);

        // Complex logic involving loops and conditions
        int sum = 0;
        for (int number : numberList) {
            if (number % 2 == 0) {
                sum += number;
            }
        }
        System.out.println("Sum of even numbers: " + sum);

        // More unrelated code
        ArrayList<String> words = new ArrayList<>();
        words.add("Hello");
        words.add("World");
        words.add("Java");

        for (String word : words) {
            System.out.println(word.toUpperCase());
        }

        // Original read from the optionalValue
        /* read */ int value = optionalValue.orElse(-1);
        System.out.println("Original value: " + value);
    }
}