import java.util.concurrent.LinkedTransferQueue;
import java.util.Queue;
import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {
        LinkedTransferQueue<Integer> queue = new LinkedTransferQueue<>();
        Queue<String> stringQueue = new LinkedList<>();
        Queue<Double> doubleQueue = new LinkedList<>();

        // Adding elements to stringQueue
        stringQueue.add("Hello");
        stringQueue.add("World");

        // Adding elements to doubleQueue
        for (int i = 0; i < 5; i++) {
            doubleQueue.add(i * 1.5);
        }

        // Processing elements in stringQueue
        while (!stringQueue.isEmpty()) {
            System.out.println("String Queue Element: " + stringQueue.poll());
        }

        // Processing elements in doubleQueue
        while (!doubleQueue.isEmpty()) {
            System.out.println("Double Queue Element: " + doubleQueue.poll());
        }

        try {
            /* write */ queue.put(42);
            
            // Simulating some additional operations
            for (int i = 0; i < 3; i++) {
                queue.put(i * 10);
            }

            // Reading and processing other elements
            while (!queue.isEmpty()) {
                Integer element = queue.take();
                System.out.println("Processed Element: " + element);
            }

            // Finally read the original written value
            /* read */ int value = queue.take();
            System.out.println("Original Value: " + value);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}