import java.util.stream.IntStream;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) {
        IntStream intStream = IntStream.of(1, 2, 3, 4, 5);
        
        /* write */
        List<Integer> boxedList = intStream.boxed().collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
        
        // Unrelated code to make the program more complex
        List<String> stringList = new ArrayList<>();
        stringList.add("Banana");
        stringList.add("Apple");
        stringList.add("Orange");
        
        // Sort the string list
        Collections.sort(stringList, new Comparator<String>() {
            @Override
            public int compare(String s1, String s2) {
                return s1.compareTo(s2);
            }
        });

        // Print sorted string list
        for (String fruit : stringList) {
            System.out.println(fruit);
        }

        // More unrelated code
        List<Double> doubleList = new ArrayList<>();
        doubleList.add(3.14);
        doubleList.add(1.59);
        doubleList.add(2.65);

        double sum = doubleList.stream().mapToDouble(Double::doubleValue).sum();
        System.out.println("Sum of doubles: " + sum);

        IntStream newIntStream = boxedList.stream().mapToInt(Integer::intValue);

        // Additional unrelated code
        List<String> moreStrings = new ArrayList<>();
        moreStrings.add("Dog");
        moreStrings.add("Cat");
        moreStrings.add("Bird");

        moreStrings.forEach(System.out::println);

        /* read */
        int[] intArray = newIntStream.toArray();
        
        for (int value : intArray) {
            System.out.println(value);
        }
    }
}