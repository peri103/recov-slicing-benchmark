import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        BlockingDeque<Integer> deque = new LinkedBlockingDeque<>();
        BlockingDeque<String> stringDeque = new LinkedBlockingDeque<>();
        
        // Adding some random integers to the deque
        for (int i = 0; i < 5; i++) {
            int randomValue = new Random().nextInt(100);
            deque.addFirst(randomValue);
            System.out.println("Added to deque: " + randomValue);
        }
        
        // Add a specific value to the end of the deque
        /* write */ deque.addLast(42);
        
        // Adding some strings to another deque
        stringDeque.addFirst("Hello");
        stringDeque.addLast("World");
        
        // Simulating some delay
        try {
            TimeUnit.SECONDS.sleep(1);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        // Reading from the string deque
        try {
            String firstString = stringDeque.takeFirst();
            System.out.println("Read from stringDeque: " + firstString);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println("Thread was interrupted, failed to complete operation.");
        }
        
        // More complex operations
        int sum = 0;
        for (Integer num : deque) {
            sum += num;
        }
        System.out.println("Sum of all elements in deque: " + sum);
        
        // Finally, retrieve the specific value added earlier
        try {
            /* read */ int value = deque.takeLast();
            System.out.println("Retrieved from deque: " + value);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println("Thread was interrupted, failed to complete operation.");
        }
        
        // Additional operations on stringDeque
        stringDeque.addFirst("Java");
        try {
            String lastString = stringDeque.takeLast();
            System.out.println("Read from stringDeque: " + lastString);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println("Thread was interrupted, failed to complete operation.");
        }
    }
}