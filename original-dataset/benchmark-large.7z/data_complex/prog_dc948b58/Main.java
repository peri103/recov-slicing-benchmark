import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        IntBuffer buffer = IntBuffer.allocate(5);
        ArrayList<Integer> randomNumbers = new ArrayList<>();
        Random random = new Random();

        // Fill buffer with random numbers
        for (int i = 0; i < 4; i++) {
            int num = random.nextInt(100);
            buffer.put(i, num);
            randomNumbers.add(num);
        }

        // Additional logic to manipulate randomNumbers
        int sum = 0;
        for (int num : randomNumbers) {
            sum += num;
        }
        System.out.println("Sum of random numbers: " + sum);

        // Original write-read pair
        /* write */ buffer.put(4, 42);

        // More complex logic
        int max = randomNumbers.get(0);
        for (int num : randomNumbers) {
            if (num > max) {
                max = num;
            }
        }
        System.out.println("Max random number: " + max);

        // Original read
        /* read */ int value = buffer.get(4);
        System.out.println("Read value: " + value);

        // Continue with more logic
        int min = randomNumbers.get(0);
        for (int num : randomNumbers) {
            if (num < min) {
                min = num;
            }
        }
        System.out.println("Min random number: " + min);
    }
}