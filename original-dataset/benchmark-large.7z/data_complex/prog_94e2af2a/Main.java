import java.util.concurrent.LinkedBlockingDeque;
import java.util.ArrayList;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        LinkedBlockingDeque<Integer> deque = new LinkedBlockingDeque<>();
        
        // Initially add some elements to the deque
        deque.add(1);
        deque.add(2);
        deque.add(3);
        
        ArrayList<String> strList = new ArrayList<>();
        strList.add("Hello");
        strList.add("World");
        
        HashMap<Integer, String> map = new HashMap<>();
        for (int i = 0; i < strList.size(); i++) {
            map.put(i, strList.get(i));
        }
        
        /* write */ deque.clear();
        
        // Performing some operations on the map
        for (int i = 0; i < map.size(); i++) {
            System.out.println("Key: " + i + ", Value: " + map.get(i));
        }
        
        // Adding more elements to deque
        deque.add(4);
        deque.add(5);
        
        // Additional operations on the ArrayList
        for (String str : strList) {
            System.out.println("String List Element: " + str);
        }
        
        /* read */ boolean isEmpty = deque.isEmpty();
        
        System.out.println("Deque is empty: " + isEmpty);
        
        // More complex logic with the deque
        if (!isEmpty) {
            while (!deque.isEmpty()) {
                System.out.println("Removed: " + deque.poll());
            }
        }
    }
}