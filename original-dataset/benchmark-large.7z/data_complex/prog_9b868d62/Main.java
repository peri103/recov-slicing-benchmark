import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        SynchronousQueue<Integer> queue = new SynchronousQueue<>();
        LinkedBlockingQueue<Integer> blockingQueue = new LinkedBlockingQueue<>();
        ArrayList<Integer> arrayList = new ArrayList<>();

        // Create a thread to perform the read operation
        Thread readerThread = new Thread(() -> {
            try {
                // Read the value from the queue
                /* read */ Integer value = queue.peek();
                System.out.println("Read value: " + value);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        // Start the reader thread
        readerThread.start();

        try {
            // Ensure the readerThread is ready to read
            Thread.sleep(100);

            // Write a value to the queue
            /* write */ queue.offer(42);

            // Wait for the readerThread to complete
            readerThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Additional complex operations
        // Using LinkedBlockingQueue
        for (int i = 0; i < 5; i++) {
            blockingQueue.offer(i * 10);
        }

        while (!blockingQueue.isEmpty()) {
            Integer val = blockingQueue.poll();
            arrayList.add(val);
        }

        // Perform some operations on the ArrayList
        for (int i = 0; i < arrayList.size(); i++) {
            arrayList.set(i, arrayList.get(i) + 5);
        }

        // Print the modified ArrayList
        for (Integer num : arrayList) {
            System.out.println("ArrayList value: " + num);
        }
    }
}