import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        IntStream intStream = IntStream.of(1, 2, 3, 4, 5);
        
        // Additional unrelated code
        List<String> stringList = new ArrayList<>();
        stringList.add("Hello");
        stringList.add("World");
        
        for (String str : stringList) {
            System.out.println(str);
        }
        
        // Additional use of similar API pairs
        IntStream anotherStream = IntStream.of(6, 7, 8, 9, 10);
        Stream<Integer> anotherBoxedStream = anotherStream.boxed();
        Integer[] anotherArray = anotherBoxedStream.toArray(Integer[]::new);
        
        for (Integer num : anotherArray) {
            System.out.println(num);
        }
        
        /* write */ Stream<Integer> boxedStream = intStream.boxed();
        
        // More unrelated code
        int[] numbers = {11, 12, 13, 14, 15};
        int sum = Arrays.stream(numbers).sum();
        System.out.println("Sum: " + sum);
        
        List<Integer> numList = Arrays.asList(16, 17, 18, 19, 20);
        numList.forEach(System.out::println);
        
        /* read */ Object[] array = boxedStream.toArray();
        
        for (Object obj : array) {
            System.out.println(obj);
        }
    }
}