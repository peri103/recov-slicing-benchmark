import java.util.concurrent.LinkedTransferQueue;
import java.util.Arrays;
import java.util.Queue;
import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {
        LinkedTransferQueue<Integer> queue = new LinkedTransferQueue<>();
        Queue<String> stringQueue = new LinkedList<>();
        
        // Initialize and add elements to the string queue
        stringQueue.add("First");
        stringQueue.add("Second");
        stringQueue.add("Third");
        
        // Process the string queue
        while (!stringQueue.isEmpty()) {
            String str = stringQueue.poll();
            System.out.println("Processing string: " + str);
        }

        // Add elements to the LinkedTransferQueue
        /* write */ queue.addAll(Arrays.asList(1, 2, 3, 4, 5));

        // Perform some unrelated operations
        int sum = 0;
        for (int i = 0; i < 10; i++) {
            sum += i;
        }
        System.out.println("Sum of first 10 natural numbers: " + sum);

        // Insert some delay or complex computation
        for (int i = 0; i < 1000000; i++) {
            // Simulate complex computation
            sum += i % 3;
        }

        // Read from the LinkedTransferQueue
        /* read */ Integer value = queue.poll();
        System.out.println("Polled value from queue: " + value);

        // More operations on the queue
        while (!queue.isEmpty()) {
            Integer num = queue.poll();
            System.out.println("Remaining value: " + num);
        }
    }
}