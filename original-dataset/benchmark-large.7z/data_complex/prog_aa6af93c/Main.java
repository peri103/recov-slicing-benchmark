import java.util.stream.Stream;
import java.util.List;
import java.util.ArrayList;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        // Initial stream with duplicate elements
        Stream<String> stream = Stream.of("apple", "banana", "apple", "orange", "banana", "grape");

        // Another stream for additional operations
        Stream<Integer> numberStream = Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

        // Convert numberStream to a list and filter even numbers
        List<Integer> evenNumbers = numberStream.filter(n -> n % 2 == 0).collect(Collectors.toList());

        // Print even numbers
        System.out.println("Even numbers:");
        for (Integer number : evenNumbers) {
            System.out.println(number);
        }

        // Perform distinct operation on the original stream
        /* write */ Stream<String> distinctStream = stream.distinct();

        // Perform another operation on evenNumbers list
        List<Integer> squaredNumbers = evenNumbers.stream().map(n -> n * n).collect(Collectors.toList());

        // Print squared numbers
        System.out.println("Squared even numbers:");
        for (Integer number : squaredNumbers) {
            System.out.println(number);
        }

        // Count distinct elements in the distinctStream
        /* read */ long count = distinctStream.count();

        // Print the count of distinct elements
        System.out.println("Count of distinct elements: " + count);

        // Additional unrelated operations to increase complexity
        List<String> fruits = new ArrayList<>();
        fruits.add("mango");
        fruits.add("pineapple");
        fruits.add("kiwi");

        // Print fruits
        System.out.println("Fruits list:");
        for (String fruit : fruits) {
            System.out.println(fruit);
        }

        // Concatenate strings from fruits list
        String allFruits = fruits.stream().collect(Collectors.joining(", "));
        System.out.println("All fruits: " + allFruits);
    }
}