import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.ArrayList;

public class Main {
    private static class Example {
        volatile int value;
    }

    public static void main(String[] args) {
        Example example = new Example();
        AtomicIntegerFieldUpdater<Example> updater = AtomicIntegerFieldUpdater.newUpdater(Example.class, "value");

        // Create and manipulate AtomicInteger
        AtomicInteger atomicInt = new AtomicInteger(100);
        atomicInt.incrementAndGet();
        atomicInt.addAndGet(50);

        // Create and manipulate AtomicReference
        AtomicReference<String> atomicRef = new AtomicReference<>("Initial");
        atomicRef.set("Updated");

        // Create and manipulate ArrayList
        ArrayList<Integer> list = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            list.add(i * 10);
        }

        /* write */ updater.set(example, 42);

        // Perform some operations on ArrayList
        for (int i = 0; i < list.size(); i++) {
            list.set(i, list.get(i) + 5);
        }

        // Print the result of AtomicInteger and AtomicReference
        System.out.println("AtomicInteger value: " + atomicInt.get());
        System.out.println("AtomicReference value: " + atomicRef.get());

        // Perform more operations on ArrayList
        for (Integer num : list) {
            System.out.println("ArrayList value: " + num);
        }

        /* read */ int value = updater.get(example);

        System.out.println("AtomicIntegerFieldUpdater value: " + value);
    }
}