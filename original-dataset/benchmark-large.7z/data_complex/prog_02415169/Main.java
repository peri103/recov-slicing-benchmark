import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.ArrayList;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        BlockingDeque<Integer> deque = new LinkedBlockingDeque<>();
        ArrayList<Integer> arrayList = new ArrayList<>();
        HashMap<Integer, String> map = new HashMap<>();

        // Adding elements to ArrayList
        for (int i = 0; i < 5; i++) {
            arrayList.add(i * 10);
        }

        // Adding elements to HashMap
        for (int i = 0; i < 5; i++) {
            map.put(i, "Value" + i);
        }

        // Processing elements in ArrayList
        for (int value : arrayList) {
            System.out.println("ArrayList value: " + value);
        }

        // Processing elements in HashMap
        for (int key : map.keySet()) {
            System.out.println("Map key: " + key + ", value: " + map.get(key));
        }

        /* write */ deque.addLast(42);

        // Unrelated operations
        int sum = 0;
        for (int value : arrayList) {
            sum += value;
        }
        System.out.println("Sum of ArrayList values: " + sum);

        // More unrelated operations
        StringBuilder sb = new StringBuilder();
        for (int key : map.keySet()) {
            sb.append(map.get(key)).append(" ");
        }
        System.out.println("Concatenated map values: " + sb.toString());

        try {
            /* read */ int value = deque.takeLast();
            System.out.println("Deque value: " + value);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}