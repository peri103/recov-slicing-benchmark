import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        try {
            Path filePath = Path.of("example.txt");
            String content = "Hello, World!";
            
            /* write */ Files.write(filePath, content.getBytes(StandardCharsets.UTF_8));

            // Additional complex code
            ArrayList<Integer> numbers = new ArrayList<>();
            for (int i = 0; i < 10; i++) {
                numbers.add(i * i);
            }

            Map<String, Integer> map = new HashMap<>();
            for (int i = 0; i < numbers.size(); i++) {
                map.put("key" + i, numbers.get(i));
            }

            for (Map.Entry<String, Integer> entry : map.entrySet()) {
                System.out.println(entry.getKey() + ": " + entry.getValue());
            }

            int sum = 0;
            for (int number : numbers) {
                sum += number;
            }
            System.out.println("Sum of squares: " + sum);

            // Reading content from file
            /* read */ List<String> lines = Files.readAllLines(filePath, StandardCharsets.UTF_8);
            for (String line : lines) {
                System.out.println(line);
            }

            // More complex operations
            numbers.removeIf(n -> n % 2 == 0);
            System.out.println("Odd squares:");
            for (int number : numbers) {
                System.out.println(number);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}