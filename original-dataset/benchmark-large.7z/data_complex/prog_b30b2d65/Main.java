import java.util.concurrent.ConcurrentSkipListSet;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        // Initialize a ConcurrentSkipListSet
        ConcurrentSkipListSet<Integer> set = new ConcurrentSkipListSet<>();
        
        // Initialize a HashMap for additional complexity
        Map<String, Integer> numberMap = new HashMap<>();
        numberMap.put("One", 1);
        numberMap.put("Two", 2);
        numberMap.put("Three", 3);
        
        // Add elements to the set
        /* write */ set.addAll(Arrays.asList(1, 2, 3, 4, 5));
        
        // Perform some operations on the map
        for (Map.Entry<String, Integer> entry : numberMap.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }
        
        // Perform some operations on the set
        if (set.contains(3)) {
            System.out.println("Set contains the number 3");
        }
        
        // Check if the set is empty
        /* read */ boolean isSetEmpty = set.isEmpty();
        System.out.println("Is the set empty? " + isSetEmpty);
        
        // Add more elements to the set
        set.addAll(Arrays.asList(6, 7, 8, 9, 10));
        
        // Iterate over the set and print each element
        for (Integer number : set) {
            System.out.println("Number in set: " + number);
        }
    }
}