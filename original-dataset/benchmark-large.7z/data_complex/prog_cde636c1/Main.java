import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;
import java.util.List;
import java.nio.charset.StandardCharsets;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Path sourcePath = Paths.get("source.txt");
        Path targetPath = Paths.get("target.txt");

        // Additional file operations
        Path anotherFilePath = Paths.get("anotherFile.txt");
        String content = "This is a sample content for another file.";
        
        try {
            // Writing content to another file
            Files.write(anotherFilePath, content.getBytes(StandardCharsets.UTF_8), StandardOpenOption.CREATE);

            // Reading content from another file
            List<String> anotherFileLines = Files.readAllLines(anotherFilePath);
            for (String line : anotherFileLines) {
                System.out.println("Another file line: " + line);
            }

            /* write */ Files.move(sourcePath, targetPath);

            // Simulating some complex operations
            ArrayList<Integer> numbers = new ArrayList<>();
            for (int i = 0; i < 10; i++) {
                numbers.add(i * 2);
            }

            int sum = 0;
            for (int num : numbers) {
                sum += num;
            }
            System.out.println("Sum of numbers: " + sum);

            /* read */ List<String> lines = Files.readAllLines(targetPath);
            for (String line : lines) {
                System.out.println("Target file line: " + line);
            }

            // More complex operations
            int product = 1;
            for (int num : numbers) {
                product *= num;
            }
            System.out.println("Product of numbers: " + product);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}