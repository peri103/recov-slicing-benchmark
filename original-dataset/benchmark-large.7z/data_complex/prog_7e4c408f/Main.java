import java.util.concurrent.atomic.AtomicIntegerArray;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        // Initialize an AtomicIntegerArray with one element
        AtomicIntegerArray atomicArray = new AtomicIntegerArray(1);

        // Initialize a HashMap to store some data
        Map<String, Integer> dataMap = new HashMap<>();
        dataMap.put("key1", 100);
        dataMap.put("key2", 200);

        // Perform some operations on the HashMap
        for (Map.Entry<String, Integer> entry : dataMap.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }

        // Increment the value at index 0 and get the new value
        /* write */ int incrementedValue = atomicArray.incrementAndGet(0);

        // Perform some calculations
        int sum = 0;
        for (int i = 0; i < 5; i++) {
            sum += i * 10;
        }
        System.out.println("Sum: " + sum);

        // Read the value at index 0
        /* read */ int value = atomicArray.get(0);

        // Print the value to ensure it is the same as incrementedValue
        System.out.println("Value from AtomicIntegerArray: " + value);

        // Adding more complexity with another AtomicIntegerArray
        AtomicIntegerArray anotherAtomicArray = new AtomicIntegerArray(2);
        anotherAtomicArray.set(0, 5);
        anotherAtomicArray.set(1, 10);

        // Perform some operations on the new AtomicIntegerArray
        int product = 1;
        for (int i = 0; i < anotherAtomicArray.length(); i++) {
            product *= anotherAtomicArray.get(i);
        }
        System.out.println("Product of elements in anotherAtomicArray: " + product);
    }
}