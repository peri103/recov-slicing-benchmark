import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;
import java.util.PriorityQueue;
import java.util.Queue;

public class Main {
    public static void main(String[] args) {
        DelayQueue<DelayedElement> queue = new DelayQueue<>();
        PriorityQueue<Integer> priorityQueue = new PriorityQueue<>();
        
        // Adding elements to the PriorityQueue
        for (int i = 0; i < 5; i++) {
            priorityQueue.add(i * 10);
        }

        /* write */ 
        queue.put(new DelayedElement("Hello, World!", 1000));

        // Processing elements from the PriorityQueue
        while (!priorityQueue.isEmpty()) {
            Integer number = priorityQueue.poll();
            System.out.println("PriorityQueue Element: " + number);
        }

        // Introducing some unrelated complexity with a custom Queue
        Queue<String> customQueue = new PriorityQueue<>();
        customQueue.add("First");
        customQueue.add("Second");
        customQueue.add("Third");

        while (!customQueue.isEmpty()) {
            String item = customQueue.poll();
            System.out.println("CustomQueue Element: " + item);
        }

        try {
            /* read */ 
            DelayedElement element = queue.take();
            System.out.println(element.getMessage());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.err.println("Thread was interrupted.");
        }
    }
}

class DelayedElement implements Delayed {
    private final String message;
    private final long startTime;

    public DelayedElement(String message, long delay) {
        this.message = message;
        this.startTime = System.currentTimeMillis() + delay;
    }

    public String getMessage() {
        return message;
    }

    @Override
    public long getDelay(TimeUnit unit) {
        long diff = startTime - System.currentTimeMillis();
        return unit.convert(diff, TimeUnit.MILLISECONDS);
    }

    @Override
    public int compareTo(Delayed o) {
        if (this.startTime < ((DelayedElement) o).startTime) {
            return -1;
        }
        if (this.startTime > ((DelayedElement) o).startTime) {
            return 1;
        }
        return 0;
    }
}