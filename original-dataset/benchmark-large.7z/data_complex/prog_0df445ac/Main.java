import java.util.Optional;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Optional<Integer> optional = Optional.empty();
        Optional<Integer> anotherOptional = Optional.of(1);

        // Additional complex code
        List<String> names = new ArrayList<>();
        names.add("Alice");
        names.add("Bob");
        names.add("Charlie");
        
        for (String name : names) {
            System.out.println("Processing name: " + name);
        }

        // Another Optional example
        Optional<String> optionalName = Optional.of("David");
        if (optionalName.isPresent()) {
            System.out.println("Optional contains: " + optionalName.get());
        }

        /* write */ boolean isEqual = optional.equals(anotherOptional);

        if (isEqual) {
            optional = anotherOptional;
        }

        // More complex code
        List<Integer> numbers = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            numbers.add(i * 2);
        }

        for (int number : numbers) {
            System.out.println("Number: " + number);
        }

        /* read */ boolean isPresent = optional.isPresent();
        System.out.println("Is value present: " + isPresent);

        // Additional unrelated code
        String message = "Hello, World!";
        System.out.println("Message length: " + message.length());
        
        Optional<Double> optionalDouble = Optional.of(3.14);
        optionalDouble.ifPresent(value -> System.out.println("Optional double value: " + value));
    }
}