import java.util.Optional;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Original write-read pair using Optional
        Integer valueToWrite = 42;
        /* write */ Optional<Integer> optionalValue = Optional.ofNullable(valueToWrite);

        // Additional complex code
        List<Integer> numbers = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            numbers.add(i);
        }

        int sum = 0;
        for (int number : numbers) {
            sum += number;
        }
        System.out.println("Sum of numbers: " + sum);

        // Simulate some processing
        List<String> strings = new ArrayList<>();
        strings.add("Hello");
        strings.add("World");
        for (String str : strings) {
            System.out.println(str);
        }

        // More unrelated code
        List<Double> doubles = new ArrayList<>();
        for (double d = 0.5; d <= 5.0; d += 0.5) {
            doubles.add(d);
        }
        double total = 0;
        for (double d : doubles) {
            total += d;
        }
        System.out.println("Total of doubles: " + total);

        // Original read from Optional
        /* read */ Integer value = optionalValue.orElse(null);
        System.out.println("Value from Optional: " + value);

        // Further unrelated code
        List<Boolean> booleans = new ArrayList<>();
        booleans.add(true);
        booleans.add(false);
        for (boolean b : booleans) {
            System.out.println("Boolean value: " + b);
        }
    }
}