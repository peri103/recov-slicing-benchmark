import java.util.concurrent.atomic.AtomicBooleanFieldUpdater;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.ArrayList;

public class Main {
    private static class MyClass {
        volatile boolean flag;
        volatile int count;
        volatile long timestamp;
    }

    public static void main(String[] args) {
        MyClass myObject = new MyClass();
        AtomicBooleanFieldUpdater<MyClass> booleanUpdater = AtomicBooleanFieldUpdater.newUpdater(MyClass.class, "flag");
        AtomicIntegerFieldUpdater<MyClass> integerUpdater = AtomicIntegerFieldUpdater.newUpdater(MyClass.class, "count");
        AtomicLongFieldUpdater<MyClass> longUpdater = AtomicLongFieldUpdater.newUpdater(MyClass.class, "timestamp");

        ArrayList<Integer> numberList = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            numberList.add(i);
        }

        /* write */ booleanUpdater.set(myObject, true);
        
        longUpdater.set(myObject, System.currentTimeMillis());
        integerUpdater.set(myObject, 42);

        for (int number : numberList) {
            System.out.println("Number: " + number);
        }

        int countValue = integerUpdater.get(myObject);
        System.out.println("Count value: " + countValue);

        long timestampValue = longUpdater.get(myObject);
        System.out.println("Timestamp value: " + timestampValue);
        
        /* read */ boolean flagValue = booleanUpdater.get(myObject);
        System.out.println("Flag value: " + flagValue);

        ArrayList<String> stringList = new ArrayList<>();
        stringList.add("Hello");
        stringList.add("World");

        for (String str : stringList) {
            System.out.println("String: " + str);
        }
    }
}