import java.util.stream.Stream;
import java.util.List;
import java.util.ArrayList;
import java.util.Optional;

public class Main {
    public static void main(String[] args) {
        // Initial Stream for the original write-read pair
        Stream<Integer> stream = Stream.of(1, 2, 3, 4, 5);

        // Using reduce to calculate sum of elements in the stream
        /* write */ int sum = stream.reduce(0, Integer::sum);

        // Creating a new stream as streams cannot be reused
        Stream<Integer> streamForCount = Stream.of(1, 2, 3, 4, 5);

        // Unrelated code to make the program more complex
        List<String> names = new ArrayList<>();
        names.add("Alice");
        names.add("Bob");
        names.add("Charlie");

        // Using a different API pair
        Optional<String> longestName = names.stream().reduce((name1, name2) -> name1.length() > name2.length() ? name1 : name2);
        longestName.ifPresent(name -> System.out.println("Longest name: " + name));

        // More unrelated code
        List<Integer> numbers = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            numbers.add(i * 10);
        }

        // Process numbers list
        numbers.stream().filter(num -> num % 20 == 0).forEach(num -> System.out.println("Filtered number: " + num));

        // Using count to get the number of elements in the new stream
        /* read */ long count = streamForCount.count();

        System.out.println("Sum: " + sum);
        System.out.println("Count: " + count);

        // Additional processing
        List<Integer> squaredNumbers = new ArrayList<>();
        numbers.stream().map(num -> num * num).forEach(squaredNumbers::add);

        System.out.println("Squared numbers: " + squaredNumbers);
    }
}