import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.nio.file.StandardOpenOption;
import java.nio.charset.StandardCharsets;

public class Main {
    public static void main(String[] args) {
        try {
            // Create a list of strings
            List<String> lines = new ArrayList<>();
            lines.add("This is line 1");
            lines.add("This is line 2");

            // Create a temporary file
            /* write */ Path tempFile = Files.createTempFile("temp", ".txt");

            // Write lines to the temporary file
            Files.write(tempFile, lines, StandardCharsets.UTF_8, StandardOpenOption.WRITE);

            // Perform some unrelated operations
            int sum = 0;
            for (int i = 0; i < 10; i++) {
                sum += i;
            }
            System.out.println("Sum of numbers from 0 to 9: " + sum);

            // Check if the file exists
            /* read */ boolean exists = Files.exists(tempFile);

            // Print the result
            System.out.println("Temp file exists: " + exists);

            // Read lines from the temporary file and print them
            List<String> readLines = Files.readAllLines(tempFile, StandardCharsets.UTF_8);
            for (String line : readLines) {
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}