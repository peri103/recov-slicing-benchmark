import java.util.Optional;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        // Initialize an Optional with a value
        Optional<String> optionalValue = Optional.of("Hello, World!");

        // Use the write method orElseThrow to ensure the value is present
        /* write */ String value = optionalValue.orElseThrow();

        // Additional code to make the program more complex
        Map<String, Integer> wordCount = new HashMap<>();
        String sentence = "This is a complex program example";
        String[] words = sentence.split(" ");

        for (String word : words) {
            wordCount.put(word, wordCount.getOrDefault(word, 0) + 1);
        }

        // Simulate some processing
        for (Map.Entry<String, Integer> entry : wordCount.entrySet()) {
            System.out.println("Word: " + entry.getKey() + ", Count: " + entry.getValue());
        }

        // Use the read method isPresent to check if the value is present
        /* read */ boolean isValuePresent = optionalValue.isPresent();

        // Print the results
        System.out.println("Value: " + value);
        System.out.println("Is value present: " + isValuePresent);

        // More unrelated complexity
        Optional<Integer> optionalNumber = Optional.of(42);
        optionalNumber.ifPresent(num -> System.out.println("Optional number: " + num));

        int sum = 0;
        for (int i = 0; i < 10; i++) {
            sum += i;
        }
        System.out.println("Sum of first 10 numbers: " + sum);
    }
}