import java.util.stream.Stream;
import java.util.Optional;
import java.util.List;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Original stream
        Stream<Integer> stream = Stream.of(1, 2, 3, 4, 5);
        
        // Create another stream to demonstrate more operations
        Stream<String> stringStream = Stream.of("apple", "banana", "cherry", "date", "elderberry");

        // Filter the string stream
        Stream<String> filteredStringStream = stringStream.filter(s -> s.startsWith("b"));
        
        // Find the first element in the filtered string stream
        Optional<String> firstString = filteredStringStream.findFirst();
        
        // Print the first string
        firstString.ifPresent(System.out::println);

        // Use a list to demonstrate more complex operations
        List<Double> doubleList = new ArrayList<>();
        for (double i = 0.5; i < 5; i += 0.5) {
            doubleList.add(i);
        }

        // Create a stream from the list and filter it
        Stream<Double> doubleStream = doubleList.stream().filter(d -> d > 2.0);

        // Print all elements in the filtered double stream
        doubleStream.forEach(System.out::println);

        // Original write and read operations
        /* write */ Stream<Integer> filteredStream = stream.filter(x -> x > 2);
        
        // Some unrelated operations
        int sum = 0;
        for (int i = 0; i < 5; i++) {
            sum += i;
        }
        System.out.println("Sum: " + sum);

        // More unrelated code
        List<Character> charList = new ArrayList<>();
        for (char c = 'a'; c <= 'e'; c++) {
            charList.add(c);
        }
        charList.forEach(System.out::println);
        
        /* read */ Optional<Integer> value = filteredStream.findFirst();
        value.ifPresent(System.out::println);
    }
}