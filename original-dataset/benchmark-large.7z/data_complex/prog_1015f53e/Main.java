import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.UserDefinedFileAttributeView;
import java.nio.charset.Charset;
import java.io.IOException;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.List;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Path filePath = Paths.get("example.txt");

        try {
            // Create a file if it doesn't exist
            if (!Files.exists(filePath)) {
                Files.createFile(filePath);
            }

            // Define the attribute name and value
            String attributeName = "user.mydescription";
            String attributeValue = "This is a test attribute";

            UserDefinedFileAttributeView view = Files.getFileAttributeView(filePath, UserDefinedFileAttributeView.class);

            // Set the attribute
            /* write */ view.write(attributeName, Charset.defaultCharset().encode(attributeValue));

            // Perform some unrelated operations
            BasicFileAttributes basicAttr = Files.readAttributes(filePath, BasicFileAttributes.class);
            System.out.println("Creation Time: " + basicAttr.creationTime());
            System.out.println("File Size: " + basicAttr.size());

            // Create a list and populate it
            List<String> stringList = new ArrayList<>();
            stringList.add("First");
            stringList.add("Second");
            stringList.add("Third");

            // Print list elements
            for (String str : stringList) {
                System.out.println("List Element: " + str);
            }

            // Perform some more unrelated operations
            Path anotherFilePath = Paths.get("another_example.txt");
            if (!Files.exists(anotherFilePath)) {
                Files.createFile(anotherFilePath);
            }
            Files.write(anotherFilePath, "Hello, World!".getBytes());

            // Read the attribute
            int size = view.size(attributeName);
            byte[] readValue = new byte[size];
            /* read */ view.read(attributeName, Charset.defaultCharset().decode(java.nio.ByteBuffer.wrap(readValue)).array());
            String value = new String(readValue, Charset.defaultCharset());

            System.out.println("Attribute value: " + value);

            // Read the content of the second file
            List<String> lines = Files.readAllLines(anotherFilePath, Charset.defaultCharset());
            for (String line : lines) {
                System.out.println("File Content: " + line);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}