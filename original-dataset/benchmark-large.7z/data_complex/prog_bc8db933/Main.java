import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.LinkedList;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        // Original ConcurrentLinkedDeque write-read pair
        ConcurrentLinkedDeque<Integer> deque = new ConcurrentLinkedDeque<>();
        /* write */ deque.addLast(42);

        // Additional code to increase complexity
        LinkedList<String> list = new LinkedList<>();
        list.add("Hello");
        list.add("World");
        list.add("!");

        // Iterate through LinkedList
        for (String str : list) {
            System.out.println(str);
        }

        // Using HashMap to store and retrieve values
        HashMap<String, Integer> map = new HashMap<>();
        map.put("Key1", 100);
        map.put("Key2", 200);

        // Retrieve values from HashMap
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

        // Additional logic involving the original deque
        int sum = 0;
        deque.addLast(10);
        deque.addLast(20);
        deque.addLast(30);

        for (Integer num : deque) {
            sum += num;
        }
        System.out.println("Sum of elements in deque: " + sum);

        // Original read method
        /* read */ Integer value = deque.peekLast();
        System.out.println("Peek last value: " + value);

        // Additional logic to manipulate the deque
        deque.removeFirst();
        deque.addFirst(99);

        for (Integer num : deque) {
            System.out.println("Deque element: " + num);
        }
    }
}