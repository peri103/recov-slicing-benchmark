import java.util.IdentityHashMap;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        IdentityHashMap<String, String> map = new IdentityHashMap<>();
        HashMap<Integer, String> anotherMap = new HashMap<>();
        anotherMap.put(1, "First");
        anotherMap.put(2, "Second");

        System.out.println("Iterating over anotherMap:");
        for (Map.Entry<Integer, String> entry : anotherMap.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }

        /* write */ map.put("key", "value");

        // Some unrelated computations
        int sum = 0;
        for (int i = 0; i < 5; i++) {
            sum += i;
        }
        System.out.println("Sum of first 5 numbers is: " + sum);

        // Using another map
        String retrievedValue = anotherMap.get(1);
        System.out.println("Retrieved from anotherMap: " + retrievedValue);

        // More unrelated logic
        int factorial = 1;
        for (int i = 1; i <= 5; i++) {
            factorial *= i;
        }
        System.out.println("Factorial of 5 is: " + factorial);

        /* read */ String value = map.get("key");
        System.out.println(value);
    }
}