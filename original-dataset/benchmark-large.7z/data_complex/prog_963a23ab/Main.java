import java.util.Queue;
import java.util.LinkedList;
import java.util.Stack;

public class Main {
    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();
        Stack<Integer> stack = new Stack<>();
        
        // Add some elements to the stack
        for (int i = 0; i < 5; i++) {
            stack.push(i * 10);
        }
        
        // Process stack elements
        while (!stack.isEmpty()) {
            int element = stack.pop();
            System.out.println("Popped from stack: " + element);
            if (element % 20 == 0) {
                queue.offer(element / 2);
            }
        }
        
        // Add an element to the queue
        /* write */ queue.offer(42);
        
        // Some unrelated computations
        int sum = 0;
        for (int i = 0; i < 10; i++) {
            sum += i;
        }
        System.out.println("Sum of first 10 numbers: " + sum);
        
        // Process queue elements
        while (!queue.isEmpty()) {
            /* read */ int value = queue.poll();
            System.out.println("Polled from queue: " + value);
        }
        
        // Additional complexity with another queue
        Queue<String> stringQueue = new LinkedList<>();
        stringQueue.offer("Hello");
        stringQueue.offer("World");
        
        while (!stringQueue.isEmpty()) {
            String str = stringQueue.poll();
            System.out.println("Polled from string queue: " + str);
        }
    }
}