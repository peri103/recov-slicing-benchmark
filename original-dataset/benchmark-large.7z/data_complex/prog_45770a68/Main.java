import java.util.stream.LongStream;
import java.util.stream.Collectors;
import java.util.List;
import java.util.function.LongPredicate;
import java.util.OptionalLong;

public class Main {
    public static void main(String[] args) {
        // Original LongStream
        LongStream longStream = LongStream.of(1, 2, 3, 4, 5);

        // Additional code: Filter the stream for even numbers
        LongPredicate isEven = n -> n % 2 == 0;
        LongStream evenNumbersStream = longStream.filter(isEven);

        // Additional code: Find the maximum value in the filtered stream
        OptionalLong maxEvenNumber = evenNumbersStream.max();
        if (maxEvenNumber.isPresent()) {
            System.out.println("Max even number: " + maxEvenNumber.getAsLong());
        } else {
            System.out.println("No even numbers found.");
        }

        // Resetting the original stream for the write-read pair
        longStream = LongStream.of(1, 2, 3, 4, 5);

        /* write */ LongStream transformedStream = longStream.flatMap(n -> LongStream.of(n, n * n));

        // Additional code: Perform another transformation on the transformed stream
        LongStream doubledStream = transformedStream.map(n -> n * 2);

        // Additional code: Collect the doubled values into a list
        List<Long> doubledList = doubledStream.boxed().collect(Collectors.toList());
        System.out.println("Doubled values: " + doubledList);

        /* read */ List<Long> collectedList = transformedStream.boxed().collect(Collectors.toList());

        System.out.println("Transformed values: " + collectedList);
    }
}