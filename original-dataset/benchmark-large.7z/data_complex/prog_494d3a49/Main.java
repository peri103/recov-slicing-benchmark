import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        List<List<String>> listOfLists = Arrays.asList(
            Arrays.asList("a", "b", "c"),
            Arrays.asList("d", "e", "f"),
            Arrays.asList("g", "h", "i")
        );

        Stream<String> flatStream = listOfLists.stream()
            /* write */ .flatMap(List::stream);

        // Additional unrelated code to increase complexity
        Map<String, Integer> frequencyMap = new HashMap<>();
        for (List<String> list : listOfLists) {
            for (String s : list) {
                frequencyMap.put(s, frequencyMap.getOrDefault(s, 0) + 1);
            }
        }

        // Additional use of Stream API
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);
        int sum = numbers.stream().mapToInt(Integer::intValue).sum();
        System.out.println("Sum of numbers: " + sum);

        // More unrelated logic
        for (Map.Entry<String, Integer> entry : frequencyMap.entrySet()) {
            System.out.println("Character: " + entry.getKey() + ", Frequency: " + entry.getValue());
        }

        /* read */ List<String> flatList = flatStream.collect(Collectors.toList());

        System.out.println(flatList);

        // Further unrelated logic
        List<String> filteredList = flatList.stream()
            .filter(s -> s.compareTo("e") > 0)
            .collect(Collectors.toList());

        System.out.println("Filtered List: " + filteredList);
    }
}