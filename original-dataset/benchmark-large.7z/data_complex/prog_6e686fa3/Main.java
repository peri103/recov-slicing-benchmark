import java.util.concurrent.LinkedTransferQueue;
import java.util.Queue;
import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {
        LinkedTransferQueue<Integer> queue = new LinkedTransferQueue<>();
        
        // Initialize queue with some elements
        queue.add(10);
        queue.add(30);
        queue.add(50);
        
        // Create another queue with different elements
        Queue<Integer> anotherQueue = new LinkedList<>();
        anotherQueue.add(70);
        anotherQueue.add(90);
        
        // Process elements in anotherQueue
        while (!anotherQueue.isEmpty()) {
            Integer element = anotherQueue.poll();
            System.out.println("Processing element: " + element);
            queue.add(element); // Add processed element to the main queue
        }
        
        // Remove an element from the main queue
        /* write */ queue.remove(10);
        
        // Iterate over the queue and print elements
        for (Integer elem : queue) {
            System.out.println("Queue element: " + elem);
        }
        
        // Add a new element to the queue
        queue.add(20);
        
        // Poll an element from the queue
        /* read */ Integer value = queue.poll();
        
        System.out.println("Polled value: " + value);
        
        // Further processing on the queue
        while (!queue.isEmpty()) {
            Integer processedValue = queue.poll();
            System.out.println("Further processed value: " + processedValue);
        }
        
        // Add more elements to the queue for future operations
        queue.add(100);
        queue.add(200);
        queue.add(300);
        
        // Perform some complex operations
        int sum = 0;
        for (Integer elem : queue) {
            sum += elem;
        }
        System.out.println("Sum of queue elements: " + sum);
    }
}