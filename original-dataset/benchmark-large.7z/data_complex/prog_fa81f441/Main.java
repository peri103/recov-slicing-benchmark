import java.util.stream.Stream;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        // Original write-read pair
        Stream<Integer> stream = Stream.of(1, 2, 3, 4, 5);
        /* write */ Object[] array = stream.toArray();

        // Additional complex code
        List<Integer> list = new ArrayList<>();
        for (int i = 1; i <= 5; i++) {
            list.add(i);
        }

        // Creating a new stream to perform additional operations
        Stream<Integer> newStream = list.stream();
        newStream = newStream.map(x -> x * 2);
        
        // Collecting results into a list
        List<Integer> doubledList = newStream.collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
        System.out.println("Doubled List: " + doubledList);

        // Unrelated computation
        int sum = 0;
        for (int num : doubledList) {
            sum += num;
        }
        System.out.println("Sum of doubled values: " + sum);

        // Create a new stream from the array to use the read method
        Stream<Object> arrayStream = Arrays.stream(array);
        /* read */ long count = arrayStream.count();

        System.out.println("Count of elements: " + count);

        // Additional unrelated operations
        List<String> words = Arrays.asList("apple", "banana", "cherry");
        words.stream()
            .map(String::toUpperCase)
            .forEach(System.out::println);
    }
}