import java.util.concurrent.ConcurrentSkipListSet;
import java.util.HashMap;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ConcurrentSkipListSet<Integer> set = new ConcurrentSkipListSet<>();
        set.add(1); // Initialize the set with a value to remove

        HashMap<String, Integer> map = new HashMap<>();
        map.put("one", 1);
        map.put("two", 2);

        ArrayList<Integer> list = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            list.add(i * 10);
        }

        int sum = 0;
        for (int num : list) {
            sum += num;
        }
        System.out.println("Sum of list: " + sum);

        /* write */ set.remove(1);

        // Simulate some complex logic
        for (String key : map.keySet()) {
            System.out.println("Key: " + key + ", Value: " + map.get(key));
        }

        list.addAll(map.values());

        int max = Integer.MIN_VALUE;
        for (int num : list) {
            if (num > max) {
                max = num;
            }
        }
        System.out.println("Max in list: " + max);

        /* read */ boolean contains = set.contains(1);
        
        System.out.println(contains); // This should print 'false' since we removed the element

        // More complex logic
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i) % 2 == 0) {
                System.out.println("Even number: " + list.get(i));
            }
        }

        ConcurrentSkipListSet<String> stringSet = new ConcurrentSkipListSet<>();
        stringSet.add("apple");
        stringSet.add("banana");

        if (stringSet.contains("apple")) {
            System.out.println("Apple is in the set");
        }
    }
}