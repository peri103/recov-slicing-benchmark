import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        AtomicReference<Integer> atomicRef = new AtomicReference<>(0);
        AtomicInteger atomicInt = new AtomicInteger(100);
        ArrayList<Integer> numberList = new ArrayList<>();

        // Simulate some complex operations
        for (int i = 0; i < 10; i++) {
            numberList.add(atomicInt.getAndAdd(i));
        }

        // Perform some unrelated operations
        for (int i = 0; i < numberList.size(); i++) {
            System.out.println("Number at index " + i + ": " + numberList.get(i));
        }

        /* write */ atomicRef.compareAndSet(0, 42);

        // More unrelated operations
        int sum = 0;
        for (int num : numberList) {
            sum += num;
        }
        System.out.println("Sum of numbers in list: " + sum);

        /* read */ int value = atomicRef.get();
        System.out.println("Value from AtomicReference: " + value);

        // Additional complex logic
        if (value > 20) {
            System.out.println("Value is greater than 20.");
        } else {
            System.out.println("Value is 20 or less.");
        }

        // Final unrelated operation
        int product = 1;
        for (int i = 1; i <= 5; i++) {
            product *= i;
        }
        System.out.println("Product of numbers 1 to 5: " + product);
    }
}