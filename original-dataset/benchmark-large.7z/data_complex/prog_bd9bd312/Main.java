import java.util.concurrent.LinkedBlockingDeque;
import java.util.Arrays;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        LinkedBlockingDeque<Integer> deque = new LinkedBlockingDeque<>(Arrays.asList(1, 2, 3, 4, 5));
        HashMap<Integer, String> map = new HashMap<>();
        map.put(1, "One");
        map.put(2, "Two");
        map.put(3, "Three");
        
        // Perform some operations on the map
        if(map.containsKey(2)) {
            System.out.println("Map contains key 2 with value: " + map.get(2));
        }
        
        // Modify the deque
        deque.addFirst(6);
        deque.addLast(0);
        
        // Remove elements not in the specified collection
        /* write */ deque.retainAll(Arrays.asList(2, 3, 4));
        
        // Perform additional operations on the deque
        deque.offer(7);
        deque.poll();
        
        // More operations on the map
        map.remove(1);
        map.put(4, "Four");
        
        // Check the size of the deque after modifications
        /* read */ int size = deque.size();
        System.out.println("Size of deque: " + size);
        
        // Print remaining elements in the deque
        for(Integer num : deque) {
            System.out.println("Deque element: " + num);
        }
        
        // Print final state of the map
        System.out.println("Final Map: " + map);
    }
}