import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;

public class Main {

    static class MyClass {
        volatile String field;
        volatile int intField;
        volatile long longField;
    }

    public static void main(String[] args) {
        MyClass myObject = new MyClass();
        
        AtomicReferenceFieldUpdater<MyClass, String> stringUpdater =
                AtomicReferenceFieldUpdater.newUpdater(MyClass.class, String.class, "field");
        AtomicIntegerFieldUpdater<MyClass> intUpdater =
                AtomicIntegerFieldUpdater.newUpdater(MyClass.class, "intField");
        AtomicLongFieldUpdater<MyClass> longUpdater =
                AtomicLongFieldUpdater.newUpdater(MyClass.class, "longField");

        // Set some initial values
        intUpdater.set(myObject, 10);
        longUpdater.set(myObject, 100L);

        // Perform some operations
        intUpdater.addAndGet(myObject, 5);
        longUpdater.addAndGet(myObject, 50L);

        /* write */ stringUpdater.set(myObject, "Hello, World!");

        // More operations
        int intValue = intUpdater.get(myObject);
        long longValue = longUpdater.get(myObject);
        
        System.out.println("Int Value: " + intValue);
        System.out.println("Long Value: " + longValue);

        // Further complex operations
        intUpdater.incrementAndGet(myObject);
        longUpdater.decrementAndGet(myObject);

        // Read the value set by the original write
        /* read */ String value = stringUpdater.get(myObject);
        System.out.println(value);

        // Additional complex logic
        for (int i = 0; i < 3; i++) {
            intUpdater.addAndGet(myObject, i);
            longUpdater.addAndGet(myObject, i * 10L);
        }

        System.out.println("Final Int Value: " + intUpdater.get(myObject));
        System.out.println("Final Long Value: " + longUpdater.get(myObject));
    }
}