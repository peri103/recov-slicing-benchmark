import java.util.concurrent.LinkedTransferQueue;
import java.util.Arrays;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        LinkedTransferQueue<Integer> queue = new LinkedTransferQueue<>();
        ArrayList<Integer> arrayList = new ArrayList<>();
        
        // Adding numbers to the ArrayList
        for (int i = 1; i <= 5; i++) {
            arrayList.add(i * 10);
        }
        
        // Adding elements of ArrayList to the queue
        /* write */ queue.addAll(Arrays.asList(1, 2, 3, 4, 5));
        
        // Additional operations on the queue
        queue.addAll(arrayList);
        
        // Simulate complex operations
        int sum = 0;
        for (Integer num : arrayList) {
            sum += num;
        }
        System.out.println("Sum of ArrayList elements: " + sum);
        
        // Check if queue is empty
        /* read */ boolean isEmpty = queue.isEmpty();
        System.out.println("Is the queue empty? " + isEmpty);
        
        // Further operations on the queue
        Integer firstElement = queue.poll();
        System.out.println("First element removed from the queue: " + firstElement);
        
        // Printing the remaining elements in the queue
        System.out.println("Remaining elements in the queue:");
        for (Integer num : queue) {
            System.out.println(num);
        }
    }
}