import java.util.concurrent.CopyOnWriteArrayList;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        CopyOnWriteArrayList<Integer> list = new CopyOnWriteArrayList<>();
        list.add(1);  // Adding initial elements to the list
        list.add(2);
        list.add(3);

        Map<String, Integer> map = new HashMap<>();
        map.put("first", 10);
        map.put("second", 20);

        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

        // Adding more elements to the list
        list.add(4);
        list.add(5);

        /* write */ list.remove(1); // This will remove the element at index 1, which is the value 2

        // Perform some operations with another CopyOnWriteArrayList
        CopyOnWriteArrayList<String> stringList = new CopyOnWriteArrayList<>();
        stringList.add("Hello");
        stringList.add("World");
        stringList.add("!");

        for (String str : stringList) {
            System.out.println(str);
        }

        // Some additional complex logic
        int sum = 0;
        for (int i = 0; i < list.size(); i++) {
            sum += list.get(i);
        }
        System.out.println("Sum of elements: " + sum);

        /* read */ int value = list.get(1); // This will now get the element at index 1, which is the value 3
        System.out.println(value);

        // More unrelated code to increase complexity
        for (int i = 0; i < 3; i++) {
            if (i % 2 == 0) {
                System.out.println("Even: " + i);
            } else {
                System.out.println("Odd: " + i);
            }
        }
    }
}