import java.util.concurrent.CopyOnWriteArrayList;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        CopyOnWriteArrayList<Integer> list = new CopyOnWriteArrayList<>();
        CopyOnWriteArrayList<Integer> list2 = new CopyOnWriteArrayList<>();
        Map<String, Integer> map = new HashMap<>();
        
        /* write */ list.addIfAbsent(42);
        
        list2.add(100);
        list2.add(200);
        list2.add(300);

        map.put("One", 1);
        map.put("Two", 2);
        map.put("Three", 3);

        int sumList2 = 0;
        for (int num : list2) {
            sumList2 += num;
        }
        
        System.out.println("Sum of list2: " + sumList2);

        int sumMapValues = 0;
        for (Integer value : map.values()) {
            sumMapValues += value;
        }
        
        System.out.println("Sum of map values: " + sumMapValues);

        // Performing some operations before reading from the list
        list2.addAll(list);
        list2.removeIf(n -> n == 100);
        
        /* read */ int value = list.get(0);
        System.out.println("Value from list: " + value);

        // Additional operations after reading
        for (int i = 0; i < list2.size(); i++) {
            System.out.println("Element at index " + i + " in list2: " + list2.get(i));
        }
    }
}