import java.util.stream.Stream;
import java.util.List;
import java.util.ArrayList;
import java.util.Optional;

public class Main {
    public static void main(String[] args) {
        // Initialize a stream of integers
        Stream<Integer> stream = Stream.of(1, 2, 3, 4, 5);

        // Perform a reduction operation to sum up the elements
        /* write */ Integer sum = stream.reduce(0, Integer::sum);

        // Re-initialize the stream as streams cannot be reused after a terminal operation
        stream = Stream.of(1, 2, 3, 4, 5);

        // Some unrelated operations to increase complexity
        List<String> names = new ArrayList<>();
        names.add("Alice");
        names.add("Bob");
        names.add("Charlie");

        Optional<String> longestName = names.stream()
                                            .reduce((name1, name2) -> name1.length() > name2.length() ? name1 : name2);

        longestName.ifPresent(name -> System.out.println("Longest name: " + name));

        // More unrelated operations
        List<Integer> numbers = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            numbers.add(i * i);
        }

        numbers.stream()
               .filter(num -> num % 2 == 0)
               .forEach(num -> System.out.println("Even square: " + num));

        // Count the number of elements in the stream
        /* read */ long count = stream.count();

        // Output results
        System.out.println("Sum: " + sum);
        System.out.println("Count: " + count);

        // Additional logic to further increase complexity
        Stream<String> wordStream = Stream.of("apple", "banana", "cherry", "date");
        long wordCount = wordStream.filter(word -> word.length() > 5).count();
        System.out.println("Words longer than 5 characters: " + wordCount);
    }
}