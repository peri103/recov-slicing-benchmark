import java.util.stream.Stream;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;

public class Main {
    public static void main(String[] args) {
        List<Integer> numbers = List.of(1, 2, 2, 3, 4, 4, 5);
        Stream<Integer> stream = numbers.stream();
        
        // Additional code to make the program more complex
        Set<String> stringSet = new HashSet<>();
        stringSet.add("apple");
        stringSet.add("banana");
        stringSet.add("apple");
        
        List<String> stringList = new ArrayList<>(stringSet);
        stringList.add("cherry");
        
        Stream<String> stringStream = stringList.stream();
        long uniqueCount = stringStream.distinct().count();
        System.out.println("Unique string count: " + uniqueCount);
        
        // Back to the original task
        /* write */ Stream<Integer> distinctStream = stream.distinct();
        
        // More unrelated complex operations
        List<Double> doubleList = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            doubleList.add(Math.sqrt(i));
        }
        
        doubleList.forEach(System.out::println);
        
        // Final read operation
        /* read */ long count = distinctStream.count();
        System.out.println("Unique number count: " + count);
    }
}