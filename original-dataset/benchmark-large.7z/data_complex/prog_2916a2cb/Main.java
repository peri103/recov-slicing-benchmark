import java.util.Optional;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        Optional<String> optional = Optional.of("Hello, World!");
        /* write */ Class<?> clazz = optional.getClass();

        // Additional code to make the program more complex
        List<Integer> numbers = new ArrayList<>();
        for (int i = 1; i <= 5; i++) {
            numbers.add(i);
        }

        Map<String, Integer> map = new HashMap<>();
        for (int i = 0; i < numbers.size(); i++) {
            map.put("Number " + i, numbers.get(i));
        }

        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

        // Simulate some unrelated calculations
        int sum = 0;
        for (int number : numbers) {
            sum += number;
        }
        System.out.println("Sum of numbers: " + sum);

        // Check if the optional value is present
        /* read */ boolean isPresent = optional.isPresent();
        System.out.println("Class: " + clazz.getName() + ", Is Present: " + isPresent);

        // More unrelated code
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < 3; i++) {
            builder.append("Iteration ").append(i).append("\n");
        }
        System.out.println(builder.toString());
    }
}