import java.util.stream.DoubleStream;
import java.util.OptionalDouble;
import java.util.List;
import java.util.ArrayList;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        DoubleStream stream = DoubleStream.of(1.0, 2.0, 3.0, 4.0, 5.0);
        /* write */ DoubleStream filteredStream = stream.filter(d -> d > 3.0);

        // Additional unrelated code to add complexity
        List<Double> additionalList = new ArrayList<>();
        for (double i = 0.5; i <= 5.0; i += 0.5) {
            additionalList.add(i);
        }

        List<Double> processedList = additionalList.stream()
                .filter(d -> d < 4.0)
                .map(d -> d * 2)
                .collect(Collectors.toList());

        System.out.println("Processed List: " + processedList);

        // More unrelated code
        double sum = processedList.stream().mapToDouble(Double::doubleValue).sum();
        System.out.println("Sum of Processed List: " + sum);

        // Some conditional logic to add complexity
        if (sum > 10) {
            System.out.println("The sum is greater than 10");
        } else {
            System.out.println("The sum is not greater than 10");
        }

        // Loop to add more complexity
        for (double value : processedList) {
            System.out.println("Value in processed list: " + value);
        }

        /* read */ OptionalDouble firstValue = filteredStream.findFirst();
        if (firstValue.isPresent()) {
            System.out.println("First value greater than 3.0 in original stream: " + firstValue.getAsDouble());
        } else {
            System.out.println("No value found");
        }
    }
}