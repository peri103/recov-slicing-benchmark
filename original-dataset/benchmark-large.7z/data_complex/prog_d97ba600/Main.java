import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Path path = Paths.get("example.txt");
        byte[] content = "Hello, World!".getBytes();
        
        try {
            /* write */ Files.write(path, content);
            
            // Adding more complexity
            List<Integer> numbers = new ArrayList<>();
            Random random = new Random();
            for (int i = 0; i < 10; i++) {
                numbers.add(random.nextInt(100));
            }
            
            int sum = 0;
            for (int number : numbers) {
                sum += number;
            }
            System.out.println("Sum of random numbers: " + sum);
            
            // Check if the file exists
            /* read */ boolean exists = Files.exists(path);
            System.out.println("File exists: " + exists);
            
            // More complex operations
            List<String> lines = Files.readAllLines(path);
            for (String line : lines) {
                System.out.println("Read line: " + line);
            }
            
            // Further manipulation of numbers
            numbers.sort(Integer::compareTo);
            System.out.println("Sorted numbers: " + numbers);
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}