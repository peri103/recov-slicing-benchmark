import java.util.WeakHashMap;
import java.util.HashMap;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        WeakHashMap<String, Integer> map = new WeakHashMap<>();
        HashMap<String, String> hashMap = new HashMap<>();
        ArrayList<Integer> arrayList = new ArrayList<>();

        // Populate the HashMap with some data
        hashMap.put("A", "Apple");
        hashMap.put("B", "Banana");
        hashMap.put("C", "Cherry");

        // Populate the ArrayList with numbers
        for (int i = 0; i < 5; i++) {
            arrayList.add(i * 5);
        }

        // Process the ArrayList
        for (Integer num : arrayList) {
            System.out.println("ArrayList contains: " + num);
        }

        // Add more data to the WeakHashMap
        map.put("tempKey", 100);
        
        /* write */ map.put("key", 42);

        // Process the HashMap
        for (String key : hashMap.keySet()) {
            System.out.println("HashMap " + key + " maps to " + hashMap.get(key));
        }

        // Some unrelated computation
        int sum = 0;
        for (int i = 0; i < arrayList.size(); i++) {
            sum += arrayList.get(i);
        }
        System.out.println("Sum of ArrayList elements: " + sum);

        // Simulate some delay or unrelated operations
        for (int i = 0; i < 1000000; i++) {
            int dummyOperation = i * 2;
        }

        /* read */ Integer value = map.get("key");
        System.out.println("Value from WeakHashMap: " + value);
    }
}