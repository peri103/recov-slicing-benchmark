import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class Main {
    public static void main(String[] args) {
        IntStream intStream = IntStream.of(1, 2, 3);
        /* write */ Stream<Integer> boxedStream = intStream.boxed();

        // Additional code to manipulate collections
        List<Integer> numbers = new ArrayList<>();
        Collections.addAll(numbers, 10, 20, 30, 40, 50);
        
        List<Integer> squaredNumbers = new ArrayList<>();
        for (Integer num : numbers) {
            squaredNumbers.add(num * num);
        }

        // Print squared numbers
        for (Integer squaredNum : squaredNumbers) {
            System.out.println("Squared: " + squaredNum);
        }

        // More operations using streams
        int maxNumber = numbers.stream().mapToInt(Integer::intValue).max().orElseThrow();
        System.out.println("Max number: " + maxNumber);

        // Continue with more unrelated operations
        List<String> names = new ArrayList<>();
        Collections.addAll(names, "Alice", "Bob", "Charlie");
        
        for (String name : names) {
            System.out.println("Name: " + name);
        }

        // Perform sorting on names
        Collections.sort(names);
        System.out.println("Sorted names: " + names);

        // Original read operation
        /* read */ Object[] array = boxedStream.toArray();
        for (Object num : array) {
            System.out.println("Original stream element: " + num);
        }
    }
}