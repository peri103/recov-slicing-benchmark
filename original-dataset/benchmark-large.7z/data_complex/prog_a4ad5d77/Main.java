import java.util.concurrent.ConcurrentSkipListSet;
import java.util.Arrays;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

public class Main {
    public static void main(String[] args) {
        ConcurrentSkipListSet<Integer> set = new ConcurrentSkipListSet<>();
        ConcurrentHashMap<Integer, String> map = new ConcurrentHashMap<>();
        ConcurrentLinkedQueue<Integer> queue = new ConcurrentLinkedQueue<>();

        /* write */ set.addAll(Arrays.asList(1, 2, 3));

        map.put(1, "One");
        map.put(2, "Two");
        map.put(3, "Three");

        queue.add(10);
        queue.add(20);
        queue.add(30);

        // Perform operations on map
        for (int i = 1; i <= 3; i++) {
            System.out.println("Map value for key " + i + ": " + map.get(i));
        }

        // Perform operations on queue
        while (!queue.isEmpty()) {
            System.out.println("Queue element: " + queue.poll());
        }

        // Additional logic
        int sum = 0;
        for (int num : set) {
            sum += num;
        }
        System.out.println("Sum of elements in set: " + sum);

        /* read */ boolean isEmpty = set.isEmpty();
        System.out.println("Is the set empty? " + isEmpty);

        // More operations on the set
        set.remove(1);
        set.add(4);
        for (int num : set) {
            System.out.println("Set element: " + num);
        }
    }
}