import java.util.concurrent.CopyOnWriteArrayList;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        CopyOnWriteArrayList<Integer> list = new CopyOnWriteArrayList<>();
        Map<String, Integer> map = new HashMap<>();
        
        // Adding elements to the map
        map.put("First", 100);
        map.put("Second", 200);
        map.put("Third", 300);

        // Iterating over the map
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }

        // Adding elements to another CopyOnWriteArrayList
        CopyOnWriteArrayList<String> stringList = new CopyOnWriteArrayList<>();
        stringList.addIfAbsent("Hello");
        stringList.addIfAbsent("World");

        // Iterating over the stringList
        for (String str : stringList) {
            System.out.println(str);
        }

        /* write */ list.addIfAbsent(1);

        // Performing some unrelated computations
        int sum = 0;
        for (int i = 0; i < 10; i++) {
            sum += i;
        }
        System.out.println("Sum of first 10 numbers: " + sum);

        // More operations on map
        if (map.containsKey("Second")) {
            int value = map.get("Second");
            System.out.println("Value for 'Second': " + value);
        }

        // More operations on stringList
        if (!stringList.contains("Java")) {
            stringList.addIfAbsent("Java");
        }

        // Performing operations on list
        if (!list.contains(2)) {
            list.addIfAbsent(2);
        }

        // More computations
        int product = 1;
        for (int i = 1; i <= 5; i++) {
            product *= i;
        }
        System.out.println("Product of first 5 numbers: " + product);

        /* read */ int value = list.get(0);
        System.out.println(value);
    }
}