import java.util.stream.Stream;
import java.util.List;
import java.util.ArrayList;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        // Original stream with duplicate elements
        Stream<String> stream = Stream.of("apple", "orange", "apple", "banana", "orange");
        
        // Additional stream manipulation for complexity
        Stream<String> upperCaseStream = stream.map(String::toUpperCase);
        
        // Collecting distinct elements into a list
        /* write */ Stream<String> distinctStream = upperCaseStream.distinct();
        
        // Unrelated code to add complexity
        List<Integer> numbers = new ArrayList<>();
        for (int i = 1; i <= 5; i++) {
            numbers.add(i * 10);
        }
        
        // Transforming numbers into their squares
        List<Integer> squaredNumbers = numbers.stream()
                                              .map(x -> x * x)
                                              .collect(Collectors.toList());
        
        // Printing squared numbers
        squaredNumbers.forEach(System.out::println);
        
        // More complex stream operations
        Stream<Integer> numberStream = numbers.stream();
        List<Integer> evenNumbers = numberStream.filter(x -> x % 2 == 0)
                                                .collect(Collectors.toList());
        
        // Printing even numbers
        evenNumbers.forEach(System.out::println);
        
        // Counting distinct elements
        /* read */ long count = distinctStream.count();
        System.out.println("Distinct count: " + count);
    }
}