import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReference;

public class Main {
    private static class MyClass {
        volatile long value;
        volatile int intValue;
    }

    public static void main(String[] args) {
        MyClass myObject = new MyClass();
        AtomicLongFieldUpdater<MyClass> longUpdater = AtomicLongFieldUpdater.newUpdater(MyClass.class, "value");
        AtomicIntegerFieldUpdater<MyClass> intUpdater = AtomicIntegerFieldUpdater.newUpdater(MyClass.class, "intValue");

        AtomicReference<String> atomicString = new AtomicReference<>("Initial");

        /* write */ longUpdater.set(myObject, 42);

        // Perform some unrelated operations
        for (int i = 0; i < 5; i++) {
            intUpdater.incrementAndGet(myObject);
            atomicString.set("Iteration " + i);
            System.out.println("Atomic String: " + atomicString.get() + ", Int Value: " + intUpdater.get(myObject));
        }

        // More unrelated operations
        String[] messages = {"Hello", "World", "This", "Is", "Java"};
        for (String message : messages) {
            atomicString.set(message);
            System.out.println("Current Message: " + atomicString.get());
        }

        /* read */ long value = longUpdater.get(myObject);

        System.out.println("Final Long Value: " + value);
    }
}