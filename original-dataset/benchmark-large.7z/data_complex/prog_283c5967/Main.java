import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        Path sourcePath = Paths.get("source.txt");
        Path targetPath = Paths.get("target.txt");

        try {
            // Ensure the source file exists for the move operation
            if (!Files.exists(sourcePath)) {
                Files.createFile(sourcePath);
                Files.write(sourcePath, "Hello, World!".getBytes());
            }

            /* write */ Files.move(sourcePath, targetPath);

            // Additional complex code
            ArrayList<Integer> numberList = new ArrayList<>();
            for (int i = 0; i < 10; i++) {
                numberList.add(i * 2);
            }

            Map<String, Integer> wordCount = new HashMap<>();
            wordCount.put("hello", 1);
            wordCount.put("world", 2);
            wordCount.put("java", 3);

            for (Map.Entry<String, Integer> entry : wordCount.entrySet()) {
                System.out.println("Word: " + entry.getKey() + ", Count: " + entry.getValue());
            }

            int sum = 0;
            for (int number : numberList) {
                sum += number;
            }
            System.out.println("Sum of numbers: " + sum);

            /* read */ List<String> lines = Files.readAllLines(targetPath);
            for (String line : lines) {
                System.out.println(line);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}