import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        try {
            // Create a directory
            Path path = Paths.get("exampleDir");
            /* write */ Files.createDirectory(path);
            
            // Additional code to add complexity
            ArrayList<String> fileList = new ArrayList<>();
            fileList.add("file1.txt");
            fileList.add("file2.txt");
            fileList.add("file3.txt");

            for (String fileName : fileList) {
                Path filePath = Paths.get("exampleDir", fileName);
                Files.createFile(filePath);
                System.out.println("Created file: " + filePath);
            }

            // Perform some unrelated operations
            ArrayList<Integer> numbers = new ArrayList<>();
            for (int i = 0; i < 10; i++) {
                numbers.add(i * i);
            }

            for (int number : numbers) {
                System.out.println("Square: " + number);
            }

            // Check if the directory exists
            /* read */ boolean exists = Files.exists(path);
            System.out.println("Directory exists: " + exists);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}