import java.util.concurrent.LinkedTransferQueue;
import java.util.concurrent.TransferQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.List;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        LinkedTransferQueue<Integer> queue = new LinkedTransferQueue<>();
        TransferQueue<String> stringQueue = new LinkedTransferQueue<>();
        LinkedBlockingQueue<Double> doubleQueue = new LinkedBlockingQueue<>();
        List<String> stringList = new ArrayList<>();

        // Initialize the queue with some elements
        queue.add(1);
        queue.add(2);
        queue.add(3);

        // Add some strings to the stringQueue
        stringQueue.add("A");
        stringQueue.add("B");
        stringQueue.add("C");

        // Add some doubles to the doubleQueue
        doubleQueue.add(1.1);
        doubleQueue.add(2.2);
        doubleQueue.add(3.3);

        // Add some strings to the stringList
        stringList.add("X");
        stringList.add("Y");
        stringList.add("Z");

        /* write */ queue.clear();

        // Process the stringQueue
        while (!stringQueue.isEmpty()) {
            try {
                String str = stringQueue.take();
                System.out.println("Processed: " + str);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Process the doubleQueue
        for (Double d : doubleQueue) {
            System.out.println("Double value: " + d);
        }

        // Process the stringList
        for (String s : stringList) {
            System.out.println("String value: " + s);
        }

        /* read */ boolean isEmpty = queue.isEmpty();
        System.out.println(isEmpty);
    }
}