import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {
    public static void main(String[] args) {
        // Original write-read pair
        Stream<Integer> stream = Stream.of(1, 2, 3, 4, 5);
        
        /* write */ List<Integer> list = stream.collect(Collectors.toList());
        
        // Additional code for complexity
        List<String> stringList = new ArrayList<>();
        stringList.add("Hello");
        stringList.add("World");
        
        Stream<String> stringStream = stringList.stream();
        List<String> collectedStrings = stringStream.collect(Collectors.toList());
        
        Stream<Integer> anotherStream = Stream.of(10, 20, 30, 40, 50);
        List<Integer> anotherList = anotherStream.collect(Collectors.toList());
        
        for (Integer number : anotherList) {
            System.out.println("Number: " + number);
        }
        
        // Perform some operations on the collectedStrings list
        for (String str : collectedStrings) {
            System.out.println("String: " + str);
        }
        
        // Original read operation
        Stream<Integer> newStream = list.stream();
        
        /* read */ long count = newStream.count();
        
        System.out.println("Count of elements in the original list: " + count);
        
        // Additional operations
        List<Integer> finalList = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            finalList.add(list.get(i) * 2);
        }
        
        for (Integer num : finalList) {
            System.out.println("Doubled Number: " + num);
        }
    }
}