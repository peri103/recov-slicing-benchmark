import java.util.stream.LongStream;
import java.util.stream.Stream;
import java.util.List;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        LongStream longStream = LongStream.of(1L, 2L, 3L);
        
        // Additional code using a different API
        List<Integer> intList = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            intList.add(i * 2);
        }
        
        // More complex operations on intList
        int sum = intList.stream().mapToInt(Integer::intValue).sum();
        System.out.println("Sum of intList: " + sum);
        
        /* write */ Stream<Long> boxedStream = longStream.boxed();
        
        // Perform other operations before reading
        intList.add(10);
        intList.removeIf(n -> n % 2 == 0);
        System.out.println("Filtered intList: " + intList);
        
        /* read */ long[] array = boxedStream.mapToLong(Long::longValue).toArray();
        
        // Additional logic after reading
        for (long value : array) {
            System.out.println("Value from array: " + value);
        }
        
        // Final operations
        intList.forEach(System.out::println);
    }
}