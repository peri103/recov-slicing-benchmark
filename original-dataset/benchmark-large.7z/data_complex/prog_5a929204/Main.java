import java.util.concurrent.LinkedBlockingDeque;
import java.util.Arrays;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        LinkedBlockingDeque<Integer> deque = new LinkedBlockingDeque<>();
        LinkedBlockingQueue<String> queue = new LinkedBlockingQueue<>();
        HashMap<Integer, String> map = new HashMap<>();

        // Adding elements to the map
        map.put(1, "One");
        map.put(2, "Two");
        map.put(3, "Three");

        // Adding elements to the queue
        queue.add("First");
        queue.add("Second");
        queue.add("Third");

        // Performing some operations on the queue
        String firstElement = queue.poll();
        System.out.println("Polled from queue: " + firstElement);

        // Iterating over the map
        for (Map.Entry<Integer, String> entry : map.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }

        // Adding elements to the deque
        /* write */ deque.addAll(Arrays.asList(1, 2, 3, 4, 5));

        // More operations
        if (!deque.isEmpty()) {
            System.out.println("Deque is not empty.");
        }

        // Adding more elements to the queue
        queue.add("Fourth");
        queue.add("Fifth");

        // Checking the size of the deque
        /* read */ int size = deque.size();
        System.out.println("Size of deque: " + size);

        // Further operations on the queue
        while (!queue.isEmpty()) {
            System.out.println("Queue element: " + queue.poll());
        }

        // Adding more elements to the map
        map.put(4, "Four");
        map.put(5, "Five");

        // Final iteration over the map
        for (Map.Entry<Integer, String> entry : map.entrySet()) {
            System.out.println("Final Key: " + entry.getKey() + ", Final Value: " + entry.getValue());
        }
    }
}