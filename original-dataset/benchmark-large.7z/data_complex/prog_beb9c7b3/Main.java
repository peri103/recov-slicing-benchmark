import java.util.stream.Stream;
import java.util.List;
import java.util.ArrayList;
import java.util.stream.Collectors;
import java.util.Optional;

public class Main {
    public static void main(String[] args) {
        Stream<Integer> stream = Stream.of(1, 2, 3, 4, 5);
        
        /* write */ int sum = stream.reduce(0, (accumulator, element) -> accumulator + element);
        
        // Additional unrelated code to increase complexity
        List<String> names = new ArrayList<>();
        names.add("Alice");
        names.add("Bob");
        names.add("Charlie");
        
        // Using another Stream API function
        Optional<String> longestName = names.stream()
                                            .reduce((name1, name2) -> name1.length() > name2.length() ? name1 : name2);
        
        longestName.ifPresent(name -> System.out.println("Longest name: " + name));
        
        // Re-create the stream as streams can only be consumed once
        Stream<Integer> newStream = Stream.of(1, 2, 3, 4, 5);
        
        // Additional unrelated code
        List<Double> squaredNumbers = newStream.map(num -> Math.pow(num, 2))
                                               .collect(Collectors.toList());
        
        squaredNumbers.forEach(num -> System.out.println("Squared: " + num));
        
        // Re-create the stream again for the read operation
        Stream<Integer> finalStream = Stream.of(1, 2, 3, 4, 5);
        
        /* read */ List<Integer> list = finalStream.collect(Collectors.toList());
        
        System.out.println("Sum: " + sum);
        System.out.println("List: " + list);
    }
}