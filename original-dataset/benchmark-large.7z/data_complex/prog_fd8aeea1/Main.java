import java.util.PriorityQueue;
import java.util.Stack;
import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {
        PriorityQueue<Integer> queue = new PriorityQueue<>();
        Stack<Integer> stack = new Stack<>();
        LinkedList<Integer> linkedList = new LinkedList<>();
        
        // Adding elements to the stack
        stack.push(100);
        stack.push(200);
        stack.push(300);
        
        // Adding elements to the linked list
        linkedList.add(10);
        linkedList.add(20);
        linkedList.add(30);
        
        // Perform operations on stack
        while (!stack.isEmpty()) {
            System.out.println("Popped from stack: " + stack.pop());
        }
        
        // Perform operations on linked list
        for (int i = 0; i < linkedList.size(); i++) {
            System.out.println("Element in linked list: " + linkedList.get(i));
        }
        
        /* write */ queue.offer(42);
        
        // Adding more elements to the queue
        queue.offer(15);
        queue.offer(25);
        queue.offer(35);
        
        // Perform operations on queue
        while (!queue.isEmpty()) {
            int value = queue.poll();
            System.out.println("Polled from queue: " + value);
        }
        
        /* read */ int value = queue.poll();
        System.out.println("First polled value: " + value);
    }
}