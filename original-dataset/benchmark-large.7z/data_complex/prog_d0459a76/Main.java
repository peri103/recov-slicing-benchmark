import java.util.TreeMap;
import java.util.HashMap;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        TreeMap<String, Integer> map = new TreeMap<>();
        HashMap<String, String> hashMap = new HashMap<>();
        ArrayList<Integer> arrayList = new ArrayList<>();
        
        // Adding elements to the HashMap
        hashMap.put("name", "Alice");
        hashMap.put("city", "Wonderland");
        
        // Adding elements to the ArrayList
        for (int i = 0; i < 5; i++) {
            arrayList.add(i * 10);
        }
        
        // Accessing elements from the HashMap
        String name = hashMap.get("name");
        System.out.println("Name from HashMap: " + name);
        
        // Accessing elements from the ArrayList
        int listValue = arrayList.get(2);
        System.out.println("Value from ArrayList: " + listValue);
        
        // Performing operations on TreeMap
        /* write */ map.put("key", 100);
        
        // More complex operations
        for (int i = 0; i < arrayList.size(); i++) {
            map.put("key" + i, arrayList.get(i));
        }
        
        // Accessing elements from the TreeMap
        int sum = 0;
        for (int i = 0; i < arrayList.size(); i++) {
            sum += map.get("key" + i);
        }
        System.out.println("Sum of values in TreeMap: " + sum);
        
        /* read */ Integer value = map.get("key");
        System.out.println("Value from TreeMap: " + value);
        
        // Additional operations to increase complexity
        String city = hashMap.get("city");
        System.out.println("City from HashMap: " + city);
        
        for (Integer val : arrayList) {
            System.out.println("ArrayList value: " + val);
        }
    }
}