import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        SynchronousQueue<Integer> queue = new SynchronousQueue<>();
        ExecutorService executor = Executors.newFixedThreadPool(2);
        List<Integer> results = new ArrayList<>();

        // Start a producer thread
        executor.submit(() -> {
            try {
                /* write */ queue.put(42);
                System.out.println("Value 42 put into the queue");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        // Start a consumer thread
        executor.submit(() -> {
            try {
                /* read */ int value = queue.take();
                results.add(value);
                System.out.println("Value " + value + " taken from the queue");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        // Additional unrelated computations
        List<String> names = new ArrayList<>();
        names.add("Alice");
        names.add("Bob");
        names.add("Charlie");

        names.forEach(name -> System.out.println("Hello, " + name));

        // Wait for the threads to finish
        executor.shutdown();
        try {
            if (!executor.awaitTermination(1, TimeUnit.SECONDS)) {
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
        }

        // Print results
        System.out.println("Results: " + results);
    }
}