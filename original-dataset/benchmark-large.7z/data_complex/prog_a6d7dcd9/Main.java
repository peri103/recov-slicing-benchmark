import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class Main {
    public static void main(String[] args) {
        DelayQueue<DelayedElement> queue = new DelayQueue<>();
        PriorityBlockingQueue<DelayedElement> priorityQueue = new PriorityBlockingQueue<>();
        LinkedBlockingQueue<DelayedElement> linkedQueue = new LinkedBlockingQueue<>();

        // Add a dummy element to the queue
        queue.add(new DelayedElement(1000));
        priorityQueue.add(new DelayedElement(2000));
        linkedQueue.add(new DelayedElement(3000));

        /* write */ queue.clear();

        // Simulate some processing
        for (int i = 0; i < 5; i++) {
            DelayedElement element = new DelayedElement(i * 1000);
            priorityQueue.add(element);
            linkedQueue.add(element);
        }

        // Process elements from priorityQueue
        while (!priorityQueue.isEmpty()) {
            try {
                DelayedElement element = priorityQueue.take();
                System.out.println("Processed from priorityQueue: " + element);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        // Process elements from linkedQueue
        while (!linkedQueue.isEmpty()) {
            try {
                DelayedElement element = linkedQueue.take();
                System.out.println("Processed from linkedQueue: " + element);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        /* read */ boolean isEmpty = queue.isEmpty();
        System.out.println(isEmpty); // This should print true

        // Add more complexity with additional logic
        for (int i = 0; i < 3; i++) {
            DelayedElement element = new DelayedElement(i * 500);
            queue.add(element);
        }

        while (!queue.isEmpty()) {
            try {
                DelayedElement element = queue.take();
                System.out.println("Processed from queue: " + element);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private static class DelayedElement implements Delayed {
        private final long delayTime;
        private final long expireTime;

        public DelayedElement(long delay) {
            this.delayTime = delay;
            this.expireTime = System.currentTimeMillis() + delay;
        }

        @Override
        public long getDelay(TimeUnit unit) {
            long diff = expireTime - System.currentTimeMillis();
            return unit.convert(diff, TimeUnit.MILLISECONDS);
        }

        @Override
        public int compareTo(Delayed o) {
            if (this.expireTime < ((DelayedElement) o).expireTime) {
                return -1;
            }
            if (this.expireTime > ((DelayedElement) o).expireTime) {
                return 1;
            }
            return 0;
        }

        @Override
        public String toString() {
            return "DelayedElement{" +
                    "delayTime=" + delayTime +
                    ", expireTime=" + expireTime +
                    '}';
        }
    }
}