import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;
import java.util.ArrayList;
import java.util.concurrent.LinkedBlockingQueue;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        DelayQueue<DelayedElement> delayQueue = new DelayQueue<>();
        LinkedBlockingQueue<String> linkedQueue = new LinkedBlockingQueue<>();
        ArrayList<Integer> numbers = new ArrayList<>();

        DelayedElement element = new DelayedElement("Hello, World!", 5, TimeUnit.SECONDS);
        
        // Adding elements to the linked queue
        linkedQueue.offer("First");
        linkedQueue.offer("Second");
        
        // Adding numbers to the ArrayList
        for (int i = 0; i < 5; i++) {
            numbers.add(i * 10);
        }

        /* write */ delayQueue.put(element);

        // Process elements in the linked queue
        while (!linkedQueue.isEmpty()) {
            System.out.println("Processing: " + linkedQueue.poll());
        }

        // Perform some computations with numbers
        int sum = 0;
        for (int num : numbers) {
            sum += num;
        }
        System.out.println("Sum of numbers: " + sum);

        // More complex logic can be added here
        for (int i = 0; i < numbers.size(); i++) {
            numbers.set(i, numbers.get(i) + 5);
        }

        // Simulate waiting for the delay to expire
        Thread.sleep(6000);

        /* read */ DelayedElement retrievedElement = delayQueue.take();
        
        System.out.println(retrievedElement.getMessage());

        // Print modified numbers
        for (int num : numbers) {
            System.out.println("Modified number: " + num);
        }
    }
}

class DelayedElement implements Delayed {
    private final String message;
    private final long delayTime;
    private final long creationTime;

    public DelayedElement(String message, long delay, TimeUnit unit) {
        this.message = message;
        this.delayTime = System.currentTimeMillis() + unit.toMillis(delay);
        this.creationTime = System.currentTimeMillis();
    }

    public String getMessage() {
        return message;
    }

    @Override
    public long getDelay(TimeUnit unit) {
        return unit.convert(delayTime - System.currentTimeMillis(), TimeUnit.MILLISECONDS);
    }

    @Override
    public int compareTo(Delayed o) {
        if (this.delayTime < ((DelayedElement) o).delayTime) {
            return -1;
        }
        if (this.delayTime > ((DelayedElement) o).delayTime) {
            return 1;
        }
        return 0;
    }
}