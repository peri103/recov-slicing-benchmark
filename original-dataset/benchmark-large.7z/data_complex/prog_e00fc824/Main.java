import java.util.concurrent.LinkedTransferQueue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Original queue
        LinkedTransferQueue<Integer> queue = new LinkedTransferQueue<>();
        queue.add(1);
        queue.add(2);
        queue.add(3);

        // Additional queue for complexity
        ConcurrentLinkedQueue<Integer> anotherQueue = new ConcurrentLinkedQueue<>();
        anotherQueue.add(10);
        anotherQueue.add(20);

        // ArrayList for additional operations
        ArrayList<Integer> list = new ArrayList<>();
        list.add(100);
        list.add(200);

        // Perform a write operation on the original queue
        /* write */ Object[] array = queue.toArray();

        // Manipulate anotherQueue
        anotherQueue.poll();
        anotherQueue.offer(30);

        // Perform operations on the list
        for (Integer num : anotherQueue) {
            list.add(num);
        }

        // Perform a read operation on the original queue
        /* read */ int size = queue.size();

        // Output results
        System.out.println("Array length: " + array.length);
        System.out.println("Queue size: " + size);

        // Additional outputs
        System.out.println("anotherQueue contents: " + anotherQueue);
        System.out.println("List contents: " + list);
    }
}