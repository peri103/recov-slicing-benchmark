import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;
import java.util.stream.Stream;
import java.util.List;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        try {
            Path directory = Paths.get("example_directory");
            /* write */ Stream<Path> pathStream = Files.list(directory);

            // Additional code to make the program more complex
            List<Path> paths = new ArrayList<>();
            pathStream.forEach(paths::add);

            // Process each path: print the name and check if it's a directory
            for (Path path : paths) {
                System.out.println("Path: " + path.getFileName());
                if (Files.isDirectory(path)) {
                    System.out.println(path.getFileName() + " is a directory.");
                } else {
                    System.out.println(path.getFileName() + " is a file.");
                }
            }

            // Sort paths by name
            paths.sort((p1, p2) -> p1.getFileName().toString().compareTo(p2.getFileName().toString()));

            // Print sorted paths
            System.out.println("Sorted paths:");
            for (Path path : paths) {
                System.out.println(path.getFileName());
            }

            // Calculate total size of files (ignoring directories)
            long totalSize = 0;
            for (Path path : paths) {
                if (!Files.isDirectory(path)) {
                    totalSize += Files.size(path);
                }
            }
            System.out.println("Total size of files: " + totalSize + " bytes");

            // Original read method
            /* read */ long count = pathStream.count();
            System.out.println("Number of files/directories: " + count);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}