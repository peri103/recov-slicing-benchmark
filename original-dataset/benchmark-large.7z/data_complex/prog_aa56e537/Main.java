import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        PriorityBlockingQueue<Integer> queue = new PriorityBlockingQueue<>();
        queue.add(1); // Adding an element to ensure the queue is not initially empty

        ConcurrentLinkedQueue<String> concurrentQueue = new ConcurrentLinkedQueue<>();
        concurrentQueue.add("Hello");
        concurrentQueue.add("World");
        
        ArrayList<Integer> arrayList = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            arrayList.add(i);
        }

        /* write */ queue.clear();

        for (String str : concurrentQueue) {
            System.out.println(str);
        }

        int sum = 0;
        for (int num : arrayList) {
            sum += num;
        }
        System.out.println("Sum of ArrayList elements: " + sum);

        /* read */ boolean isEmpty = queue.isEmpty();
        System.out.println("Is the PriorityBlockingQueue empty? " + isEmpty);

        arrayList.add(sum);
        for (int num : arrayList) {
            System.out.println("ArrayList element: " + num);
        }
    }
}