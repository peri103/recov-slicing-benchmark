import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.stream.Stream;

public class Main {
    public static void main(String[] args) {
        try {
            // Create a temporary file to write and read
            Path tempFile = Files.createTempFile("example", ".txt");

            // Write some content to the file
            String content = "Hello, World!";
            Files.writeString(tempFile, content, StandardOpenOption.WRITE);

            // Perform some unrelated file operations
            List<String> lines = new ArrayList<>();
            lines.add("First line");
            lines.add("Second line");
            Files.write(tempFile, lines, StandardOpenOption.APPEND);

            // Create another temporary file
            Path anotherFile = Files.createTempFile("anotherExample", ".txt");
            Files.writeString(anotherFile, "Another content", StandardOpenOption.WRITE);

            // Read the content of the file
            /* read */ String fileContent = Files.readString(tempFile);
            System.out.println("Read content: " + fileContent);

            // Use a stream to read lines from the file
            try (Stream<String> stream = Files.lines(tempFile)) {
                stream.forEach(System.out::println);
            }

            // Get the size of the file
            /* write */ long fileSize = Files.size(tempFile);
            System.out.println("File size: " + fileSize);

            // Get the size of another file
            long anotherFileSize = Files.size(anotherFile);
            System.out.println("Another file size: " + anotherFileSize);

            // Perform some operations with a list
            List<Integer> numbers = new ArrayList<>();
            for (int i = 0; i < 10; i++) {
                numbers.add(i * i);
            }

            numbers.forEach(System.out::println);

            // Clean up the temporary files
            Files.delete(tempFile);
            Files.delete(anotherFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}