import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        CopyOnWriteArraySet<Integer> set = new CopyOnWriteArraySet<>();
        set.add(1);
        set.add(2);
        set.add(3);

        CopyOnWriteArrayList<Integer> list = new CopyOnWriteArrayList<>();
        list.add(4);
        list.add(5);

        HashMap<Integer, String> map = new HashMap<>();
        map.put(1, "One");
        map.put(2, "Two");
        map.put(3, "Three");

        /* write */ set.remove(2);

        for (Integer number : list) {
            if (map.containsKey(number)) {
                System.out.println("Map contains: " + number);
            } else {
                System.out.println("Map does not contain: " + number);
            }
        }

        for (Integer number : set) {
            System.out.println("Set contains: " + number);
        }

        /* read */ boolean contains = set.contains(2);
        System.out.println(contains); // This should print false as 2 was removed

        for (Integer number : set) {
            list.add(number);
        }

        for (int i = 0; i < list.size(); i++) {
            System.out.println("List element: " + list.get(i));
        }
    }
}