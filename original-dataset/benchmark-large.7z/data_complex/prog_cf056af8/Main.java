import java.util.concurrent.atomic.AtomicLong;
import java.util.ArrayList;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        AtomicLong atomicLong = new AtomicLong();
        /* write */ atomicLong.set(12345L);

        // Simulate some complex operations
        ArrayList<Integer> numbers = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            numbers.add(i * 2);
        }
        
        HashMap<String, Integer> map = new HashMap<>();
        map.put("one", 1);
        map.put("two", 2);
        map.put("three", 3);
        
        // Perform operations on the map
        if (map.containsKey("two")) {
            int valueFromMap = map.get("two");
            System.out.println("Value from map: " + valueFromMap);
        }
        
        // Iterate and print numbers list
        for (int num : numbers) {
            System.out.println("Number: " + num);
        }
        
        // Additional operations
        long sum = 0;
        for (int num : numbers) {
            sum += num;
        }
        System.out.println("Sum of numbers: " + sum);

        /* read */ long value = atomicLong.get();
        System.out.println("AtomicLong value: " + value);

        // More unrelated operations
        ArrayList<String> words = new ArrayList<>();
        words.add("Hello");
        words.add("World");
        
        for (String word : words) {
            System.out.println("Word: " + word);
        }
    }
}