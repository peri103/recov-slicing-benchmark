import java.util.concurrent.ConcurrentSkipListSet;
import java.util.HashMap;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ConcurrentSkipListSet<Integer> set = new ConcurrentSkipListSet<>();
        HashMap<String, Integer> map = new HashMap<>();
        ArrayList<String> list = new ArrayList<>();

        // Adding elements to the map
        map.put("one", 1);
        map.put("two", 2);

        // Adding elements to the list
        list.add("hello");
        list.add("world");

        /* write */ set.add(42);

        // Iterating over the map
        for (String key : map.keySet()) {
            System.out.println("Key: " + key + ", Value: " + map.get(key));
        }

        // Iterating over the list
        for (String item : list) {
            System.out.println("List item: " + item);
        }

        // Perform some calculations
        int sum = 0;
        for (int i = 0; i < 10; i++) {
            sum += i;
        }
        System.out.println("Sum of numbers from 0 to 9: " + sum);

        /* read */ boolean exists = set.contains(42);
        System.out.println("Does the set contain 42? " + exists);

        // More complex operations
        ArrayList<Integer> numbers = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            numbers.add(i * i);
        }

        for (int number : numbers) {
            System.out.println("Square: " + number);
        }

        // Checking map values
        if (map.containsKey("one")) {
            System.out.println("Map contains key 'one' with value: " + map.get("one"));
        }
    }
}