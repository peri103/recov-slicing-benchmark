import java.util.concurrent.LinkedBlockingQueue;
import java.util.Stack;
import java.util.PriorityQueue;

public class Main {
    public static void main(String[] args) {
        LinkedBlockingQueue<Integer> queue = new LinkedBlockingQueue<>();
        Stack<Integer> stack = new Stack<>();
        PriorityQueue<Integer> priorityQueue = new PriorityQueue<>();

        // Add elements to the stack
        stack.push(10);
        stack.push(20);
        stack.push(30);

        // Process elements from the stack
        while (!stack.isEmpty()) {
            int element = stack.pop();
            System.out.println("Popped from stack: " + element);

            // Add elements to the priority queue
            priorityQueue.add(element * 2);
        }

        // Process elements from the priority queue
        while (!priorityQueue.isEmpty()) {
            int element = priorityQueue.poll();
            System.out.println("Polled from priority queue: " + element);

            // Add elements to the queue
            try {
                /* write */ queue.put(element + 5);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("Failed to write to queue: " + e.getMessage());
            }
        }

        // Simulate some unrelated operations
        int sum = 0;
        for (int i = 1; i <= 5; i++) {
            sum += i;
        }
        System.out.println("Sum of first 5 natural numbers: " + sum);

        // Perform additional operations on the queue
        if (!queue.isEmpty()) {
            /* read */ Integer value = queue.peek();
            System.out.println("Peeked from queue: " + value);
        }

        // More unrelated logic
        int product = 1;
        for (int i = 1; i <= 3; i++) {
            product *= i;
        }
        System.out.println("Product of first 3 natural numbers: " + product);
    }
}