import java.util.stream.Stream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        // Create a stream and limit its size
        Stream<Integer> stream = Stream.of(1, 2, 3, 4, 5);
        /* write */ Stream<Integer> limitedStream = stream.limit(3);

        // Additional code to demonstrate complexity
        List<String> names = Arrays.asList("Alice", "Bob", "Charlie", "David");
        Map<String, Integer> nameLengthMap = new HashMap<>();

        for (String name : names) {
            nameLengthMap.put(name, name.length());
        }

        // Process the map to find names with length greater than 3
        List<String> filteredNames = nameLengthMap.entrySet().stream()
                .filter(entry -> entry.getValue() > 3)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());

        // Print the filtered names
        System.out.println("Names with length greater than 3: " + filteredNames);

        // More unrelated code
        int sum = 0;
        for (int i = 1; i <= 10; i++) {
            sum += i;
        }
        System.out.println("Sum of numbers from 1 to 10 is: " + sum);

        // Execute the read operation on the limited stream
        /* read */ Object[] array = limitedStream.toArray();
        System.out.println("Limited stream to array: " + Arrays.toString(array));
    }
}