import java.util.concurrent.atomic.DoubleAdder;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        DoubleAdder adder = new DoubleAdder();

        // Initially add some values to the adder
        adder.add(10.5);
        adder.add(5.5);

        // Create an AtomicInteger and perform some operations
        AtomicInteger atomicInt = new AtomicInteger(100);
        atomicInt.incrementAndGet();
        atomicInt.addAndGet(50);

        // Create an ArrayList and perform operations
        ArrayList<Integer> list = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            list.add(i * 10);
        }

        // Reset the adder
        /* write */ adder.reset();

        // Perform operations on ArrayList
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }

        // Further operations on AtomicInteger
        atomicInt.decrementAndGet();
        int atomicResult = atomicInt.get();
        System.out.println("Atomic Integer Value: " + atomicResult);

        // Read the sum after reset
        /* read */ double sum = adder.sum();
        System.out.println("Sum after reset: " + sum); // This should print 0.0 since the adder was reset
    }
}