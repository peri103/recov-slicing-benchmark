import java.util.stream.Stream;
import java.util.List;
import java.util.Arrays;
import java.util.stream.Collectors;
import java.util.function.Predicate;

public class Main {
    public static void main(String[] args) {
        // Original write-read pair
        Stream<Integer> stream = Stream.of(1, 2, 3, 4, 5);
        /* write */ Stream<Integer> limitedStream = stream.limit(3);

        // Additional code complexity
        Stream<String> stringStream = Stream.of("apple", "banana", "cherry", "date", "elderberry");
        Predicate<String> startsWithAorB = s -> s.startsWith("a") || s.startsWith("b");
        Stream<String> filteredStream = stringStream.filter(startsWithAorB);
        List<String> filteredList = filteredStream.collect(Collectors.toList());
        System.out.println("Filtered List: " + filteredList);

        // More code complexity
        int sum = Stream.of(10, 20, 30, 40).reduce(0, Integer::sum);
        System.out.println("Sum of numbers: " + sum);

        // Original read operation
        /* read */ List<Integer> result = limitedStream.collect(Collectors.toList());
        System.out.println("Limited Stream Result: " + result);

        // Additional unrelated code
        Stream<Double> doubleStream = Stream.of(1.1, 2.2, 3.3, 4.4);
        double average = doubleStream.mapToDouble(Double::doubleValue).average().orElse(0.0);
        System.out.println("Average of doubles: " + average);
    }
}