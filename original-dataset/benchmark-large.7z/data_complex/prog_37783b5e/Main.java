import java.util.TreeMap;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        TreeMap<Integer, String> treeMap = new TreeMap<>();
        HashMap<Integer, String> hashMap = new HashMap<>();
        
        // Using HashMap to store some values
        for (int i = 0; i < 5; i++) {
            hashMap.put(i, "Value " + i);
        }
        
        // Iterating over HashMap and printing its values
        for (Map.Entry<Integer, String> entry : hashMap.entrySet()) {
            System.out.println("HashMap Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }
        
        /* write */ treeMap.put(1, "Hello, World!");

        // Performing some operations with TreeMap
        treeMap.put(2, "Another Value");
        treeMap.put(3, "Yet Another Value");
        
        // Finding the first entry
        Map.Entry<Integer, String> firstEntry = treeMap.firstEntry();
        System.out.println("First Entry in TreeMap: Key = " + firstEntry.getKey() + ", Value = " + firstEntry.getValue());

        // Checking if a key exists
        if (treeMap.containsKey(2)) {
            System.out.println("TreeMap contains key 2");
        }
        
        // Removing an entry
        treeMap.remove(3);
        
        /* read */ String value = treeMap.get(1);
        System.out.println("Read from TreeMap: " + value);
        
        // Printing all values in TreeMap
        for (Map.Entry<Integer, String> entry : treeMap.entrySet()) {
            System.out.println("TreeMap Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }
    }
}