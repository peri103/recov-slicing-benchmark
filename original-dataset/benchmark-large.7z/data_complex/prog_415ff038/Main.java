import java.util.concurrent.ConcurrentHashMap;
import java.util.ArrayList;
import java.util.HashSet;

public class Main {
    public static void main(String[] args) {
        // Initialize a ConcurrentHashMap to store key-value pairs
        ConcurrentHashMap<String, Integer> map = new ConcurrentHashMap<>();
        
        // Initialize an ArrayList to store some integers
        ArrayList<Integer> list = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            list.add(i * 10);
        }
        
        // Add the sum of the list to the map
        int sum = 0;
        for (int num : list) {
            sum += num;
        }
        /* write */ map.put("key", sum);
        
        // Initialize a HashSet to store unique strings
        HashSet<String> set = new HashSet<>();
        set.add("apple");
        set.add("banana");
        set.add("cherry");
        
        // Perform some operations on the set
        if (set.contains("banana")) {
            set.remove("banana");
        }
        
        // Print all elements in the set
        for (String fruit : set) {
            System.out.println(fruit);
        }

        // Calculate and print the average value from the list
        double average = sum / (double) list.size();
        System.out.println("Average: " + average);
        
        // Read the value from the map
        /* read */ Integer value = map.get("key");
        System.out.println("Value from map: " + value);
    }
}