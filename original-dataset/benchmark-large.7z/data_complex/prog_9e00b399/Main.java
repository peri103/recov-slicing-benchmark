import java.util.stream.DoubleStream;
import java.util.OptionalDouble;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        DoubleStream doubleStream = DoubleStream.of(1.0, 2.0, 3.0, 4.0, 5.0);
        
        // Additional unrelated code for complexity
        List<Double> additionalList = new ArrayList<>();
        for (double i = 6.0; i <= 10.0; i++) {
            additionalList.add(i);
        }
        
        /* write */ DoubleStream boxedStream = doubleStream.boxed().mapToDouble(Double::doubleValue);
        
        // More unrelated code to increase complexity
        OptionalDouble optionalMax = additionalList.stream().mapToDouble(Double::doubleValue).max();
        if (optionalMax.isPresent()) {
            System.out.println("Max value in additionalList: " + optionalMax.getAsDouble());
        }
        
        // Processing additionalList
        double additionalSum = additionalList.stream().mapToDouble(Double::doubleValue).sum();
        System.out.println("Sum of additionalList: " + additionalSum);
        
        // More unrelated code
        double average = additionalList.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
        System.out.println("Average of additionalList: " + average);
        
        /* read */ double sum = boxedStream.sum();
        
        System.out.println("Sum of boxedStream: " + sum);
    }
}