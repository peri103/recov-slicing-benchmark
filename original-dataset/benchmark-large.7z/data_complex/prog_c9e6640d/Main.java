import java.util.stream.DoubleStream;
import java.util.stream.IntStream;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Original DoubleStream operations
        DoubleStream stream = DoubleStream.of(1.0, 2.0, 3.0);
        /* write */ DoubleStream mappedStream = stream.map(x -> x * 2);

        // Additional IntStream operations
        IntStream intStream = IntStream.range(1, 5);
        IntStream squaredStream = intStream.map(x -> x * x);
        int sumOfSquares = squaredStream.sum();
        System.out.println("Sum of squares: " + sumOfSquares);

        // Unrelated ArrayList operations
        List<String> stringList = new ArrayList<>();
        stringList.add("Hello");
        stringList.add("World");
        for (String s : stringList) {
            System.out.println(s);
        }

        // Perform some calculations
        double result = Math.pow(2, 3) + Math.sqrt(16);
        System.out.println("Result of calculations: " + result);

        // Continue with the original DoubleStream
        /* read */ double sum = mappedStream.sum();
        System.out.println("Sum of mapped stream: " + sum);

        // Additional operations with ArrayList
        List<Integer> numbers = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            numbers.add(i * 3);
        }
        for (int num : numbers) {
            if (num % 2 == 0) {
                System.out.println("Even number: " + num);
            }
        }
    }
}