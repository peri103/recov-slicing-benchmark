import java.util.concurrent.CopyOnWriteArrayList;
import java.util.HashMap;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        CopyOnWriteArrayList<Integer> list = new CopyOnWriteArrayList<>();
        list.add(1);
        list.add(2);
        list.add(3);

        HashMap<String, Integer> map = new HashMap<>();
        map.put("First", 10);
        map.put("Second", 20);
        map.put("Third", 30);

        List<Integer> anotherList = new CopyOnWriteArrayList<>();
        for (int i = 0; i < 5; i++) {
            anotherList.add(i * 5);
        }

        for (Integer value : anotherList) {
            System.out.println("Another list value: " + value);
        }

        int sum = 0;
        for (String key : map.keySet()) {
            sum += map.get(key);
        }
        System.out.println("Sum of map values: " + sum);

        /* write */ list.remove(1);

        int product = 1;
        for (int i = 0; i < list.size(); i++) {
            product *= list.get(i);
        }
        System.out.println("Product of list values: " + product);

        /* read */ int value = list.get(1);
        System.out.println("Read value from list: " + value);

        anotherList.addAll(list);
        System.out.println("Combined list values:");
        for (Integer val : anotherList) {
            System.out.println(val);
        }
    }
}