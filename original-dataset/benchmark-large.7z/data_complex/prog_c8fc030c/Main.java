import java.util.OptionalLong;
import java.util.stream.LongStream;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        LongStream longStream = LongStream.of(1, 2, 3, 4, 5);
        /* write */ LongStream filteredStream = longStream.filter(n -> n > 3);
        
        // Adding complexity with an ArrayList
        List<Integer> numbers = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            numbers.add(i * 2);
        }

        // Processing the ArrayList
        int sum = 0;
        for (int number : numbers) {
            sum += number;
        }
        System.out.println("Sum of numbers: " + sum);

        // Another stream operation
        LongStream anotherStream = LongStream.of(10, 20, 30, 40, 50);
        LongStream transformedStream = anotherStream.map(n -> n / 2);
        OptionalLong firstTransformedValue = transformedStream.findFirst();
        if (firstTransformedValue.isPresent()) {
            System.out.println("First transformed value: " + firstTransformedValue.getAsLong());
        }

        // More complex logic
        List<String> strings = new ArrayList<>();
        strings.add("apple");
        strings.add("banana");
        strings.add("cherry");

        for (String str : strings) {
            System.out.println("Fruit: " + str);
        }

        /* read */ OptionalLong value = filteredStream.findFirst();
        if (value.isPresent()) {
            System.out.println("First filtered value: " + value.getAsLong());
        } else {
            System.out.println("No value found");
        }
    }
}