import java.util.stream.Stream;
import java.util.Optional;
import java.util.List;
import java.util.ArrayList;
import java.util.function.Predicate;

public class Main {
    public static void main(String[] args) {
        // Original Stream operations
        Stream<Integer> stream = Stream.of(1, 2, 3, 4, 5);
        /* write */ Stream<Integer> filteredStream = stream.filter(n -> n > 3);

        // Additional complexity: Using another stream and operations
        List<String> stringList = new ArrayList<>();
        stringList.add("apple");
        stringList.add("banana");
        stringList.add("cherry");
        
        // Creating a stream from a list
        Stream<String> stringStream = stringList.stream();
        
        // Filtering the stream based on a predicate
        Predicate<String> startsWithB = s -> s.startsWith("b");
        Stream<String> filteredStringStream = stringStream.filter(startsWithB);
        
        // Finding the first element that matches the predicate
        Optional<String> firstString = filteredStringStream.findFirst();
        firstString.ifPresent(System.out::println);

        // Unrelated code: Simple arithmetic operations
        int a = 10;
        int b = 20;
        int sum = a + b;
        System.out.println("Sum: " + sum);
        
        // More unrelated code: Loop through numbers and print squares
        for (int i = 1; i <= 5; i++) {
            System.out.println("Square of " + i + ": " + (i * i));
        }

        // Original Stream read operation
        /* read */ Optional<Integer> firstElement = filteredStream.findFirst();
        firstElement.ifPresent(System.out::println);
    }
}