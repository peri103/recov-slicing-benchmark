import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.locks.ReentrantLock;
import java.util.ArrayList;

public class Main {
    private volatile long value;
    private volatile int intValue;

    public static void main(String[] args) {
        Main instance = new Main();
        AtomicLongFieldUpdater<Main> longUpdater = AtomicLongFieldUpdater.newUpdater(Main.class, "value");
        AtomicIntegerFieldUpdater<Main> intUpdater = AtomicIntegerFieldUpdater.newUpdater(Main.class, "intValue");
        ReentrantLock lock = new ReentrantLock();
        ArrayList<Integer> numbers = new ArrayList<>();

        /* write */ longUpdater.set(instance, 100L);

        // Some unrelated computations
        lock.lock();
        try {
            for (int i = 0; i < 10; i++) {
                numbers.add(i * 10);
                if (i % 2 == 0) {
                    intUpdater.set(instance, i);
                }
            }
        } finally {
            lock.unlock();
        }

        // More unrelated code
        for (int i = 0; i < numbers.size(); i++) {
            System.out.println("Number: " + numbers.get(i));
        }

        /* read */ long readValue = longUpdater.get(instance);
        
        System.out.println("Read Long Value: " + readValue);

        // Further unrelated operations
        int sum = 0;
        for (int number : numbers) {
            sum += number;
        }
        System.out.println("Sum of numbers: " + sum);

        // Another atomic operation
        intUpdater.set(instance, 50);
        int readIntValue = intUpdater.get(instance);
        System.out.println("Read Int Value: " + readIntValue);
    }
}