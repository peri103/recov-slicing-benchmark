import java.util.concurrent.CopyOnWriteArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class Main {
    public static void main(String[] args) {
        CopyOnWriteArrayList<Integer> list = new CopyOnWriteArrayList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        
        // Adding more elements to the list
        for (int i = 4; i <= 10; i++) {
            list.add(i);
        }

        // Using a HashSet to demonstrate unrelated complexity
        HashSet<String> set = new HashSet<>();
        set.add("Apple");
        set.add("Banana");
        set.add("Cherry");

        Iterator<String> it = set.iterator();
        while (it.hasNext()) {
            System.out.println("Set contains: " + it.next());
        }

        /* write */ Object[] array = list.toArray();
        
        // Perform some operations on the array
        System.out.println("Array contents:");
        for (Object obj : array) {
            System.out.print(obj + " ");
        }
        System.out.println();

        // More unrelated operations
        int sum = 0;
        for (Integer num : list) {
            sum += num;
        }
        System.out.println("Sum of list elements: " + sum);

        /* read */ int size = list.size();
        System.out.println("Size of the list: " + size);
    }
}