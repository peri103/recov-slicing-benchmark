import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        try {
            // Step 1: Create a temporary file and write initial data
            Path tempFile = Files.createTempFile("example", ".txt");
            Files.write(tempFile, "Hello, World!".getBytes());

            // Step 2: Read all bytes from the file
            /* write */ byte[] data = Files.readAllBytes(tempFile);
            System.out.println("Data read from file: " + new String(data));

            // Step 3: Perform some unrelated operations
            List<Integer> numbers = new ArrayList<>();
            for (int i = 0; i < 10; i++) {
                numbers.add(i * i);
            }

            int sum = 0;
            for (int num : numbers) {
                sum += num;
            }
            System.out.println("Sum of squares from 0 to 9: " + sum);

            // Step 4: Check the size of the file
            /* read */ long size = Files.size(tempFile);
            System.out.println("Size of file: " + size + " bytes");

            // Step 5: Perform additional unrelated operations
            List<String> words = new ArrayList<>();
            words.add("apple");
            words.add("banana");
            words.add("cherry");

            for (String word : words) {
                System.out.println("Word: " + word);
            }

            // Step 6: Clean up by deleting the temporary file
            Files.delete(tempFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}