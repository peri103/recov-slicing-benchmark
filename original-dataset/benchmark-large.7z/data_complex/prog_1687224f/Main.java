import java.util.stream.DoubleStream;
import java.util.stream.IntStream;
import java.util.List;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        DoubleStream doubleStream = DoubleStream.of(1.0, 2.0, 3.0);
        DoubleStream anotherStream = DoubleStream.of(4.0, 5.0, 6.0);
        IntStream intStream = IntStream.range(1, 4);

        List<Double> results = new ArrayList<>();
        intStream.forEach(i -> {
            double sum = anotherStream.map(x -> x * i).reduce(0, (a, b) -> a + b);
            results.add(sum);
        });

        /* write */
        DoubleStream mappedStream = doubleStream.map(x -> x * 2);

        // Perform some operations with results
        double totalSum = results.stream().reduce(0.0, Double::sum);
        System.out.println("Total Sum of results: " + totalSum);

        /* read */
        double result = mappedStream.reduce(0, (a, b) -> a + b);

        System.out.println("Result from mappedStream: " + result);

        // Additional unrelated code
        List<Integer> intList = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            intList.add(i * i);
        }

        int maxSquare = intList.stream().mapToInt(Integer::intValue).max().orElse(0);
        System.out.println("Max square value: " + maxSquare);
    }
}