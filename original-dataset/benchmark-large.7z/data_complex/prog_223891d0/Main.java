import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {
    public static void main(String[] args) {
        Stream<List<Integer>> streamOfLists = Stream.of(
            List.of(1, 2, 3),
            List.of(4, 5, 6),
            List.of(7, 8, 9)
        );

        // Additional unrelated code
        Map<String, Integer> map = new HashMap<>();
        map.put("one", 1);
        map.put("two", 2);
        map.put("three", 3);

        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }

        // Another stream operation
        Stream<String> stringStream = Stream.of("apple", "banana", "cherry");
        List<String> stringList = stringStream
            .map(String::toUpperCase)
            .collect(Collectors.toList());
        System.out.println(stringList);

        /* write */ Stream<Integer> flatMappedStream = streamOfLists.flatMap(List::stream);

        // More unrelated code
        List<Integer> numbers = List.of(10, 20, 30, 40, 50);
        int sum = numbers.stream().reduce(0, Integer::sum);
        System.out.println("Sum of numbers: " + sum);

        // Even more unrelated code
        Stream<String> anotherStringStream = Stream.of("dog", "cat", "bird");
        anotherStringStream.forEach(System.out::println);

        /* read */ List<Integer> collectedList = flatMappedStream.collect(Collectors.toList());

        System.out.println(collectedList);
    }
}