import java.util.concurrent.LinkedTransferQueue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Initialize the LinkedTransferQueue and add elements
        LinkedTransferQueue<Integer> queue = new LinkedTransferQueue<>();
        queue.add(1);
        queue.add(2);
        queue.add(3);

        // Initialize another queue for additional operations
        ConcurrentLinkedQueue<String> stringQueue = new ConcurrentLinkedQueue<>();
        stringQueue.add("One");
        stringQueue.add("Two");
        stringQueue.add("Three");

        // Perform some operations on the stringQueue
        String firstElement = stringQueue.poll();
        System.out.println("Polled from stringQueue: " + firstElement);

        // Convert queue to array
        /* write */ Object[] array = queue.toArray();

        // Initialize an ArrayList and perform operations
        ArrayList<Integer> list = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            list.add(i * 10);
        }

        // Print ArrayList elements
        for (int num : list) {
            System.out.println("ArrayList element: " + num);
        }

        // Add more elements to the queue
        queue.add(4);
        queue.add(5);

        // Calculate and print the size of the queue
        /* read */ int size = queue.size();
        System.out.println("Queue size: " + size);

        // Perform some unrelated computation
        int sum = 0;
        for (int i = 0; i < list.size(); i++) {
            sum += list.get(i);
        }
        System.out.println("Sum of ArrayList elements: " + sum);

        // Print the length of the array derived from the queue
        System.out.println("Array length: " + array.length);
    }
}