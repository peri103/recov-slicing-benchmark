import java.util.Properties;
import java.util.HashMap;
import java.util.Set;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        Properties properties = new Properties();
        
        // Initialize properties with some values
        properties.setProperty("key1", "value1");
        properties.setProperty("key2", "value2");
        properties.setProperty("key3", "value3");
        
        /* write */ properties.remove("key1");
        
        // Add some unrelated code using HashMap
        HashMap<String, Integer> map = new HashMap<>();
        map.put("one", 1);
        map.put("two", 2);
        map.put("three", 3);
        
        // Iterate over the map
        Set<Map.Entry<String, Integer>> entries = map.entrySet();
        for (Map.Entry<String, Integer> entry : entries) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }
        
        // Perform some operations on properties
        properties.setProperty("key4", "value4");
        properties.setProperty("key5", "value5");
        
        // Get all property names
        Set<String> propertyNames = properties.stringPropertyNames();
        for (String name : propertyNames) {
            System.out.println("Property: " + name + ", Value: " + properties.getProperty(name));
        }
        
        // Attempt to read the removed property
        /* read */ String value = properties.getProperty("key1");
        
        // Since "key1" was removed, value should be null
        System.out.println(value);  // Output: null
        
        // Add another set of operations using HashMap
        map.put("four", 4);
        map.put("five", 5);
        
        // Iterate over the map again
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println("Updated Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }
    }
}