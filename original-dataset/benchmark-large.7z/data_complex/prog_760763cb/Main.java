import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;
import java.util.PriorityQueue;

public class Main {
    public static void main(String[] args) {
        DelayQueue<DelayedElement> delayQueue = new DelayQueue<>();
        PriorityQueue<Integer> priorityQueue = new PriorityQueue<>();

        // Add an element to the DelayQueue for demonstration
        DelayedElement element = new DelayedElement(1000, "Test Element");
        delayQueue.add(element);

        // Add elements to the PriorityQueue
        priorityQueue.add(5);
        priorityQueue.add(10);
        priorityQueue.add(3);

        /* write */ delayQueue.remove(element);

        // Process the PriorityQueue
        while (!priorityQueue.isEmpty()) {
            int item = priorityQueue.poll();
            System.out.println("Processing item from PriorityQueue: " + item);
        }

        // Simulate some complex logic
        for (int i = 0; i < 3; i++) {
            delayQueue.add(new DelayedElement(500 * i, "Element " + i));
        }

        // Additional unrelated logic
        int sum = 0;
        for (int i = 1; i <= 5; i++) {
            sum += i;
        }
        System.out.println("Sum of first 5 numbers: " + sum);

        /* read */ DelayedElement peekedElement = (DelayedElement) delayQueue.peek();

        if (peekedElement == null) {
            System.out.println("The element was removed successfully.");
        } else {
            System.out.println("The element was not removed.");
        }
    }
}

class DelayedElement implements Delayed {
    private long delayTime;
    private long creationTime;
    private String data;

    public DelayedElement(long delay, String data) {
        this.delayTime = delay;
        this.creationTime = System.currentTimeMillis();
        this.data = data;
    }

    @Override
    public long getDelay(TimeUnit unit) {
        long diff = creationTime + delayTime - System.currentTimeMillis();
        return unit.convert(diff, TimeUnit.MILLISECONDS);
    }

    @Override
    public int compareTo(Delayed o) {
        if (this.getDelay(TimeUnit.MILLISECONDS) < o.getDelay(TimeUnit.MILLISECONDS)) {
            return -1;
        }
        if (this.getDelay(TimeUnit.MILLISECONDS) > o.getDelay(TimeUnit.MILLISECONDS)) {
            return 1;
        }
        return 0;
    }

    @Override
    public String toString() {
        return data;
    }
}