import java.util.HashSet;
import java.util.HashMap;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        HashSet<Integer> set = new HashSet<>();
        set.add(1); // Adding an element to ensure it can be removed
        HashMap<String, Integer> map = new HashMap<>();
        ArrayList<Integer> list = new ArrayList<>();

        // Adding elements to map
        map.put("One", 1);
        map.put("Two", 2);
        map.put("Three", 3);

        // Adding elements to list
        for (int i = 0; i < 5; i++) {
            list.add(i * 10);
        }

        // Perform some operations on map
        if (map.containsKey("Two")) {
            int valueFromMap = map.get("Two");
            System.out.println("Value from map: " + valueFromMap);
        }

        // Perform some operations on list
        int sum = 0;
        for (int num : list) {
            sum += num;
        }
        System.out.println("Sum of list: " + sum);

        /* write */ set.remove(1);

        // Perform additional operations on set
        set.add(2);
        set.add(3);
        set.add(4);

        for (Integer num : set) {
            System.out.println("Set contains: " + num);
        }

        /* read */ boolean contains = set.contains(1);
        System.out.println("Set contains 1: " + contains); // This should print 'false' since the element was removed

        // More complex operations
        ArrayList<Integer> anotherList = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            anotherList.add(i * 5);
        }

        for (int i = 0; i < anotherList.size(); i++) {
            int val = anotherList.get(i);
            if (val % 2 == 0) {
                System.out.println("Even number in anotherList: " + val);
            }
        }
    }
}