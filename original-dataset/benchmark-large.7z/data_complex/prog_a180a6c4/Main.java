import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.nio.file.StandardOpenOption;
import java.nio.charset.StandardCharsets;

public class Main {
    public static void main(String[] args) {
        try {
            // Original write-read pair
            Path path = Paths.get("exampleDir");
            /* write */ Files.createDirectories(path);
            
            // Additional complexity: create a file within the directory
            Path filePath = Paths.get("exampleDir", "exampleFile.txt");
            List<String> lines = new ArrayList<>();
            lines.add("Hello, World!");
            Files.write(filePath, lines, StandardCharsets.UTF_8, StandardOpenOption.CREATE);

            // More complexity: read from the file and print its contents
            List<String> readLines = Files.readAllLines(filePath, StandardCharsets.UTF_8);
            for (String line : readLines) {
                System.out.println("File content: " + line);
            }

            // Perform some unrelated operations
            int sum = 0;
            for (int i = 0; i < 10; i++) {
                sum += i;
            }
            System.out.println("Sum of numbers from 0 to 9: " + sum);

            // Original read operation
            /* read */ boolean exists = Files.exists(path);
            System.out.println("Directory exists: " + exists);

            // More unrelated operations
            if (exists) {
                Path newFilePath = Paths.get("exampleDir", "newFile.txt");
                Files.write(newFilePath, "New file content".getBytes(), StandardOpenOption.CREATE);
                System.out.println("New file created.");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}