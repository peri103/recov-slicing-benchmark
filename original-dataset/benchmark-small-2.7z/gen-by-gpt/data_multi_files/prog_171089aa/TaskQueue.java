import java.util.concurrent.PriorityBlockingQueue;

public class TaskQueue {
    private PriorityBlockingQueue<Integer> queue = new PriorityBlockingQueue<>();

    public void addTask(int taskPriority) {
        /* write */ queue.offer(taskPriority);
    }

    public Integer getNextTask() {
        return queue.poll();
    }

    public boolean hasTasks() {
        return !queue.isEmpty();
    }
}
