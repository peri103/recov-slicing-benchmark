public class Main {
    public static void main(String[] args) {
        TaskManager manager = new TaskManager();

        // Adding tasks with different priorities
        manager.addTask(10);
        manager.addTask(5);
        manager.addTask(20);

        // Log the status
        manager.logStatus();

        // Process the tasks
        manager.processTasks();
    }
}