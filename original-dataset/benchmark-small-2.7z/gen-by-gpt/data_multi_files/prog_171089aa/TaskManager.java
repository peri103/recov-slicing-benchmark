import java.util.concurrent.ArrayBlockingQueue;

public class TaskManager {
    private TaskQueue taskQueue = new TaskQueue();
    private ArrayBlockingQueue<String> logQueue = new ArrayBlockingQueue<>(10);

    public void addTask(int priority) {
        taskQueue.addTask(priority);
        logQueue.offer("Task with priority " + priority + " added.");
    }

    public void processTasks() {
        while (taskQueue.hasTasks()) {
            Integer task = taskQueue.getNextTask();
            /* read */ System.out.println("Processing task with priority: " + task);
        }
    }

    public void logStatus() {
        while (!logQueue.isEmpty()) {
            System.out.println("Log: " + logQueue.poll());
        }
    }
}
