import java.util.ArrayList;
import java.util.HashMap;

public class ComplexOperations {
    private ArrayList<String> names = new ArrayList<>();
    private HashMap<String, Integer> nameToAgeMap = new HashMap<>();

    public ComplexOperations() {
        // Initializing some data
        names.add("Alice");
        names.add("Bob");
        names.add("Charlie");

        nameToAgeMap.put("Alice", 30);
        nameToAgeMap.put("Bob", 25);
        nameToAgeMap.put("Charlie", 35);
    }

    public void displayNamesAndAges() {
        for (String name : names) {
            System.out.println(name + " is " + nameToAgeMap.get(name) + " years old.");
        }
    }

    public void addNameAndAge(String name, int age) {
        names.add(name);
        nameToAgeMap.put(name, age);
    }

    public void displaySumOfNumbers() {
        int sum = 0;
        for (int i = 0; i < 10; i++) {
            sum += i;
        }
        System.out.println("Sum of numbers from 0 to 9: " + sum);
    }
}
