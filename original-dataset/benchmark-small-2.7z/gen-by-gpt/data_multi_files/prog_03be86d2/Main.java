public class Main {
    public static void main(String[] args) {
        PriorityQueueManager pqManager = new PriorityQueueManager();
        ComplexOperations operations = new ComplexOperations();

        // Using ComplexOperations
        operations.displayNamesAndAges();
        operations.addNameAndAge("David", 40);
        operations.displayNamesAndAges();
        operations.displaySumOfNumbers();

        // Adding elements to the queue
        pqManager.addElement(10);
        pqManager.addElement(20);
        pqManager.addElement(5);
        pqManager.addElement(15);
        pqManager.addElement(25);

        // Reading from the queue
        /* read */ int value = pqManager.getQueue().poll();
        System.out.println("Polled value from the queue: " + value);

        // Display remaining elements in the queue
        System.out.println("Remaining elements in the queue:");
        while (!pqManager.getQueue().isEmpty()) {
            System.out.println(pqManager.getQueue().poll());
        }
    }
}