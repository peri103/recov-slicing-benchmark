public class Main {
    public static void main(String[] args) {
        Course course = new Course("Computer Science");
        
        Student alice = new Student("Alice", 20);
        Student bob = new Student("Bob", 22);

        course.addStudent(alice);
        course.addStudent(bob);

        System.out.println("Course: " + course.getCourseName());
        
        Student firstStudent = course.getFirstStudent();
        System.out.println("First student in the course: " + firstStudent.getName() + ", Age: " + firstStudent.getAge());
    }
}