import java.util.ArrayList;
import java.util.List;

public class Course {
    private String courseName;
    private List<Student> students = new ArrayList<>();

    public Course(String courseName) {
        this.courseName = courseName;
    }

    public void addStudent(Student student) {
        students.add(student);
    }

    public void printStudentNames() {
        System.out.println("Students in " + courseName + ":");
        for (Student student : students) {
            System.out.println(student.getName());
        }
    }
}
