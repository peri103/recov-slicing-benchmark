public class Main {
    public static void main(String[] args) {
        Student student = new Student("John");
        Course course1 = new Course(101, "Math");
        Course course2 = new Course(102, "Science");

        student.completeCourse(course1.getCourseId());

        // Some unrelated computation
        int factorial = 1;
        for (int i = 1; i <= 5; i++) {
            factorial *= i;
        }
        System.out.println("Factorial of 5: " + factorial);

        // Further operations
        boolean hasCompletedMath = student.hasCompletedCourse(course1.getCourseId());
        /* read */ System.out.println(student.getName() + " has completed Math: " + hasCompletedMath);

        // More unrelated code
        int sum = 0;
        for (int i = 1; i <= 10; i++) {
            sum += i;
        }
        System.out.println("Sum of first 10 numbers: " + sum);
    }
}