import java.util.HashSet;

public class Student {
    private String name;
    private HashSet<Integer> completedCourses = new HashSet<>();

    public Student(String name) {
        this.name = name;
    }

    public void completeCourse(int courseId) {
        /* write */ completedCourses.add(courseId);
    }

    public boolean hasCompletedCourse(int courseId) {
        return completedCourses.contains(courseId);
    }

    public String getName() {
        return name;
    }
}
