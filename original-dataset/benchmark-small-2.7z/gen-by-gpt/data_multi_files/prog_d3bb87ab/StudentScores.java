import java.util.concurrent.ConcurrentHashMap;
import java.util.List;
import java.util.ArrayList;

public class StudentScores {
    private ConcurrentHashMap<String, Integer> scoreMap = new ConcurrentHashMap<>();
    private List<Integer> scoreList = new ArrayList<>();

    public void addScore(int score) {
        /* write */ scoreMap.putIfAbsent("latestScore", score);
        scoreList.add(score);
    }

    public Integer getLatestScore() {
        return scoreMap.get("latestScore");
    }

    public List<Integer> getAllScores() {
        return scoreList;
    }
}
