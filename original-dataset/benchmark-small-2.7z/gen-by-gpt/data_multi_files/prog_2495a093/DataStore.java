import java.util.concurrent.CopyOnWriteArrayList;

public class DataStore {
    private CopyOnWriteArrayList<Integer> numbers = new CopyOnWriteArrayList<>();

    public void addNumber(int number) {
        /* write */ numbers.add(number);
    }

    public CopyOnWriteArrayList<Integer> getNumbers() {
        return numbers;
    }
}
