import java.util.List;

public class Main {
    public static void main(String[] args) {
        DataStore dataStore = new DataStore();
        dataStore.addNumber(42);

        Student student = new Student("Alice");
        student.enrollCourse("Mathematics");
        student.enrollCourse("Science");

        Course course = new Course("Mathematics");
        course.enrollStudent(student);

        List<Student> students = course.getEnrolledStudents();
        for (Student s : students) {
            System.out.println("Student: " + s.getName());
            System.out.println("Courses: " + s.getCourses());
        }

        CopyOnWriteArrayList<Integer> numbers = dataStore.getNumbers();
        /* read */ int number = numbers.get(0);
        System.out.println("Number from DataStore: " + number);
    }
}