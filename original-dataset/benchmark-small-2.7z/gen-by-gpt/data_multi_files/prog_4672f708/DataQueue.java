import java.util.concurrent.LinkedTransferQueue;

public class DataQueue {
    private LinkedTransferQueue<Integer> queue = new LinkedTransferQueue<>();

    public void addData(int data) {
        try {
            /* write */ queue.put(data);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public LinkedTransferQueue<Integer> getQueue() {
        return queue;
    }
}
