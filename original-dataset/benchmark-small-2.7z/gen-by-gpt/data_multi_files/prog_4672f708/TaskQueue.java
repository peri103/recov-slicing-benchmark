import java.util.concurrent.LinkedTransferQueue;

public class TaskQueue {
    private LinkedTransferQueue<Integer> queue = new LinkedTransferQueue<>();

    public void addTask(int task) {
        try {
            /* write */ queue.put(task);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public int getTask() {
        try {
            return queue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
            return -1; // Return an error value
        }
    }
}
