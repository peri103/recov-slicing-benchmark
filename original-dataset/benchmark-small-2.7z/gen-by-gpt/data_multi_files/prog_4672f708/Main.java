public class Main {
    public static void main(String[] args) {
        DataQueue dataQueue = new DataQueue();
        DataProcessor dataProcessor = new DataProcessor(dataQueue);

        dataQueue.addData(42);

        int processedValue = dataProcessor.processData();
        System.out.println("Processed value: " + processedValue);

        // Additional logic to demonstrate complexity
        dataQueue.addData(100);
        dataQueue.addData(200);

        for (int i = 0; i < 2; i++) {
            System.out.println("Next processed value: " + dataProcessor.processData());
        }
    }
}