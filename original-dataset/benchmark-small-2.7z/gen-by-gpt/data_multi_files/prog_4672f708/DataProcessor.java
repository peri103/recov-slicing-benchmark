import java.util.concurrent.LinkedTransferQueue;

public class DataProcessor {
    private DataQueue dataQueue;

    public DataProcessor(DataQueue dataQueue) {
        this.dataQueue = dataQueue;
    }

    public int processData() {
        try {
            /* read */ int value = dataQueue.getQueue().take();
            return value;
        } catch (InterruptedException e) {
            e.printStackTrace();
            return -1;
        }
    }
}
