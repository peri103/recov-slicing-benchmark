import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        DataStore dataStore = new DataStore();
        Course course = new Course("Mathematics");
        
        Student alice = new Student("Alice");
        alice.addScore(85);
        alice.addScore(90);
        
        Student bob = new Student("Bob");
        bob.addScore(75);
        bob.addScore(80);
        
        course.addStudent(alice);
        course.addStudent(bob);

        dataStore.putValue("key", 42);

        // Print student scores
        for (Student student : course.getStudents()) {
            System.out.println("Scores for " + student.getName() + ": " + student.getScores());
        }

        // Original read operation
        /* read */ int value = dataStore.getValue("key");
        System.out.println("Value from DataStore: " + value);
    }
}