import java.util.HashMap;

public class DataStore {
    private HashMap<String, Integer> map = new HashMap<>();

    public void putValue(String key, int value) {
        /* write */ map.put(key, value);
    }

    public int getValue(String key) {
        return map.get(key);
    }
}
