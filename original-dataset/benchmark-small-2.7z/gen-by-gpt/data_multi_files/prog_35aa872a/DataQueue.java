import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class DataQueue {
    private BlockingQueue<Integer> queue = new LinkedBlockingQueue<>();

    public void addData(int data) {
        try {
            /* write */ queue.put(data);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public BlockingQueue<Integer> getQueue() {
        return queue;
    }
}
