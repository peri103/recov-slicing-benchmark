public class Main {
    public static void main(String[] args) {
        DataProcessor processor = new DataProcessor();
        DataQueue queue = processor.getDataQueue();

        // Add data to the queue
        for (int i = 0; i < 5; i++) {
            queue.addData(i * 10);
        }

        // Add a special value
        queue.addData(42);

        // Process the data
        processor.processData();

        try {
            /* read */ int finalValue = queue.getQueue().take();
            System.out.println("Final value taken from queue: " + finalValue);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}