import java.util.concurrent.BlockingQueue;

public class DataProcessor {
    private DataQueue dataQueue = new DataQueue();

    public void processData() {
        BlockingQueue<Integer> queue = dataQueue.getQueue();
        try {
            while (!queue.isEmpty()) {
                int value = queue.take();
                System.out.println("Processed value: " + value);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public DataQueue getDataQueue() {
        return dataQueue;
    }
}
