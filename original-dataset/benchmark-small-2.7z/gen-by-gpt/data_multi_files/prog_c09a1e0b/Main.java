public class Main {
    public static void main(String[] args) {
        // Create TreeSetManager instance
        TreeSetManager treeSetManager = new TreeSetManager();
        treeSetManager.addValue(42);
        treeSetManager.addValue(15);
        treeSetManager.addValue(30);

        // Create Course and Student instances
        Course course = new Course("Mathematics");
        Student student1 = new Student("Alice");
        Student student2 = new Student("Bob");

        // Add scores to students
        student1.addScore(95);
        student1.addScore(85);
        student2.addScore(75);
        student2.addScore(65);

        // Add students to course
        course.addStudent(student1);
        course.addStudent(student2);

        // Iterate through students and print their scores
        for (Student student : course.getStudents()) {
            System.out.println("Student: " + student.getName());
            for (Integer score : student.getScores()) {
                System.out.println("Score: " + score);
            }
        }

        // Final read
        /* read */ boolean containsValue = treeSetManager.containsValue(42);
        System.out.println("TreeSet contains 42: " + containsValue);
    }
}