import java.util.TreeMap;

public class StudentScores {
    private TreeMap<Integer, String> scoreMap = new TreeMap<>();

    public void addScore(int id, String score) {
        /* write */ scoreMap.put(id, score);
    }

    public String getScore(int id) {
        return scoreMap.get(id);
    }
}
