public class Main {
    public static void main(String[] args) {
        Course course = new Course("Mathematics");
        Student student1 = new Student("Alice");
        Student student2 = new Student("Bob");

        student1.getScores().addScore(1, "A");
        student2.getScores().addScore(2, "B");

        course.addStudent(student1);
        course.addStudent(student2);

        for (Student student : course.getStudents()) {
            System.out.println("Student: " + student.getName());
            System.out.println("Score: " + student.getScores().getScore(1));
        }

        // Reading the score of the first student
        /* read */ String score = student1.getScores().getScore(1);
        System.out.println("Read Score for Alice: " + score);
    }
}