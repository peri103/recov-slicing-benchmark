public class Main {
    public static void main(String[] args) {
        // LinkedList operations
        LinkedListOperations operations = new LinkedListOperations();
        operations.addElement(10);
        operations.addElement(20);
        operations.addElement(30);
        
        // Student and Course operations
        Student alice = new Student("Alice");
        alice.addGrade(85);
        alice.addGrade(90);

        Student bob = new Student("Bob");
        bob.addGrade(75);
        bob.addGrade(80);

        Course math = new Course("Mathematics");
        math.enrollStudent(alice);
        math.enrollStudent(bob);

        // Display grades
        System.out.println("Grades for Alice in " + math.getTitle() + ": " + math.getStudent("Alice").getGrades());
        System.out.println("Grades for Bob in " + math.getTitle() + ": " + math.getStudent("Bob").getGrades());

        // Read operation in LinkedList
        /* read */ int lastElement = operations.getLastElement();
        System.out.println("Last element in LinkedList: " + lastElement);
    }
}