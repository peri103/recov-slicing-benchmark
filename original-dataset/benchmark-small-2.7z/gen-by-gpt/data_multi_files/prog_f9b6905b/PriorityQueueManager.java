import java.util.concurrent.PriorityBlockingQueue;

public class PriorityQueueManager {
    private PriorityBlockingQueue<Integer> queue = new PriorityBlockingQueue<>();

    public void addElement(int element) {
        /* write */ queue.offer(element);
    }

    public Integer retrieveElement() {
        return queue.poll();
    }
}
