import java.util.HashMap;
import java.util.Map;

public class Course {
    private String courseName;
    private Map<Integer, Student> enrolledStudents = new HashMap<>();

    public Course(String courseName) {
        this.courseName = courseName;
    }

    public void enrollStudent(Student student) {
        enrolledStudents.put(student.getId(), student);
    }

    public Student getStudent(int id) {
        return enrolledStudents.get(id);
    }

    public String getCourseName() {
        return courseName;
    }
}
