public class Student {
    private String name;
    private int id;
    private PriorityQueueManager queueManager = new PriorityQueueManager();

    public Student(String name, int id) {
        this.name = name;
        this.id = id;
    }

    public void addScore(int score) {
        queueManager.addElement(score);
    }

    public Integer getScore() {
        return queueManager.retrieveElement();
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }
}
