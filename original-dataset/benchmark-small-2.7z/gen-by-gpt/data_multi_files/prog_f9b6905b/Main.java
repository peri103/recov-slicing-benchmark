public class Main {
    public static void main(String[] args) {
        Course course = new Course("Data Structures");
        Student student = new Student("Alice", 1001);
        student.addScore(95);
        course.enrollStudent(student);

        Student retrievedStudent = course.getStudent(1001);
        System.out.println("Student Name: " + retrievedStudent.getName());
        System.out.println("Course: " + course.getCourseName());

        /* read */ Integer score = retrievedStudent.getScore();
        System.out.println("Score: " + score);
    }
}