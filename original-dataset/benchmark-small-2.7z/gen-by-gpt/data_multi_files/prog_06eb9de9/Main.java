public class Main {
    public static void main(String[] args) {
        SortedMapManager sortedMapManager = new SortedMapManager();
        sortedMapManager.addEntry("key1", 100);

        DataProcessor dataProcessor = new DataProcessor(sortedMapManager);
        dataProcessor.addSampleData();
        dataProcessor.processEntries();

        /* read */ Integer value = sortedMapManager.getEntry("key1");
        System.out.println("Value for 'key1': " + value);
    }
}