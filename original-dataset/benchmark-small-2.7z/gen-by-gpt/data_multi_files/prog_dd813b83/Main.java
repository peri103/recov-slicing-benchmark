public class Main {
    public static void main(String[] args) {
        Student student = new Student("John Doe", 12345);
        Course course = student.getCourse();

        // Add assignments to the course
        course.addAssignment(1, "Assignment 1: Java Basics");
        course.addAssignment(2, "Assignment 2: Object-Oriented Programming");

        // Retrieve and print assignment details
        String assignmentDescription = course.getAssignment(1);
        System.out.println("Course: " + course.getCourseName());
        System.out.println("Student: " + student.getName());
        System.out.println("Assignment: " + assignmentDescription);
    }
}