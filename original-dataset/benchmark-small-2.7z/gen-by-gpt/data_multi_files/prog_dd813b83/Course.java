import java.util.concurrent.ConcurrentSkipListMap;

public class Course {
    private String courseName;
    private ConcurrentSkipListMap<Integer, String> assignments;

    public Course(String courseName) {
        this.courseName = courseName;
        this.assignments = new ConcurrentSkipListMap<>();
    }

    public String getCourseName() {
        return courseName;
    }

    public void addAssignment(int id, String description) {
        /* write */ assignments.put(id, description);
    }

    public String getAssignment(int id) {
        /* read */ return assignments.get(id);
    }
}
