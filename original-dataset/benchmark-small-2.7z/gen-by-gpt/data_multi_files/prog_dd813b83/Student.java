public class Student {
    private String name;
    private int id;
    private Course course;

    public Student(String name, int id) {
        this.name = name;
        this.id = id;
        this.course = new Course("Introduction to Java");
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public Course getCourse() {
        return course;
    }
}
