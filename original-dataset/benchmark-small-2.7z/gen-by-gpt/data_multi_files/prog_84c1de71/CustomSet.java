import java.util.HashSet;

public class CustomSet {
    private HashSet<Integer> set = new HashSet<>();

    public void addElement(int element) {
        /* write */ set.add(element);
    }

    public boolean containsElement(int element) {
        return set.contains(element);
    }

    public HashSet<Integer> getAllElements() {
        return set;
    }
}
