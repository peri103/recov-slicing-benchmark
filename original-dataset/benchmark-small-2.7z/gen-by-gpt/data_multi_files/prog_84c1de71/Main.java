import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {
        // Initialize CustomSet and add elements
        CustomSet customSet = new CustomSet();
        customSet.addElement(10);
        customSet.addElement(20);
        customSet.addElement(30);

        // Initialize Student and add scores
        Student student = new Student("Bob");
        student.addScore(85);
        student.addScore(90);

        // Check if CustomSet contains certain elements
        boolean containsTen = customSet.containsElement(10);
        boolean containsForty = customSet.containsElement(40);

        // Print results of CustomSet checks
        System.out.println("CustomSet contains 10: " + containsTen);
        System.out.println("CustomSet contains 40: " + containsForty);

        // Print student scores
        System.out.println(student.getName() + "'s scores: " + student.getScores());

        // Additional data structure: LinkedList
        LinkedList<String> queue = new LinkedList<>();
        queue.add("First");
        queue.add("Second");

        // Process and print elements in the queue
        while (!queue.isEmpty()) {
            System.out.println("Queue element: " + queue.poll());
        }

        // Check if CustomSet contains the element added in CustomSet class
        /* read */ boolean containsValue = customSet.containsElement(10);
        System.out.println("Final check: CustomSet contains 10: " + containsValue);
    }
}