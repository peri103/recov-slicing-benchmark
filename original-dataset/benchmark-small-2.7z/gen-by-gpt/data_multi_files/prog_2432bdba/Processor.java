import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;

public class Processor {
    private ConcurrentLinkedQueue<String> queue = new ConcurrentLinkedQueue<>();
    private AtomicInteger counter = new AtomicInteger(0);

    public void processQueue() {
        while (!queue.isEmpty()) {
            String element = queue.poll();
            System.out.println("Processing: " + element);
            counter.incrementAndGet();
        }
    }

    public void addElementToQueue(String element) {
        queue.add(element);
    }

    public int getProcessedCount() {
        return counter.get();
    }
}
