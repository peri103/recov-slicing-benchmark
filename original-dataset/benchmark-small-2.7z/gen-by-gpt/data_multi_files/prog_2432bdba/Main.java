public class Main {
    public static void main(String[] args) {
        DataStore dataStore = new DataStore();
        Processor processor = new Processor();

        // Adding elements to the queue
        processor.addElementToQueue("first");
        processor.addElementToQueue("second");
        processor.addElementToQueue("third");

        // Processing the queue
        processor.processQueue();

        // Adding a value to the data store
        dataStore.addValue("key", 100);

        // Performing some unrelated calculations
        int sum = 0;
        for (int i = 0; i < 10; i++) {
            sum += i;
        }
        System.out.println("Sum of first 10 numbers: " + sum);

        // Simulating some delay or additional operations
        try {
            Thread.sleep(200);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Reading the value from the data store
        /* read */ Integer value = dataStore.getValue("key");
        System.out.println("Value from data store: " + value);

        // Displaying the count of processed elements
        System.out.println("Total elements processed: " + processor.getProcessedCount());
    }
}