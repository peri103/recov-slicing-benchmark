import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {
        // Create a course and students
        Course course = new Course("Mathematics");
        Student student1 = new Student("Alice");
        Student student2 = new Student("Bob");

        // Add scores to students
        student1.addScore(85);
        student1.addScore(90);
        student2.addScore(78);
        student2.addScore(88);

        // Add students to the course
        course.addStudent(student1);
        course.addStudent(student2);

        // Print all students and their scores
        for (Student student : course.getStudents()) {
            System.out.println("Student: " + student.getName());
            LinkedList<Integer> scores = student.getScores();
            for (int score : scores) {
                System.out.println("Score: " + score);
            }
        }

        // Original read
        LinkedList<Integer> scores = student1.getScores();
        /* read */ int lastScore = scores.getLast();
        System.out.println("Last score of " + student1.getName() + ": " + lastScore);
    }
}