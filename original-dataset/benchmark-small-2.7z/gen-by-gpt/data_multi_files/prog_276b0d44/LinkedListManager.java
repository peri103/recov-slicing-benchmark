import java.util.LinkedList;

public class LinkedListManager {
    private LinkedList<Integer> list = new LinkedList<>();

    public void addElement(int element) {
        /* write */ list.addLast(element);
    }

    public int getLastElement() {
        return list.getLast();
    }

    public LinkedList<Integer> getList() {
        return list;
    }

    public void performOperations() {
        list.addFirst(10);
        list.addLast(20);
        list.addLast(30);
        for (int i = 0; i < list.size(); i++) {
            list.set(i, list.get(i) * 2);
        }
    }
}
