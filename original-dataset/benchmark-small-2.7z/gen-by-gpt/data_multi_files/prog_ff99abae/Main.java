public class Main {
    public static void main(String[] args) {
        Student student = new Student("Bob");
        student.addScore(42);

        Course course = new Course("Mathematics");
        course.addStudent(student);

        for (Student s : course.getStudents()) {
            Vector<Integer> scores = s.getScores();
            /* read */ int score = scores.get(0);
            System.out.println("Student: " + s.name + ", Score: " + score);
        }
    }
}