public class Student {
    private String name;
    private VectorManager vectorManager = new VectorManager();

    public Student(String name) {
        this.name = name;
    }

    public void addScore(int score) {
        vectorManager.addValue(score);
    }

    public Vector<Integer> getScores() {
        return vectorManager.getVector();
    }
}
