import java.util.Vector;

public class VectorManager {
    private Vector<Integer> vector = new Vector<>();

    public void addValue(int value) {
        /* write */ vector.add(value);
    }

    public Vector<Integer> getVector() {
        return vector;
    }
}
