import java.util.Vector;

public class VectorOperations {
    private Vector<Integer> vector = new Vector<>();

    public void addValue(int value) {
        /* write */ vector.add(value);
    }

    public Vector<Integer> getVector() {
        return vector;
    }

    public int calculateSum() {
        int sum = 0;
        for (int i = 0; i < vector.size(); i++) {
            sum += vector.get(i);
        }
        return sum;
    }

    public int findMaxValue() {
        int maxValue = Integer.MIN_VALUE;
        for (Integer num : vector) {
            if (num > maxValue) {
                maxValue = num;
            }
        }
        return maxValue;
    }
}
