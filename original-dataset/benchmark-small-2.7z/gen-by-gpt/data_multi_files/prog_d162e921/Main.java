import java.util.PriorityQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class Main {
    public static void main(String[] args) {
        DelayQueueManager delayQueueManager = new DelayQueueManager();
        DelayedElement element1 = new DelayedElement(1000, "Element1");
        DelayedElement element2 = new DelayedElement(2000, "Element2");

        delayQueueManager.addElement(element1);
        delayQueueManager.addElement(element2);

        // PriorityQueue example
        PriorityQueue<Integer> priorityQueue = new PriorityQueue<>();
        priorityQueue.add(3);
        priorityQueue.add(1);
        priorityQueue.add(2);

        // LinkedBlockingQueue example
        LinkedBlockingQueue<String> linkedBlockingQueue = new LinkedBlockingQueue<>();
        linkedBlockingQueue.add("First");
        linkedBlockingQueue.add("Second");

        // Process PriorityQueue elements
        while (!priorityQueue.isEmpty()) {
            System.out.println("PriorityQueue element: " + priorityQueue.poll());
        }

        // Process LinkedBlockingQueue elements
        while (!linkedBlockingQueue.isEmpty()) {
            System.out.println("LinkedBlockingQueue element: " + linkedBlockingQueue.poll());
        }

        // Additional logic before reading from DelayQueue
        System.out.println("Performing other operations...");

        try {
            DelayedElement retrievedElement1 = delayQueueManager.retrieveElement();
            System.out.println("Retrieved from DelayQueue: " + retrievedElement1);

            DelayedElement retrievedElement2 = delayQueueManager.retrieveElement();
            System.out.println("Retrieved from DelayQueue: " + retrievedElement2);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println("Thread was interrupted");
        }
    }
}