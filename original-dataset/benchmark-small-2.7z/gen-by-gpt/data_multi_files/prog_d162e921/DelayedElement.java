import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;

public class DelayedElement implements Delayed {
    private final long delay;
    private final long expire;
    private final String name;

    public DelayedElement(long delay, String name) {
        this.delay = delay;
        this.expire = System.currentTimeMillis() + delay;
        this.name = name;
    }

    @Override
    public long getDelay(TimeUnit unit) {
        long remaining = expire - System.currentTimeMillis();
        return unit.convert(remaining, TimeUnit.MILLISECONDS);
    }

    @Override
    public int compareTo(Delayed other) {
        if (this.expire < ((DelayedElement) other).expire) {
            return -1;
        }
        if (this.expire > ((DelayedElement) other).expire) {
            return 1;
        }
        return 0;
    }

    @Override
    public String toString() {
        return "DelayedElement{" + "name=" + name + ", delay=" + delay + '}';
    }
}
