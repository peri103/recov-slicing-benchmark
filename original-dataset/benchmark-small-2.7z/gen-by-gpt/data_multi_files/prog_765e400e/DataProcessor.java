import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DataProcessor {
    private ArrayList<Integer> arrayList = new ArrayList<>();
    private HashMap<String, Integer> hashMap = new HashMap<>();

    public void populateArrayList() {
        for (int i = 0; i < 5; i++) {
            arrayList.add(i * 10);
        }
    }

    public void printArrayList() {
        for (int i = 0; i < arrayList.size(); i++) {
            System.out.println("ArrayList element: " + arrayList.get(i));
        }
    }

    public void populateHashMap() {
        hashMap.put("A", 1);
        hashMap.put("B", 2);
        hashMap.put("C", 3);
    }

    public void printHashMap() {
        for (Map.Entry<String, Integer> entry : hashMap.entrySet()) {
            System.out.println("HashMap key: " + entry.getKey() + ", value: " + entry.getValue());
        }
    }

    public int calculateSum(int n) {
        int sum = 0;
        for (int i = 0; i < n; i++) {
            sum += i;
        }
        return sum;
    }
}
