import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        DequeManager dequeManager = new DequeManager();
        Student student = new Student("Bob");

        // Adding scores to the student
        for (int i = 0; i < 5; i++) {
            student.addScore(i * 20);
        }

        // Adding attributes to the student
        student.addAttribute("age", 20);
        student.addAttribute("grade", 3);

        // Adding scores to the deque
        for (int score : student.getScores()) {
            dequeManager.addValue(score);
        }

        // Reading the last value from the deque
        /* read */ Integer lastValue = dequeManager.peekLastValue();
        System.out.println("Last value in deque: " + lastValue);

        // Displaying student attributes
        System.out.println("Student age: " + student.getAttribute("age"));
        System.out.println("Student grade: " + student.getAttribute("grade"));
    }
}