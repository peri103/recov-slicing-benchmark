import java.util.concurrent.ConcurrentLinkedDeque;

public class DequeManager {
    private ConcurrentLinkedDeque<Integer> deque = new ConcurrentLinkedDeque<>();

    public void addValue(int value) {
        /* write */ deque.addLast(value);
    }

    public Integer peekLastValue() {
        return deque.peekLast();
    }
}
