import java.util.Map;

public class Main {
    public static void main(String[] args) {
        QueueOperations queueOps = new QueueOperations();
        Student student = new Student("John");

        // Enrolling student in courses
        student.enrollCourse("Math", 95);
        student.enrollCourse("Science", 88);

        // Display student's courses
        Map<String, Integer> courses = student.getCourses();
        for (Map.Entry<String, Integer> entry : courses.entrySet()) {
            System.out.println("Course: " + entry.getKey() + ", Grade: " + entry.getValue());
        }

        // Add a value to the queue
        queueOps.addValue(42);

        // Some unrelated calculations
        int product = 1;
        for (int i = 1; i <= 3; i++) {
            product *= i;
        }
        System.out.println("Product of numbers 1 to 3: " + product);

        // Retrieve value from the queue
        /* read */ Integer value = queueOps.retrieveValue();
        System.out.println("Retrieved value from queue: " + value);
    }
}