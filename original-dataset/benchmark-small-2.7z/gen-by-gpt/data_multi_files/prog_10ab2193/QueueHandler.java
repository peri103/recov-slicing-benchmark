import java.util.concurrent.LinkedTransferQueue;

public class QueueHandler {
    private LinkedTransferQueue<Integer> queue = new LinkedTransferQueue<>();

    public void addToQueue(int value) {
        /* write */ queue.offer(value);
    }

    public Integer removeFromQueue() {
        return queue.poll();
    }
}
