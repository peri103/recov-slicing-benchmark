import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class MessageQueue {
    private BlockingQueue<String> queue = new LinkedBlockingQueue<>();

    public void addMessage(String message) {
        queue.add(message);
    }

    public String processMessage() throws InterruptedException {
        return queue.take();
    }

    public boolean hasMessages() {
        return !queue.isEmpty();
    }
}
