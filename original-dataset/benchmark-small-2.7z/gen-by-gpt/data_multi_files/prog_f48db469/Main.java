import java.util.HashSet;

public class Main {
    public static void main(String[] args) {
        TreeSetOperations treeSetOps = new TreeSetOperations();
        Student student = new Student("John");

        // Add elements to TreeSet
        for (int i = 0; i < 5; i++) {
            treeSetOps.addElement(i * 10);
        }

        // Check if elements are present in TreeSet
        for (int i = 0; i < 50; i += 10) {
            /* read */ boolean containsValue = treeSetOps.containsElement(i);
            System.out.println("TreeSet contains " + i + ": " + containsValue);
        }

        // Add grades to student
        student.addGrade(95.5);
        student.addGrade(88.0);

        // Display student information
        System.out.println("Student Name: " + student.getName());
        System.out.println("Grades: " + student.getGrades());

        // HashSet operations
        HashSet<String> hashSet = new HashSet<>();
        hashSet.add("Hello");
        hashSet.add("World");

        if (hashSet.contains("Hello")) {
            System.out.println("HashSet contains 'Hello'");
        }
    }
}