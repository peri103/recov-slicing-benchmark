import java.util.concurrent.LinkedBlockingQueue;
import java.util.Queue;

public class ComplexOperations {
    public void performQueueOperations() {
        LinkedBlockingQueue<String> queue = new LinkedBlockingQueue<>();
        queue.add("Hello");
        queue.add("World");
        System.out.println("Queue elements:");
        for (String s : queue) {
            System.out.println(s);
        }
    }

    public void performNumberOperations() {
        Queue<Integer> numberQueue = new LinkedBlockingQueue<>();
        for (int i = 1; i <= 5; i++) {
            numberQueue.add(i);
        }
        System.out.println("Number queue elements:");
        while (!numberQueue.isEmpty()) {
            System.out.println(numberQueue.poll());
        }
    }

    public void performSumCalculation() {
        int sum = 0;
        for (int i = 1; i <= 10; i++) {
            sum += i;
        }
        System.out.println("Sum of numbers from 1 to 10: " + sum);
    }
}
