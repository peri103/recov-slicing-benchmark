public class Main {
    public static void main(String[] args) {
        DequeOperations dequeOps = new DequeOperations();
        ComplexOperations complexOps = new ComplexOperations();

        complexOps.performQueueOperations();
        complexOps.performNumberOperations();
        
        dequeOps.addValue(42);
        
        // More complex operations on deque
        for (int i = 0; i < 3; i++) {
            dequeOps.getDeque().addLast(i * 10);
        }
        System.out.println("Deque elements after adding more items:");
        for (Integer num : dequeOps.getDeque()) {
            System.out.println(num);
        }
        
        complexOps.performSumCalculation();
        
        try {
            /* read */ int value = dequeOps.getDeque().takeLast();
            System.out.println("Read value from deque: " + value);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Further operations on deque
        dequeOps.getDeque().addLast(99);
        System.out.println("Final state of deque:");
        for (Integer num : dequeOps.getDeque()) {
            System.out.println(num);
        }
    }
}