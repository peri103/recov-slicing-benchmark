public class Main {
    public static void main(String[] args) {
        StackManager stackManager = new StackManager();
        Course course = new Course("Computer Science");

        // Enroll students in the course
        course.enrollStudent("Alice");
        course.enrollStudent("Bob");
        course.enrollStudent("Charlie");
        course.processEnrollments();

        // Use the stack manager
        stackManager.pushValue(10);
        stackManager.pushValue(20);
        stackManager.pushValue(30);

        // Perform stack operations
        int sum = 0;
        while (!stackManager.isEmpty()) {
            sum += stackManager.popValue();
        }
        System.out.println("Sum of stack elements: " + sum);

        // Reuse the stack manager
        stackManager.pushValue(42);
        stackManager.pushValue(84);
        stackManager.pushValue(126);

        // Read the top element of the stack
        /* read */ int value = stackManager.peekValue();
        System.out.println("Top of stack: " + value);

        // Final operations
        System.out.println("Stack size: " + stackManager.getSize());
        while (!stackManager.isEmpty()) {
            System.out.println("Popped: " + stackManager.popValue());
        }
    }
}