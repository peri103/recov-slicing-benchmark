import java.util.LinkedList;
import java.util.Queue;

public class Course {
    private String courseName;
    private Queue<String> studentsQueue = new LinkedList<>();

    public Course(String courseName) {
        this.courseName = courseName;
    }

    public void enrollStudent(String studentName) {
        studentsQueue.add(studentName);
    }

    public void processEnrollments() {
        while (!studentsQueue.isEmpty()) {
            System.out.println("Enrolling: " + studentsQueue.poll() + " in " + courseName);
        }
    }
}
